%En was interested in knowing correlation between puncta and curvature.
%Unlike the 2d projections done before, I had better idea for to use in
%poster, paper figures ....

clear all;
close all;


%ROI42 will be the test case

%image stacks
int_stack='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\results - real data ROI42\Final Code to use - red channel\Final_ER1_Avg_Stack.tif';
cl_stack='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\results - real data ROI42\Final Code to use - red channel\Final_Cluster_Stack.tif';

%get number images
int_info=imfinfo(int_stack);
num_images=numel(int_info);

%cell array to hold boundary and intensity information
cell_intensity=cell(num_images,3);
cell_bound=cell(num_images,1);

%get the curvature data
[x1,y1,z1,curve1]=get_curvature();
x1=double(x1);
y1=double(y1);
z1=double(z1);

%reading in the stacks
for r=1:num_images

   %images
   int_im=(imread(int_stack,r)); 
   cl_im=(imread(cl_stack,r));
   
   %some dimensions
   if r==1
       dim1=size(int_im,1);
       dim2=size(int_im,2);
       im_keep=int_im;
   end

   %figuring out center
   idx_c=find(cl_im>0);
   [y_c,x_c]=ind2sub(size(cl_im),idx_c);

   %calculate angle
   bound_send=[y_c,x_c];
   [giant_coord_list_tmp]=calc_angle(bound_send,mean(x_c),mean(y_c),im_keep);
   giant_coord_list=sortrows(giant_coord_list_tmp,3);
   
   %storing the initial boundary
   cell_bound(r,1)={[giant_coord_list(:,1),giant_coord_list(:,2)]};
   
   %storing the intensity information - all intensity
   cell_intensity(r,1)={int_im(idx_c)};
   

   %getting the actual centers
   bw_im=poly2mask(giant_coord_list(:,1),giant_coord_list(:,2),dim1,dim2);
   center_tmp=regionprops(bw_im,'Centroid');
   centers=center_tmp.Centroid;
   centers_keep(r,1)=centers(1);
   centers_keep(r,2)=centers(2);
   
   %clear statements
   clear int_im; clear cl_im; clear giant_coord_list; clear giant_coord_list_tmp;
   clear BW; clear idx_c; clear bw_im; clear bound_send;
   clear center_tmp; clear centers; 
   
end

%absolute centers
x_abs_center=mean(centers_keep(:,1));
y_abs_center=mean(centers_keep(:,2));

%getting the actual angle to use
for s=1:num_images

    %images
    int_im=(imread(int_stack,s)); 
    cl_im=(imread(cl_stack,s));
    
    %get a boundary
    bound_tmp=cell_bound(s,1);
    bound=bound_tmp{1};
    
    %adding z
    bound(:,3)=linspace(s,s,numel(bound(:,1)))';
    
    %getting intensity - raw
    idx_b=sub2ind(size(int_im),bound(:,2),bound(:,1));
    bound(:,4)=int_im(idx_b);
    
    %getting intensity in cluster and out of cluster
    all_intensity=int_im(idx_b);
    all_cluster=cl_im(idx_b);
    
    for u=1:numel(idx_b)
        if all_cluster(u,1)<=1
            int_in_cluster(u,1)=0;
            int_out_cluster(u,1)=all_intensity(u,1);
        else
            int_in_cluster(u,1)=all_intensity(u,1);
            int_out_cluster(u,1)=0;
        end
    end

    %adding intensities - in and out of cluster
    bound(:,5)=int_in_cluster;
    bound(:,6)=int_out_cluster;
    
    
    if s==1
        master_list=bound;
    else
        master_list_tmp=master_list;
        clear master_list;
        master_list=[master_list_tmp;bound];
        clear master_list_tmp;
    end
    
    min_x_arr(s,1)=min(bound(:,1));
    max_x_arr(s,1)=max(bound(:,1));
    
    %clear statements
    clear bound_tmp; clear bound; clear int_im; clear idx_b;
    clear all_intensity; clear all_cluster; clear int_in_cluster;
    clear int_out_cluster;
    
end

%extrema stuff for 2d projection
abs_min_x=min(min_x_arr(:,1));
abs_max_x=max(max_x_arr(:,1));

%pre-allocating for speed - intensity projections
proj2d=zeros(num_images,abs_max_x-abs_min_x+1);
proj2d_in=zeros(num_images,abs_max_x-abs_min_x+1);
proj2d_out=zeros(num_images,abs_max_x-abs_min_x+1);

%pre-allocating for speed - coordinate projections
proj2d_x=zeros(num_images,abs_max_x-abs_min_x+1);
proj2d_y=zeros(num_images,abs_max_x-abs_min_x+1);
proj2d_z=zeros(num_images,abs_max_x-abs_min_x+1);

for q=1:num_images
   
    %get the information for this z slice
    idx_list=find(master_list(:,3)==q);
    master_list_tmp=master_list(idx_list,:);
    
    %counter
    count=1;
    
    if numel(idx_list)>0
        
        for g=abs_min_x:abs_max_x
            
            %looking for x coordinate
            idx_look=find(master_list_tmp(:,1)==g);
            
            %counter
            count2=1;
            
            if numel(idx_look)>0
               
                for p=1:numel(idx_look)
                    if master_list_tmp(idx_look(p),2)>y_abs_center
                        
                        %all intensity
                        thing_keep(count2,1)=master_list_tmp(idx_look(p),4);
                        
                        %intensity in cluster
                        thing_keep_in(count2,1)=master_list_tmp(idx_look(p),5);
                        
                        %intensity out of cluster
                        thing_keep_out(count2,1)=master_list_tmp(idx_look(p),6);
                        
                       %storing y coordinate
                       thing_keep_y(count2,1)=master_list_tmp(idx_look(p),2);
                        
                        %iterate counter
                        count2=count2+1;
                        
                    end
                end
                
                %loading projections
                if count2>1
                    
                    %intensity projections
                    proj2d(q,count)=max(thing_keep(:,1));
                    proj2d_in(q,count)=max(thing_keep_in(:,1));
                    proj2d_out(q,count)=max(thing_keep_out(:,1));
                    
                    %coordinate projections
                    proj2d_x(q,count)=g;
                    proj2d_y(q,count)=(thing_keep_y(1));
                    proj2d_z(q,count)=q;
                    
                end
                
                %clear statements
                clear thing_keep; clear thing_keep_out; clear thing_keep_in;
                
            end
            clear idx_look;
            count=count+1;
        end
        
    end
    
    clear idx_list; clear master_list_tmp
    
end

%flipping to make outputs look like  Imaris
proj2d=flipud(proj2d);
proj2d_in=flipud(proj2d_in);
proj2d_out=flipud(proj2d_out);
proj2d_x=flipud(proj2d_x);
proj2d_y=flipud(proj2d_y);
proj2d_z=flipud(proj2d_z);

%figures
figure, imagesc((proj2d),[0 1200]); colormap(gray); colorbar; title('All Intensity');
figure, imagesc((proj2d_in),[0 1200]); colormap(gray); colorbar; title('Intensity in Clusters');
figure, imagesc((proj2d_out),[0 1200]); colormap(gray); colorbar; title('All Intensity Out of Clusters');

figure, imagesc((proj2d_x)); colormap(gray); colorbar; title('x coordinate');
figure, imagesc((proj2d_y)); colormap(gray); colorbar; title('y coordinate');
figure, imagesc((proj2d_z)); colormap(gray); colorbar; title('z coordinate');

% [x1,y1,z1,curve1]=get_curvature();
% z1_int=uint16(z1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%adding curvature%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%dimensions
dimA=size(proj2d_x,1);
dimB=size(proj2d_x,2);

%curvature projection
proj2d_curve=double(zeros([dimA,dimB]));

%nonzero entries
idx_non_zero=find(proj2d_x>0);


z1=z1-94+1;

for a=1:numel(idx_non_zero)
     
        %coordinates
        xnow=proj2d_x(idx_non_zero(a)); xnow=double(xnow);
        ynow=proj2d_y(idx_non_zero(a)); ynow=double(ynow);
        znow=proj2d_z(idx_non_zero(a)); znow=double(znow);
        
        %keeping xyz coordinates
        xmeg(a,1)=xnow;
        ymeg(a,1)=ynow;
        zmeg(a,1)=znow;
        
        %distance calculations
        dist_arr=(((x1-xnow).^2)+((y1-ynow).^2)+((z1-znow).^2)).^0.5;
        
        %finding minimum distance
        min_dist=min(dist_arr(:,1));
        if min_dist<=20000
            idx_min=find(dist_arr==min_dist);
        
            %loading curvature projection
            all_curve=curve1(idx_min,1);
            idx_good=find(all_curve~=0);
            if numel(idx_good)>0
                idx_non_zero(a)
                proj2d_curve(idx_non_zero(a))=mean(all_curve(idx_good));
            end
            
            %clear statements
            clear idx_min;clear all_curve; clear idx_good;
        end
        
        %clear statements
        clear xnow; clear ynow; clear znow;
        clear dist_arr; clear min_dist; 

end

%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%figure
figure, imagesc(proj2d_curve,[-0.5,0.5]); colormap(ens_curve_map); colorbar; title('Curvature');
% 
% figure, hold on;
% plot3(x1,y1,z1,'r+');
% plot3(xmeg,ymeg,zmeg,'go');



%rgb rendering
proj2d_curve_rgb=make_rgb_blank_en(proj2d_curve);
proj2d_rgb=make_rgb_blank_gray(proj2d,12000);
proj2d_in_rgb=make_rgb_blank_gray(proj2d_in,12000);
proj2d_out_rgb=make_rgb_blank_gray(proj2d_out,12000);

%bump mapping
proj2d_rgb_bump(:,:,1)=proj2d_rgb(:,:,1).*proj2d_curve_rgb(:,:,1);
proj2d_rgb_bump(:,:,2)=proj2d_rgb(:,:,2).*proj2d_curve_rgb(:,:,2);
proj2d_rgb_bump(:,:,3)=proj2d_rgb(:,:,3).*proj2d_curve_rgb(:,:,3);

proj2d_in_rgb_bump(:,:,1)=proj2d_in_rgb(:,:,1).*proj2d_curve_rgb(:,:,1);
proj2d_in_rgb_bump(:,:,2)=proj2d_in_rgb(:,:,2).*proj2d_curve_rgb(:,:,2);
proj2d_in_rgb_bump(:,:,3)=proj2d_in_rgb(:,:,3).*proj2d_curve_rgb(:,:,3);

proj2d_out_rgb_bump(:,:,1)=proj2d_out_rgb(:,:,1).*proj2d_curve_rgb(:,:,1);
proj2d_out_rgb_bump(:,:,2)=proj2d_out_rgb(:,:,2).*proj2d_curve_rgb(:,:,2);
proj2d_out_rgb_bump(:,:,3)=proj2d_out_rgb(:,:,3).*proj2d_curve_rgb(:,:,3);

%rgb matrix
rgb_matrix=[[proj2d_rgb,proj2d_rgb_bump];[proj2d_in_rgb,proj2d_in_rgb_bump];[proj2d_out_rgb,proj2d_out_rgb_bump]];
figure, imshow(rgb_matrix);


