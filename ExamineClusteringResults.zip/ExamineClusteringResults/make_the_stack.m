function[stack_ret]=make_the_stack(the_dir,num_ims)


%open the directory 
listing=dir(the_dir);

%pre-allocating
idx_arr=zeros(num_ims,2);
ims_arr=cell(num_ims,1);
idx_arr(:,2)=[1:num_ims]';

%counter
count=1;
count2=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Open the Files%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%find the indices
for i=1:size(listing,1)
   
    %get name
    the_name=listing(i).name;
    
    strcat(the_dir,the_name)
    
    if numel(the_name)>=3
       
        %get the index
        idx_per=find(the_name=='.');
        
        %index test
        idx_test1=str2num(the_name(idx_per(1)-1));
        idx_test2=str2num(the_name(idx_per(1)-2:idx_per(1)-1));
        idx_test3=str2num(the_name(idx_per(1)-3:idx_per(1)-1));
        
        if numel(idx_test3)>0
            idx_arr(count,1)=idx_test3;
            count=count+1;
        elseif numel(idx_test2)>0
            idx_arr(count,1)=idx_test2;
            count=count+1;
        else
            idx_arr(count,1)=idx_test1;
            count=count+1;
        end
        
        
        
        %reading and storing image
        ims_arr(count2,1)={imread(strcat(the_dir,the_name))};
        count2=count2+1;
        
       %clear statements
       clear idx_per; clear idx_test1; clear idx_test2; clear idx_test3;
        
    end
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%creating the stack%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%sorting
idx_arr_sort=sortrows(idx_arr,1);

for j=1:num_ims
    
    
    
    %get the relevant index
    idx_ret=idx_arr_sort(j,2);
    
    %get the image
    im_tmp=ims_arr(idx_ret,1);
    im=im_tmp{1};
    
    %figure, imagesc(im); colormap(gray); colorbar; title(num2str(j));
    
    %pre-allocating stacks
    if j==1
        dim1=size(im,1)
        dim2=size(im,2)
        stack_ret=zeros(dim1,dim2,num_ims);
    end
    
    %store the image
    stack_ret(:,:,j)=im;
    
    %clear statements
    clear idx_ret; clear im_tmp; clear im;
    
end










