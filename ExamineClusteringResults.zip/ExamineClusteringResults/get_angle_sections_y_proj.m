function[]=get_angle_sections_y_proj(ang_in,a0,aF)

%z extrema
min_z=min(ang_in(:,5));
max_z=max(ang_in(:,5));

%cell array to hold the sections
cell_sections=cell((max_z-min_z+1),1);

%number of images
num_ims=(max_z-min_z+1);

for i=min_z:max_z
    
  %a section of matrix
  idx_section=find(ang_in(:,5)==i);
  the_section=ang_in(idx_section,:);

  %low end
  idx_low_tmp=find(the_section(:,3)>=a0);
  if numel(idx_low_tmp)>0
     idx_low=idx_low_tmp(1);
  else
     idx_low=1;
  end
  
  %high end
  idx_high_tmp=find(the_section(:,3)<=aF);
  if numel(idx_high_tmp)>0
      idx_high=idx_high_tmp(numel(idx_high_tmp));
  else
      idx_high=numel(the_section(:,3));
  end
  
  %storing
  cell_sections(i,1)={the_section(idx_low:idx_high,:)};
  
  %record xy extreme
  ylow_arr(i,1)=min(the_section(idx_low:idx_high,2));
  yhigh_arr(i,1)=max(the_section(idx_low:idx_high,2));
  
  %clear statements
  clear idx_section; clear the_section;
  clear idx_high_tmp; clear idx_high;
  clear idx_low_tmp; clear idx_low;

end

%x extrema
abs_ylow=uint16(min(ylow_arr(:,1)));
abs_yhigh=uint16(max(yhigh_arr(:,1)));

%projection to return
width_proj=abs_yhigh-abs_ylow+1;
the_proj_return_x=zeros((max_z-min_z+1),width_proj);
the_proj_return_y=zeros((max_z-min_z+1),width_proj);
the_proj_return_z=zeros((max_z-min_z+1),width_proj);
the_proj_return_int=zeros((max_z-min_z+1),width_proj);

%adding the intensity data to projection
for g=1:num_ims
    
    %grab a matrix section
    section_now_tmp=cell_sections(g,1);
    section_now=section_now_tmp{1};
    
    %sorting by y coordinate
    section_now_sort=sortrows(section_now,2);
    
    %counter
    count=1;
    
    for k=abs_ylow:abs_yhigh
        
        %populate the z matrix
        the_proj_return_z(g,:)=g;
        
        %populate the intensity matrix y matrix
        idx_is_there=find(section_now_sort(:,2)==k);
        if numel(idx_is_there)>0
            the_proj_return_int(g,count)=max(section_now_sort(idx_is_there,4));
            the_proj_return_x(g,count)=mean(section_now_sort(idx_is_there,1));
        end
        clear idx_is_there; 
        
        %populate the y matrix
        the_proj_return_y(g,count)=k;
        
        %iterate counter
        count=count+1;

    end
    
    %clear statements
    clear section_now_tmp; clear section_now;
    clear section_now_sort;
end

%figures for debugging
figure, imagesc(medfilt2(the_proj_return_int, [3 3])); colormap(gray); colorbar; title('Intensity Projection');
% figure, imagesc(the_proj_return_x); colormap(gray); colorbar; title('x Projection');
% figure, imagesc(the_proj_return_y); colormap(gray); colorbar; title('y Projection');
% figure, imagesc(the_proj_return_z); colormap(gray); colorbar; title('z Projection');












