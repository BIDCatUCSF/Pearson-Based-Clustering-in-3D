function[]=return_projection(im1,angle_data)

%definitions of inputs
%im1 = stack of images
%angle_data(:,1)=x boundary
%angle_data(:,2)=y boundary
%angle_data(:,3)=theta;
%angle_data(:,4)=intensity
%angle_data(:,5)=z slice

%which_quad = 1 (30->120)
%which_quad = 2 (120->210)
%which_quad = 3 (210->300)
%which_quad = 4 (300->30)












































