clear all; close all;

%this is a function written to check the orientation of the intensity data
%and curvature surface.

%image stacks
int_stack='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\results - real data ROI42\Final Code to use - green channel\Final_ER1_Avg_Stack.tif';

%get number images
int_info=imfinfo(int_stack);
num_images=numel(int_info);

%get the curvature data
[x1,y1,z1,curve1]=get_curvature();
z1_int=uint16(z1);

%image start index
ns=94;


%reading in the stacks
for r=1:num_images
    
    %images
   int_im=(imread(int_stack,r));
   figure, imagesc(int_im); colormap(gray); colorbar; hold on; title(num2str(ns));
   
   %looking on surface
   idx_find=find(z1_int==ns);
   
   if numel(idx_find)>0
       xplot=x1(idx_find);
       yplot=y1(idx_find);
       for p=1:numel(idx_find)
          plot(xplot(p),yplot(p),'r+','LineWidth',1.5); 
       end
       clear xplot; clear yplot;
   end
   
   %iterate index
   ns=ns+1;
   
   %clear statements
   clear int_im; clear idx_find;
    
end































