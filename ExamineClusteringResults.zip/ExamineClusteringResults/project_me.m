%En was interested in knowing correlation between puncta and curvature.
%Unlike the 2d projections done before, I had better idea for to use in
%poster, paper figures ....

clear all;
close all;


%ROI42 will be the test case

%image stacks
int_stack='E:\en project\Oct2018 Images\Simple2Dto3dProjCode\creating simulation\Sim1.tif';
cl_stack='E:\en project\Oct2018 Images\Simple2Dto3dProjCode\creating simulation\Sim1.tif';

%get number images
int_info=imfinfo(int_stack);
num_images=numel(int_info);

%cell array to hold boundary and intensity information
cell_intensity=cell(num_images,1);
cell_bound=cell(num_images,1);

%reading in the stacks
for r=1:num_images

   %images
   int_im=(imread(int_stack,r)); 
   cl_im=(imread(cl_stack,r));
   
   %some dimensions
   if r==1
       dim1=size(int_im,1);
       dim2=size(int_im,2);
       im_keep=int_im;
   end

   %figuring out center
   idx_c=find(cl_im>0);
   [y_c,x_c]=ind2sub(size(cl_im),idx_c);

   %calculate angle
   bound_send=[y_c,x_c];
   [giant_coord_list_tmp]=calc_angle(bound_send,mean(x_c),mean(y_c),im_keep);
   giant_coord_list=sortrows(giant_coord_list_tmp,3);
   
   %storing the initial boundary
   cell_bound(r,1)={[giant_coord_list(:,1),giant_coord_list(:,2)]};
   
   %storing the intensity information
   cell_intensity(r,1)={int_im(idx_c)};
   
   %getting the actual centers
   bw_im=poly2mask(giant_coord_list(:,1),giant_coord_list(:,2),dim1,dim2);
   center_tmp=regionprops(bw_im,'Centroid');
   centers=center_tmp.Centroid;
   centers_keep(r,1)=centers(1);
   centers_keep(r,2)=centers(2);
   
   %clear statements
   clear int_im; clear cl_im; clear giant_coord_list; clear giant_coord_list_tmp;
   clear BW; clear idx_c; clear bw_im; clear bound_send;
   clear center_tmp; clear centers;
end

%absolute centers
x_abs_center=mean(centers_keep(:,1));
y_abs_center=mean(centers_keep(:,2));

%getting the actual angle to use
for s=1:num_images

    %get a boundary
    bound_tmp=cell_bound(s,1);
    bound=bound_tmp{1};
    
    %getting the intensity for each boundary position
    int_for_bound_tmp=cell_intensity(s,1);
    int_for_bound=int_for_bound_tmp{1};
    
    %angles
    [coord_list_tmp]=calc_angle(bound,x_abs_center,y_abs_center,im_keep);
    coord_list_tmp(:,4)=int_for_bound;
    coord_list=sortrows(coord_list_tmp,3);
    
    %z coordinate
    coord_list(:,5)=linspace(s,s,numel(coord_list(:,3)))';
    
    %making large matrix
    if s==1
        master_list=coord_list;
    else
        master_list_tmp=master_list;
        clear master_list;
        master_list=[master_list_tmp;coord_list];
        clear master_list_tmp;
    end
    
    %clear statements
    clear bound_tmp; clear bound;
    clear coord_list_tmp;clear coord_list;
    clear  int_for_bound_tmp; clear int_for_bound;
    
end

%converting to degree for the love of god
master_list(:,3)=master_list(:,3)*(180/pi);

%making a copy of list and scaling for calculation on quadrant 4
idx_yeah=find(master_list(:,3)<=30);
master_list_copy=master_list;
master_list_copy(idx_yeah,3)=master_list_copy(idx_yeah,3)+360;

get_angle_sections_x_proj(master_list,10,170);
% get_angle_sections_y_proj(master_list,120,210);
% get_angle_sections_x_proj(master_list,210,300);
% get_angle_sections_y_proj(master_list_copy,300,390);
































