function[the_rgb_im]=make_rgb_blank_gray(im_start,max_num)

%colormaps
gray_map(:,1)=linspace(0,1,64)';
gray_map(:,2)=linspace(0,1,64)';
gray_map(:,3)=linspace(0,1,64)';

min_num=0;

max_num=double(max_num);
min_num=double(min_num);

im_start=im_start-min_num;
max_num=max_num-min_num;
max_num=max_num*1;

im_start=im_start.*(64/max_num);
the_rgb_im=ind2rgb(uint16(im_start),gray_map);


