function[ret_thing]=add_frame_around_psf(psf_in)

%dimensions
dA=size(psf_in,1)
dB=size(psf_in,2)

dA_new=uint16(dA*1.6)
dB_new=uint16(dB*1.6)

ret_thing=zeros(dA_new,dB_new);
ret_thing=double(ret_thing);

cx=uint16(dA_new*0.5)
cy=uint16(dB_new*0.5)

for q=1:dA
    for p=1:dB
   
        ret_thing(uint16(cx-(dA*0.5)+p),uint16(cy-(dB*0.5)+q))=psf_in(q,p);
        
    end
end





















