function[proj_2d_ret]=make_2d_projection(t_kernel,er_path,path_bd,n_start,n_end)

%This functions does the 2d projection from the kernel
%t_kernel - the coordinates of kernel
%t_kernel(:,1) = x
%t_kernel(:,2) = y
%t_kernel(:,3) = z
%er_path = path to eroded boundaries

%z slice extrema
zmin=min(t_kernel(:,3));
zmax=max(t_kernel(:,3));

%cell array to hold angles of averaged boundary
cell_ang_avg_bd=cell(zmax-zmin+1,2);

%averaging the eroded images
[new_im_arr,list_frames]=avg_erode_bound(er_path,path_bd,n_start,n_end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%Figuring out the extent to dicretize in radial direction%%%%%%%%%%%%

%counter
count_bd=1;

%adding the angle
for r=zmin:zmax
   
    %getting the frame number
    idx_frame=find(list_frames==r);
    
    %getting the image of the averaged boundary
    er_avg_new_tmp=new_im_arr(idx_frame(1),1);
    er_avg_new=er_avg_new_tmp{1};
    
    %getting all of the non-zero entries
    idx_it=find(er_avg_new>0);
    
    %converting these indices to xy coordinates
    [y_it,x_it]=ind2sub(size(er_avg_new),idx_it);
    bd_it=[y_it,x_it];
    
    %making a blank image
    blank_im=zeros(size(er_avg_new));
    blank_im=double(blank_im);
    
    %masking
    blank_im(idx_it)=1;
    
    %calculating centroid for this slice
    s=regionprops(blank_im,'centroid');
    c_now=s.Centroid;
    
    %get the angles of the coordinates of the average boundaries
    [ang_er_avg]=calc_angle(bd_it,c_now(1),c_now(2),blank_im);
    ang_er_avg(:,3)=ang_er_avg(:,3).*(180/pi);
    sort_ang_er_avg=sortrows(ang_er_avg,3);
    cell_ang_avg_bd(count_bd,1)={sort_ang_er_avg};
    cell_ang_avg_bd(count_bd,2)={r};
    
    %getting all coordinates in kernel from this z slice
    idx_k=find(t_kernel(:,3)==r);
    if numel(idx_k)>0
       
        %segment out the coordinates in this slice
        bound_s(:,2)=t_kernel(idx_k,1);
        bound_s(:,1)=t_kernel(idx_k,2);
        
        %get the angles
        [ang_get]=calc_angle(bound_s,c_now(1),c_now(2),blank_im);
        
        %storing the angle information
        t_kernel(idx_k,4)=(ang_get(:,3))*(180/pi);
        
        %clear statements
        clear bound_s; clear ang_get;
        
    end
    
    %iterate counter
    count_bd=count_bd+1;
    
    %clear statements
    clear idx_frame; clear er_avg_new_tmp; clear er_avg_new;
    clear idx_it; clear blank_im; clear s; clear c_now; clear idx_k;
    clear y_it; clear x_it;
    clear bd_it; clear ang_er_avg; clear sort_ang_er_avg;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Some quality control%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%These lines of code handle the case where you angles like
%356,357,358,359,1,2,3 ... you are near 0 degree point

% %find high angles
% idx_high1=find(t_kernel(:,4)>300);
% idx_low1=find(t_kernel(:,4)<50);
% 
% %flag to tell you if you are at this interface
% flag_interface=0;
% 
% if numel(idx_high1)>0 && numel(idx_low1)>0
%     flag_interface=1; 
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Figuring out the widest z slice%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_size=1;

for s=zmin:zmax

    %the elements of the kernel to examine
    idx_length=find(t_kernel(:,3)==s);
    
    %get the theta of the kernel
    theta_ker=t_kernel(idx_length,4);
    
    %find high angles
    idx_high1=find(theta_ker>300);
    idx_low1=find(theta_ker<50);
    
    %flag to tell you if you are at this interface
    flag_interface=0;
    
    if numel(idx_high1)>0 && numel(idx_low1)>0
        flag_interface=1;
    end
    
    %clear statements
    clear idx_high1; clear idx_low1;
    
    %getting the theta for the whole boundary
    whole_bd_tmp=cell_ang_avg_bd(count_size,1);
    whole_bd=whole_bd_tmp{1};
    
    if flag_interface==1
        
        %counters
        count_left=1;
        count_right=1;
 
        for a=1:numel(theta_ker)
           
            %an angle from the kernel
            theta_now=theta_ker(a)
            
            if theta_now>270 && theta_now <=360
                theta_left(count_left,1)=theta_now;
                count_left=count_left+1;
            else
                theta_right(count_right,1)=theta_now;
                count_right=count_right+1;
            end
            
            %clear statement
            clear theta_now;
            
        end
        
        %going to the boundary of slice - left
        theta_left
        min_left=min(theta_left(:,1));
        idx_start_tmp=find(whole_bd(:,3)>=min_left);
        if numel(idx_start_tmp)>0
            idx_start1=idx_start_tmp(1);
        else
            idx_start1=numel(whole_bd(:,3));
        end
        idx_end1=numel(whole_bd(:,3));
        
        %going to the boundary of slice - right
        if count_right>1
            idx_start2=1;
            max_right=max(theta_right(:,1));
            idx_end_tmp=find(whole_bd(:,3)<=max_right);
            if numel(idx_end_tmp)>0
                idx_end2=idx_end_tmp(numel(idx_end_tmp));
            else
                idx_end2=1;
            end
            
            %calculating the length
            the_length_now=(numel([idx_start1:idx_end1]))+(numel([idx_start2:idx_end2]));
            
            %storing sizes
            what_size(count_size,1)=the_length_now;
            what_size(count_size,2)=s;
            
            %storing indices in each
            idx_extrema(count_size,1)=idx_start1;
            idx_extrema(count_size,2)=idx_end1;
            idx_extrema(count_size,3)=idx_start2;
            idx_extrema(count_size,4)=idx_end2;
            
        else
            
            %calculating the length
            the_length_now=(numel([idx_start1:idx_end1]));
            
            %storing
            what_size(count_size,1)=the_length_now;
            what_size(count_size,2)=s;
            
            %storing indices in each
            idx_extrema(count_size,1)=idx_start1;
            idx_extrema(count_size,2)=idx_end1;
            idx_extrema(count_size,3)=0;
            idx_extrema(count_size,4)=0;
            
        end
        
        %clear statements
        clear min_left; clear max_right;
        clear idx_start_tmp; clear idx_start1; clear idx_end1;
        clear idx_end_tmp; clear idx_start2; clear idx_end2;
        clear the_length_now;clear theta_left; clear theta_right;
        
    else
        
        %extrema
        min_theta_ker=min(theta_ker);
        max_theta_ker=max(theta_ker);
        
        %the start
        idx_start1_tmp=find(whole_bd(:,3)>=min_theta_ker);
        if numel(idx_start1_tmp)>0
            idx_start1=idx_start1_tmp(1);
        else
            idx_start1=1;
        end
        
        %the end
        idx_end1_tmp=find(whole_bd(:,3)<=max_theta_ker);
        if numel(idx_end1_tmp)>=0
           idx_end1=idx_end1_tmp(numel(idx_end1_tmp));
        else
            idx_end1=numel(whole_bd(:,3));
        end
        
        %calculating the length
        the_length_now=(numel([idx_start1:idx_end1]));
        
        %storing
        what_size(count_size,1)=the_length_now;
        what_size(count_size,2)=s;
        
        %storing indices in each
        idx_extrema(count_size,1)=idx_start1;
        idx_extrema(count_size,2)=idx_end1;
        idx_extrema(count_size,3)=0;
        idx_extrema(count_size,4)=0;
        
        %clear statements
        clear min_theta_ker; clear max_theta_ker; clear idx_start1_tmp; clear idx_start1;
        clear idx_end1_tmp; clear idx_end1; clear the_length_now;
        
    end
    
    
    
    %iterate counter
    count_size=count_size+1;
    
    %clear statements
    clear idx_length; clear theta_ker; clear whole_bd_tmp; clear whole_bd;
    
end

%getting the maximum
sort_what_size=sortrows(what_size,1);
big_z=sort_what_size(count_size-1,2);
xsize_proj=sort_what_size(count_size-1,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%making the 2d projection%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%inserting the widest element%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%size of projection
zsize_proj=zmax-zmin+1;

%counter
count_final=1;

%loading the widest frame
for u=zmin:zmax
    
    %stop at the widest z
    if u==big_z

        %get the elements from the big slice
        idx_s1=idx_extrema(count_final,1);
        idx_e1=idx_extrema(count_final,2);
        idx_s2=idx_extrema(count_final,3);
        idx_e2=idx_extrema(count_final,4);

        %getting the frame number
        idx_frame=find(list_frames==u);

        %getting the image of the averaged boundary
        er_avg_new_tmp=new_im_arr(idx_frame(1),1);
        er_avg_new=er_avg_new_tmp{1};
        er_avg_new=double(er_avg_new);
        %figure, imagesc(er_avg_new); colormap(gray); colorbar; title(num2str(u));
        
        
        %getting the theta for the whole boundary
        whole_bd_tmp=cell_ang_avg_bd(count_final,1);
        whole_bd=whole_bd_tmp{1};

        %pre-allocate matrix
        proj_2d_ret=zeros(zsize_proj,xsize_proj);
        proj_2d_ret=double(proj_2d_ret);
        
        %the middle  position of the widest row
        mid_of_widest_row=uint16(xsize_proj*0.5);
        mid_of_widest_row=double(mid_of_widest_row);
        
        if idx_s2==0 && idx_e2==0
            
            xa=whole_bd(idx_s1:idx_e1,1);
            ya=whole_bd(idx_s1:idx_e1,2);
            idx_a=sub2ind(size(er_avg_new),ya,xa);
            proj_2d_ret(count_final,:)=er_avg_new(idx_a);
            
            %getting the middle angle
            all_angles=[whole_bd(idx_s1:idx_e1,3)]
            mid_angle=all_angles(uint16(xsize_proj*0.5))
            
            %clear statements
            clear xa; clear ya; clear idx_a;
            
        else
            
            xa=whole_bd(idx_s1:idx_e1,1);
            ya=whole_bd(idx_s1:idx_e1,2);
            idx_a=sub2ind(size(er_avg_new),ya,xa);
            l_add=numel(idx_a);
            proj_2d_ret(count_final,1:l_add)=er_avg_new(idx_a);
            
            xb=whole_bd(idx_s2:idx_e2,1);
            yb=whole_bd(idx_s2:idx_e2,2);
            idx_b=sub2ind(size(er_avg_new),yb,xb);
            l_add2=numel(idx_b)+l_add;
            proj_2d_ret(count_final,(l_add+1):l_add2)=er_avg_new(idx_b);
            
            %getting the middle angle
            all_angles=[whole_bd(idx_s1:idx_e1,3);whole_bd(idx_s2:idx_e2,3)]
            mid_angle=all_angles(uint16(xsize_proj*0.5))
            
            %clear statements
            clear xa; clear ya; clear idx_a; clear l_add;
            clear xb; clear yb; clear idx_b; clear l_add; clear l_add2;
            
        end
       
        %clear statements
        clear idx_s1; clear idx_e1; clear idx_s2; clear idx_e2;
        clear idx_frame; clear er_avg_new_tmp; clear er_avg_new;
        clear whole_bd_tmp; clear whole_bd;
         
    end
    
    %iterate counter
    count_final=count_final+1;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Adding the rest of the rows to the projection%%%%%%%%%%%%%%

%counter
count_final=1;

%loading the widest frame
for u=zmin:zmax
    
    %stop at the widest z
    if u~=big_z

        %get the elements from the big slice
        idx_s1=idx_extrema(count_final,1);
        idx_e1=idx_extrema(count_final,2);
        idx_s2=idx_extrema(count_final,3);
        idx_e2=idx_extrema(count_final,4);

        %getting the frame number
        idx_frame=find(list_frames==u);

        %getting the image of the averaged boundary
        er_avg_new_tmp=new_im_arr(idx_frame(1),1);
        er_avg_new=er_avg_new_tmp{1};
        er_avg_new=double(er_avg_new);
        %figure, imagesc(er_avg_new); colormap(gray); colorbar; title(num2str(u));
        
        %getting the theta for the whole boundary
        whole_bd_tmp=cell_ang_avg_bd(count_final,1);
        whole_bd=whole_bd_tmp{1};

        
        if idx_s2==0 && idx_e2==0
            
            xa=whole_bd(idx_s1:idx_e1,1);
            ya=whole_bd(idx_s1:idx_e1,2);
            idx_a=sub2ind(size(er_avg_new),ya,xa);
            
            %doing the alignment
            all_angles=[whole_bd(idx_s1:idx_e1,3)];
            diff_angles=abs(all_angles-mid_angle);
            min_diff=min(diff_angles);
            loc_min=find(diff_angles==min_diff);
            loc_min=double(loc_min);
            
            %load the projection start to middle
            for g=1:mid_of_widest_row
                
                %making index a double
                g=double(g);
               
                clear cr_idx;
                
                %current index in projection
                cr_idx=mid_of_widest_row-g+1;
                
                %adding intensities
                if numel(loc_min)>0 && (loc_min(1)-g+1)>0 %&& (loc_min(1)-g+1)<=numel(idx_a)
                    
                    %current index in list of intensities
                    cr_idx_int=idx_a(loc_min(1)-g+1);

                    %load the projection
                    proj_2d_ret(count_final,cr_idx)=er_avg_new(cr_idx_int);
                    
                    %clear statmeent
                    clear cr_idx_int;
                
                end
                
                %clear statemtn
                clear cr_idx;
                
            end
            
            %load the projection middle to end
            for h=(mid_of_widest_row+1):xsize_proj
                
                %making index a double
                h=double(h);
                
                %adding intensities
                if numel(loc_min)>0 && (loc_min(1)+h-mid_of_widest_row) <= numel(all_angles)
                    
                    %current index in list of intensities
                    cr_idx_int=idx_a(loc_min(1)+h-mid_of_widest_row);
                
                    %load the projection
                    proj_2d_ret(count_final,h)=er_avg_new(cr_idx_int);
                    
                    %clear statmeent
                    clear cr_idx_int;
                    
                end
                
            end
            
            %clear statements
            clear xa; clear ya; clear idx_a;
            clear all_angles; clear diff_angles; clear min_diff; clear loc_min;
            
        else
            
            %section < 360 degrees
            xa=whole_bd(idx_s1:idx_e1,1);
            ya=whole_bd(idx_s1:idx_e1,2);
            idx_a=sub2ind(size(er_avg_new),ya,xa);
            idx_a=double(idx_a);
            
            %section > 0 degrees
            xb=whole_bd(idx_s2:idx_e2,1);
            yb=whole_bd(idx_s2:idx_e2,2);
            idx_b=sub2ind(size(er_avg_new),yb,xb);
            
            %doing the alignment
            if mid_angle <= 360
                
                %doing the alignment
                all_angles=[whole_bd(idx_s1:idx_e1,3)];
                diff_angles=abs(all_angles-mid_angle);
                min_diff=min(diff_angles);
                loc_min=find(diff_angles==min_diff);
                loc_min=double(loc_min);
                
                %load the projection start to middle
                for g=1:mid_of_widest_row
                    
                    %making index a double
                    g=double(g);
                    
                    clear cr_idx;
                    
                    %current index in projection
                    cr_idx=mid_of_widest_row-g+1;
                    
                    %adding intensities
                    if numel(loc_min)>0 && (loc_min(1)-g+1)>0 %&& (loc_min(1)-g+1)<=numel(idx_a)
                        
                        %current index in list of intensities
                        cr_idx_int=idx_a(loc_min(1)-g+1);
                        
                        %for debugging only
%                         if u==zmax
%                             what_is_min=loc_min
%                             what_i_want=loc_min(1)-g+1
%                             cr_idx_int
%                             u
%                             john=100000
%                             g
%                             count_final
%                         end
                        
                        %load the projection
                        proj_2d_ret(count_final,cr_idx)=er_avg_new(cr_idx_int);
                        
                        %clear statmeent
                        clear cr_idx_int;
                        
                    end
                    
                    %clear statemtn
                    clear cr_idx;
                    
                end
                
                %load the projection middle to end
                for h=(mid_of_widest_row+1):xsize_proj
                    
                    %making index double
                    h=double(h);
                    
                    %adding intensities
                    if numel(loc_min)>0 && (loc_min(1)+h-mid_of_widest_row) <= numel(all_angles)
                        
                        %current index in list of intensities
                        cr_idx_int=idx_a(loc_min(1)+h-mid_of_widest_row);
                        
                        %load the projection
                        proj_2d_ret(count_final,h)=er_avg_new(cr_idx_int);
                        
                        %clear statmeent
                        clear cr_idx_int;
                        
                    end
                    
                end
                
                %clear statements
                clear xa; clear ya; clear idx_a;
                clear all_angles; clear diff_angles; clear min_diff; clear loc_min;
                
            else
                
                %doing the alignment
                all_angles=[whole_bd(idx_s2:idx_e2,3)];
                diff_angles=abs(all_angles-mid_angle);
                min_diff=min(diff_angles);
                loc_min=find(diff_angles==min_diff);
                loc_min=double(loc_min);
                
                %load the projection start to middle
                for g=1:mid_of_widest_row

                    %making index a double
                    g=double(g);
                    
                    clear cr_idx;
                    
                    %current index in projection
                    cr_idx=mid_of_widest_row-g+1;
                    
                    %adding intensities
                    if numel(loc_min)>0 && (loc_min(1)-g+1)>0 %&& (loc_min(1)-g+1)<=numel(idx_a)
                        
                        %current index in list of intensities
                        cr_idx_int=idx_b(loc_min(1)-g+1);

                        %load the projection
                        proj_2d_ret(count_final,cr_idx)=er_avg_new(cr_idx_int);
                        
                        %clear statmeent
                        clear cr_idx_int;
                        
                    end
                    
                    %clear statemtn
                    clear cr_idx;
                    
                end
                
                %load the projection middle to end
                for h=(mid_of_widest_row+1):xsize_proj
                    
                    %making index a double
                    h=double(h);
                    
                    %adding intensities
                    if numel(loc_min)>0 && (loc_min(1)+h-mid_of_widest_row) <= numel(all_angles)
                        
                        %current index in list of intensities
                        cr_idx_int=idx_b(loc_min(1)+h-mid_of_widest_row);
                        
                        %load the projection
                        proj_2d_ret(count_final,h)=er_avg_new(cr_idx_int);
                        
                        %clear statmeent
                        clear cr_idx_int;
                        
                    end
                    
                end
                
                %clear statements
                clear all_angles; clear diff_angles; clear min_diff; clear loc_min;
                
            end
            
            
            %clear statements
            clear xa; clear ya; clear idx_a;
            clear xb; clear yb; clear idx_b;
            
        end
        
        %clear statements
        clear idx_s1; clear idx_e1; clear idx_s2; clear idx_e2;
        clear idx_frame; clear er_avg_new_tmp; clear er_avg_new;
        clear whole_bd_tmp; clear whole_bd;
        
    end
    
    %iterate counter
    count_final=count_final+1;
    
end





%figure, imagesc(proj_2d_ret); colormap(gray); colorbar; title('What does this look like?');

































% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %counter
% count_z=1;
% 
% for z=zmin:zmax
%    
%     %getting the frame number
%     idx_frame=find(list_frames==z);
%     
%     %getting the image of the averaged boundary
%     er_avg_new_tmp=new_im_arr(idx_frame(1),1);
%     er_avg_new=er_avg_new_tmp{1};
%     
%     %getting all the coordinates from this slice
%     idx_tay=find(t_kernel(:,3)==z);
%     if numel(idx_tay)>0
%        
%         %draw figure
%         figure, imagesc(er_avg_new); colormap(gray); colorbar; title(num2str(z)); hold on;
%         
%         %get the coordinates
%         xn=t_kernel(idx_tay,1);
%         yn=t_kernel(idx_tay,2);
%         ang_n=t_kernel(idx_tay,4);
%         
%         %plotting the selected points in color
%         for m=1:numel(ang_n)
%            
%             %get an index for the colorbar
%             idx_c=uint16(ang_n(m)*(64/360));
%             if idx_c<1
%                 idx_c=1;
%             end
%             if idx_c>64
%                 idx_c=64;
%             end
%             
%             %plotting
%             plot(xn(m),yn(m),'r+','MarkerEdgeColor',the_map(idx_c,:),'MarkerSize',12,'LineWidth',1.5);
%             
%             %clear statements
%             clear idx_c;
%             
%         end
%         
%         %clear statements
%         clear xn; clear yn; clear ang_n;
%         
%     end
%     
%     
%     %clear statements
%     clear idx_frame; clear frame_num_tmp; clear frame_num;
%     clear er_avg_new_tmp; clear er_avg_new; clear idx_tay;
%     
% end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
