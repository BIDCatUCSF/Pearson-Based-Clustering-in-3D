function[back_lev]=find_backg(in_sq,corx,cory)

%this is background removal primarily based on clustering (kmeans -
%cityblock)

in_sq=double(in_sq);

i_c_t=imcrop(in_sq,[corx,cory,6,6]);
dimm=size(i_c_t,1); dimn=size(i_c_t,2);
IDX=kmeans([i_c_t(1:(dimm*dimn))]',2,'emptyaction','singleton','replicates',5,'start','uniform','distance','cityblock');
IDX_n=reshape(IDX,dimm,dimn);
IDX1=find(IDX_n==1);
IDX2=find(IDX_n==2);

avg_clus1=mean(i_c_t(IDX1));
avg_clus2=mean(i_c_t(IDX2));

[IDX1_nx,IDX1_ny]=ind2sub([dimm,dimn],IDX1);
[IDX2_nx,IDX2_ny]=ind2sub([dimm,dimn],IDX2);

%figure, imagesc(i_c_t); colormap(gray); hold on;

if avg_clus1>avg_clus2
   % plot(IDX1_nx,IDX1_ny,'r+');
   % plot(IDX2_nx,IDX2_ny,'g+');
    back_lev=avg_clus2;
else
    %plot(IDX1_nx,IDX1_ny,'g+');
    %plot(IDX2_nx,IDX2_ny,'r+');
    back_lev=avg_clus1;
end
