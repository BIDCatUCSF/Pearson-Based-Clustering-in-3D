function[bound_sb]=fin_extrema_pts(xc,yc,bound_arr,side_d,idx_curr,zc)

%xc,yc = xy coordinates of pixel at the center of box
%bound_arr = matrix with boundary that I am working on
%side_d = how far in distance to go left and right of center pt.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%move left%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize
dist_left=0;
idx_left=1;

%counter
count_left=1;

while dist_left<=(side_d+1)
    
    %clear statments
    clear idx_left; 
    clear dist_left;
    
   %left index
   idx_left=idx_curr-count_left;
   
   %if you are too close to the start of boundary
   if idx_left<=0
      idx_left_tmp=idx_left;
      clear idx_left;
      idx_left=numel(bound_arr(:,1))+idx_left_tmp;
      clear idx_left_tmp;
   end
   
   %compute distance
   dist_left=(((xc-bound_arr(idx_left,2))^2)+((yc-bound_arr(idx_left,1))^2)).^0.5;
   
   %iterate counter
   count_left=count_left+1;
    
   
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%move right%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize
dist_right=0;
idx_right=1;

%counter
count_right=1;

while dist_right<=(side_d+1)
    
    %clear statements
    clear dist_right; clear idx_right;
    
   %right index
   idx_right=idx_curr+count_right;
   
   %if you pass the end of the boundary
   if idx_right>numel(bound_arr(:,1))
       idx_right_tmp=idx_right;
       clear idx_right;
       idx_right=idx_right_tmp-numel(bound_arr(:,1));
       clear idx_right_tmp
   end
    
   %compute distance
   idx_curr
   idx_right
   dist_right=(((xc-bound_arr(idx_right,2))^2)+((yc-bound_arr(idx_right,1))^2).^0.5); 
   
   %iterate counter
   count_right=count_right+1;
   
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Compute Boundary matrix to return%%%%%%%%%%%%%%%%%%%%%%

if idx_left > idx_right 
    
    bound_sb_tmp(:,1)=bound_arr(idx_left:numel(bound_arr(:,1)),1);
    bound_sb_tmp(:,2)=bound_arr(idx_left:numel(bound_arr(:,1)),2);
    bound_sb_tmp(:,3)=linspace(zc,zc,numel([idx_left:numel(bound_arr(:,1))]))';
    bound_sb_tmp(:,4)=bound_arr(idx_left:numel(bound_arr(:,1)),3);
    
    bound_sb(:,1)=[bound_arr(1:idx_right,1);bound_sb_tmp(:,1)];
    bound_sb(:,2)=[bound_arr(1:idx_right,2);bound_sb_tmp(:,2)];
    bound_sb(:,3)=[linspace(zc,zc,numel([1:idx_right]))';bound_sb_tmp(:,3)];
    bound_sb(:,4)=[bound_arr(1:idx_right,3);bound_sb_tmp(:,4)];
    
    did_it_get_here=1;
    
elseif idx_right > numel(bound_arr(:,1))
    
    bound_sb_tmp(:,1)=bound_arr(1:(idx_right-numel(bound_arr(:,1))),1);
    bound_sb_tmp(:,2)=bound_arr(1:(idx_right-numel(bound_arr(:,1))),2);
    bound_sb_tmp(:,3)=linspace(zc,zc,numel([idx_right-numel(bound_arr(:,1))]))';
    bound_sb_tmp(:,4)=bound_arr(1:(idx_right-numel(bound_arr(:,1))),3);
    
    bound_sb(:,1)=[bound_arr(idx_left:numel(bound_arr(:,1)),1);bound_sb_tmp(:,1)];
    bound_sb(:,2)=[bound_arr(idx_left:numel(bound_arr(:,1)),2);bound_sb_tmp(:,2)];
    bound_sb(:,3)=[linspace(zc,zc,[idx_left:numel(bound_arr(:,1))])';bound_sb_tmp(:,3)];
    bound_sb(:,4)=[bound_arr(idx_left:numel(bound_arr(:,1)),3);bound_sb_tmp(:,4)];
    
    did_it_get_here=2;

else
    
    bound_sb(:,1)=bound_arr(idx_left:idx_right,1);
    bound_sb(:,2)=bound_arr(idx_left:idx_right,2);
    bound_sb(:,3)=linspace(zc,zc,numel([idx_left:idx_right]))';
    bound_sb(:,4)=bound_arr(idx_left:idx_right,3);
    
    did_it_get_here=3;
   

end














