function[im_pc]=inter_cc_step_for_parallel_proc(cell_w_kernels,im_pc,the_idx,path_bd1,n_start1,n_end1,psf_look1,im_t,path_er1)

%grab all of the kernels for a given boundary
kernels_bd_tmp=cell_w_kernels(the_idx,1);
kernels_bd=kernels_bd_tmp{1};

%number of kernels for this z slice
num_kernels=size(kernels_bd,1);

%going through the kernels for boundary (i)
for j=1:num_kernels
    
    %get  a kernel
    k_now_tmp=kernels_bd(j,1);
    k_now=k_now_tmp{1};
    
    %xy coordinates
    x_c_tmp=kernels_bd(j,2);
    y_c_tmp=kernels_bd(j,3);
    x_c=x_c_tmp{1};
    y_c=y_c_tmp{1};
    
    %converting to an index
    idx_c=sub2ind(size(im_t),x_c,y_c);
    
    %create the 2d projection
    [the_2d_thing]=make_2d_projection(k_now,path_er1,path_bd1,n_start1,n_end1);
    
    %center
    dim1t=size(the_2d_thing,1);
    dim2t=size(the_2d_thing,2);
    xc_2=uint16(dim2t*0.5);
    yc_2=uint16(dim1t*0.5);
    
    %debugging
    %         figure, imagesc(the_2d_thing); colormap(gray); colorbar; title('Stop Here!'); hold on;
    %         plot(xc_2,yc_2,'r+');
    
    %get pearson data
    [pc_ret]=get_pearson(psf_look1,the_2d_thing,xc_2,yc_2);
    
    %adding Pearson data to slice
    im_pc(idx_c)=pc_ret;
    
    %clear statements
    clear k_now_tmp; clear k_now; clear x_c; clear x_c_tmp; clear y_c; clear y_c_tmp;
    clear idx_c;clear dim1t; clear dim2t; clear xc_2; clear yc_2;
    clear pc_ret;
    
end