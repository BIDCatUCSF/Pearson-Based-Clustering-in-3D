function[cell_pears_ret]=return_cc_of_tcell_parallel(cell_w_kernels1,path_er,path_bd,n_start,n_end,psf_look)

%This is a function that determines the spatial cross-correlation of
%kernels distributed along the edge of t-cells

%inputs
%cell_w_kernels - cell array(A,2)
%A = # of boundaries (# of z slices)
%cell_w_kernels(a,1) = all kernels for boundary 'a'
%cell_w_kernels(a,2) = slice # (# in z stack)
%path_er = string, path to get eroded boundary images

%getting the image size
im_t1=imread(strcat(path_er,num2str(n_start),'.tif'));

%total number of z slices
num_z=size(cell_w_kernels1,1);

%pre-allocating cell array to hold pearson values
cell_pears_ret=cell(num_z,2);


parfor i=1:num_z

    %creating an image slice that will eventually contain the pixel-wise
    %correlation calculation
    im_pc1=zeros(size(im_t1));
    im_pc1=double(im_pc1);
    
    %The calculation
    [im_pc_ret]=inter_cc_step_for_parallel_proc(cell_w_kernels1,im_pc1,i,path_bd,n_start,n_end,psf_look,im_t1,path_er);
    
    %storing Pearson slice
    cell_pears_ret(i,1)={im_pc_ret};
   

end












