function[cell_pears_ret]=return_cc_of_tcell(cell_w_kernels,path_er,path_bd,n_start,n_end,psf_look)

%This is a function that determines the spatial cross-correlation of
%kernels distributed along the edge of t-cells

%inputs
%cell_w_kernels - cell array(A,2)
%A = # of boundaries (# of z slices)
%cell_w_kernels(a,1) = all kernels for boundary 'a'
%cell_w_kernels(a,2) = slice # (# in z stack)
%path_er = string, path to get eroded boundary images

%getting the image size
im_t=imread(strcat(path_er,num2str(n_start),'.tif'));

%total number of z slices
num_z=size(cell_w_kernels,1);

%pre-allocating cell array to hold pearson values
cell_pears_ret=cell(num_z,2);


for i=1:num_z
   
    %grab all of the kernels for a given boundary
    kernels_bd_tmp=cell_w_kernels(i,1);
    kernels_bd=kernels_bd_tmp{1};
    
    %number of kernels for this z slice
    num_kernels=size(kernels_bd,1);
    
    %creating an image slice that will eventually contain the pixel-wise
    %correlation calculation
    im_pc=zeros(size(im_t));
    im_pc=double(im_pc);
    
    %going through the kernels for boundary (i)
    for j=1:num_kernels
      
        %get  a kernel
        k_now_tmp=kernels_bd(j,1);
        k_now=k_now_tmp{1};
        
        %xy coordinates
        x_c_tmp=kernels_bd(j,2);
        y_c_tmp=kernels_bd(j,3);
        x_c=x_c_tmp{1};
        y_c=y_c_tmp{1};
        
        %converting to an index
        idx_c=sub2ind(size(im_t),y_c,x_c);
        
        %create the 2d projection
        [the_2d_thing]=make_2d_projection_v2(k_now,path_er,path_bd,n_start,n_end);
        
        %center
        dim1t=size(the_2d_thing,1);
        dim2t=size(the_2d_thing,2);
        xc_2=uint16(dim2t*0.5);
        yc_2=uint16(dim1t*0.5);
        
        %debugging
%         figure, imagesc(the_2d_thing); colormap(gray); colorbar; title('Stop Here!'); hold on;
%         plot(xc_2,yc_2,'r+');

        %get pearson data
        [pc_ret]=get_pearson(psf_look,the_2d_thing,xc_2,yc_2);
        
        %adding Pearson data to slice
        im_pc(idx_c)=pc_ret;
        
        %clear statements
        clear k_now_tmp; clear k_now; clear x_c; clear x_c_tmp; clear y_c; clear y_c_tmp;
        clear idx_c;clear dim1t; clear dim2t; clear xc_2; clear yc_2;
        clear pc_ret;
        
    end
    
    %storing Pearson slice
    cell_pears_ret(i,1)={im_pc};
    
    %clear statements
    clear kernels_bd_tmp; clear kernels_bd;
    clear num_kernels;

end












