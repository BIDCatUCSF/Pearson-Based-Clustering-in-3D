function[big_im_return]=add_cc_to_image(tile,big_im,xe,ye)

%dimensions of the tile
dimA=size(tile,1);
dimB=size(tile,2);

%making a blank image at the size of the cross correlation matrix
big_im_new=zeros(size(big_im));
big_im_new=double(big_im_new);

for x=1:dimA
    for y=1:dimB
        
       big_im_new(xe+x-1,ye+y-1)=tile(x,y);
        
        
    end 
end


%image to return
big_im_return=big_im_new+big_im;




































