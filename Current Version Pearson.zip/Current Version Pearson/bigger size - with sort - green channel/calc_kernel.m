function[row_return]=calc_kernel(cell_arr,ang_curr,box_size,z_curr,x_cent,y_cent,zmin)

%cell_arr = cell array containing the boundaries that will be in kernel
%ang_curr = angle (degrees) of current point around which kernel will be
%           made
%box_size = size of box (i.e. box dimensions are (box_size x box_size)
%z_curr = current z plane

%output will be a list of coordinates to plot

%levels
side_dist=uint16((box_size-1)*0.5);
side_dist=double(side_dist)

%counter
count=1;

for i=1:box_size
    
   %grab boundary (top to bottom) 
   bound_n_tmp=cell_arr(i,1);
   bound_n=bound_n_tmp{1};
   bound_n=double(bound_n);
   
   %finding the center point
   min_idx=find_start_pt(bound_n,ang_curr);

   %local counter
   count_loc=1;

   %getting a row
   for j=1:box_size
       
       %you will pass the end of the boundary before you finish searching
       if (min_idx(1)+box_size) > numel(bound_n(:,1)) 
       
           %going to the start of the boundary
           new_thing=(min_idx(1)+j-side_dist-1)-numel(bound_n(:,1));
           
           if new_thing<=0
               
               row_tmp(count_loc,1)=bound_n(min_idx(1)+j-side_dist-1,1); %x
               row_tmp(count_loc,2)=bound_n(min_idx(1)+j-side_dist-1,2); %y
               row_tmp(count_loc,3)=z_curr-side_dist+i-1;%z
           
           else
               
               row_tmp(count_loc,1)=bound_n(new_thing,1); %x
               row_tmp(count_loc,2)=bound_n(new_thing,2); %y
               row_tmp(count_loc,3)=z_curr-side_dist+i-1;%z
           
           end
           
           %clear statement
           clear new_thing;
           
        %you are the near the start of the stack
       elseif (min_idx(1)+j-side_dist-1)<=0
           
           %counting backwards
           idx_use=(numel(bound_n(:,1)))+(min_idx(1)+j-side_dist-1);
           
           row_tmp(count_loc,1)=bound_n(idx_use,1); %x
           row_tmp(count_loc,2)=bound_n(idx_use,2); %y
           row_tmp(count_loc,3)=z_curr-side_dist+i-1;%z
           
           %clear statement
           clear idx_use;
           
       else
           
           row_tmp(count_loc,1)=bound_n(min_idx(1)+j-side_dist-1,1); %x
           row_tmp(count_loc,2)=bound_n(min_idx(1)+j-side_dist-1,2); %y
           row_tmp(count_loc,3)=z_curr-side_dist+i-1;%z
       
       end
       
       %iterate counter
       count_loc=count_loc+1;
       
   end
   
   
   %storing all coordinates
   if count==1
       row_return=row_tmp;
   else
       row_return_tmp=row_return;
       clear row_return;
       row_return=[row_return_tmp;row_tmp];
       clear row_return_tmp;
   end
   
   %iterate counter
   count=count+1;
    
   %clear statements
   clear bound_n_tmp; clear bound_n;
   clear dist_arr; clear min_dist; clear min_idx;
   clear row_tmp;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%screening to limit xy range of the coordinates returned%%%%%%%%%%%%%

%the limits
xlow=x_cent-side_dist
xhigh=x_cent+side_dist
ylow=y_cent-side_dist
yhigh=y_cent+side_dist


idx_x_low=find(row_return(:,2)<xlow);
if numel(idx_x_low)>0
    row_return(idx_x_low,:)=[];
end

idx_x_high=find(row_return(:,2)>xhigh);
if numel(idx_x_high)>0
    row_return(idx_x_high,:)=[];
end

idx_y_low=find(row_return(:,1)<ylow);
if numel(idx_y_low)>0
    row_return(idx_y_low,:)=[];
end

idx_y_high=find(row_return(:,1)>yhigh);
if numel(idx_y_high)>0
    row_return(idx_y_high,:)=[];
end


row_return




