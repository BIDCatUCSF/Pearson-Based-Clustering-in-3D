function[PSF]=make_PSf(width1,amplitude1)

%making doubles
width1=double(width1);
amplitude1=double(amplitude1);

%render a 2D gaussian
PSF=fspecial('gaussian',width1,10);

%rescaling
dim1=size(PSF,1);
dim2=size(PSF,2);
min_P=min(PSF(1:(dim1*dim2)));
max_P=max(PSF(1:(dim1*dim2)));
PSF=PSF-min_P;
PSF=PSF.*(amplitude1/(max_P-min_P));
%figure, imagesc(PSF); colormap(gray); colorbar;