%  function[ret_idx]=find_start_pt(bound_in,xs,ys)
%  
%  %make everything double
%  xs=double(xs);
%  ys=double(ys);
%  bound_in=double(bound_in);
%  
%  %some distance calculation
%  dist_c=(((bound_in(:,2)-xs).^2)+((bound_in(:,1)-ys).^2));
%  min_d=min(dist_c);
%  ret_idx_tmp=find(dist_c==min_d);
%  ret_idx=ret_idx_tmp(1);
 


function[ret_idx]=find_start_pt(bound_in,ang_s)

%looking through the angles
idx_find=find(bound_in(:,3)>=ang_s);

if numel(idx_find)>0
    ret_idx=idx_find(1);
else
    ret_idx=numel(bound_in(:,1));
end
    




































