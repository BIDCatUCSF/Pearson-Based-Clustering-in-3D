clear all; close all;

%render a 2D gaussian
PSF=fspecial('gaussian',7,10);

%rescaling
dim1=size(PSF,1);
dim2=size(PSF,2);
min_P=min(PSF(1:(dim1*dim2)));
max_P=max(PSF(1:(dim1*dim2)));
PSF=PSF-min_P;
PSF=PSF.*(100/(max_P-min_P));
figure, imagesc(PSF); colormap(gray); colorbar;

%larger PSF for test
large_PSF=fspecial('gaussian',20,10);
dim1a=size(large_PSF,1);
dim2a=size(large_PSF,2);
min_l=min(large_PSF(1:(dim1a*dim2a)));
max_l=max(large_PSF(1:(dim1a*dim2a)));
large_PSF=large_PSF-min_l;
max_l=max_l-min_l;
large_PSF=large_PSF.*(100/max_l);

figure, imagesc(large_PSF); colormap(gray); colorbar;



%making a large image of PSFs
large_ims=zeros(100,100);
pos_list=[20,20
   37,37
    60,60];

% for i=1:2
%     for j=1:dim1
%         for k=1:dim2
%             if i==2
%                 large_ims(pos_list(i,1)+j-4,pos_list(i,2)+k-4)=PSF(j,k).*0.2;
%             else
%                 large_ims(pos_list(i,1)+j-4,pos_list(i,2)+k-4)=PSF(j,k)*1;
%             end
%         end
%     end
% end

for r=3:3
   
    for s=1:dim1a
        for t=1:dim2a
            
            large_ims(pos_list(r,1)+t,pos_list(r,2)+s)=large_PSF(t,s).*1;
            
        end
    end
    
end

figure, imagesc(large_ims); colormap(gray); colorbar;

%do the cross correlation

%create cross correlation image
im_cc=zeros(size(large_ims));
im_cc=double(im_cc);

%dimension of the large images
dim1a=size(large_ims,1);
dim2a=size(large_ims,2);

%PSF for cross corellation
% PSF_cc=PSF./100;

%counter
count=1;

for r=1:dim1a
    for s=1:dim2a
        
       %cropping
       icrop=imcrop(large_ims,[r,s,dim1-1,dim2-1]);
       
       %cross correlation calculation
       if size(icrop,1)==dim1 && size(icrop,2)==dim2
 
           %scaling PSF
           max_crop=max(icrop(1:(dim1*dim2)));
           PSF_use=PSF./100;
           
           %cross correlation
           [corr] = CrossCorrelation(icrop,PSF_use);
           
           %making the matrix
           if count==1
            [im_cc_ret]=add_cc_to_image(corr,im_cc,r,s);
           else
               im_cc_ret_tmp=im_cc_ret;
               clear im_cc_ret;
               [im_cc_ret]=add_cc_to_image(corr,im_cc_ret_tmp,r,s);
               clear im_cc_ret_tmp;
           end
           
           %iterate counter
           count=count+1;

           
           %clear statements
           clear corr; clear max_cc; clear idx_max_cc; clear ycc_tmp; clear xcc_tmp;
           clear PSF_use; clear max_crop;
           
       end
        
       %clear statements
       clear icrop;
       
    end 
end

figure, surf(im_cc_ret); shading interp; axis tight; colormap(jet); colorbar; title('CC sum');
figure, imagesc(im_cc_ret); colormap(jet); colorbar; title('CC sum');


%arrays for fitting
count_fit=1;
for r=1:size(im_cc_ret,1)
    
    for s=1:size(im_cc_ret,2)
       
        xfit(count_fit,1)=r;
        yfit(count_fit,1)=s;
        
        count_fit=count_fit+1;
        
    end
   
    
end
idx_fit=sub2ind(size(im_cc_ret),yfit,xfit);
zfit=im_cc_ret(idx_fit);





































