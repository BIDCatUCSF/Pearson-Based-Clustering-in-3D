clear all; %close all;

%render a 2D gaussian
PSF=fspecial('gaussian',8,10);

%rescaling
dim1=size(PSF,1);
dim2=size(PSF,2);
min_P=min(PSF(1:(dim1*dim2)));
max_P=max(PSF(1:(dim1*dim2)));
PSF=PSF-min_P;
PSF=PSF.*(100/(max_P-min_P));
figure, imagesc(PSF); colormap(gray); colorbar;