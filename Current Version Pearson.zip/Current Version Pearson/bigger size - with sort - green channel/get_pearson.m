function[pc_ret]=get_pearson(psf_p,c_im_keep,xc2,yc2)

%inputs
% psf_p = user-defined object that you are looking for
% c_im_keep = 2d projection 
% xc2 = x center of 2d projection
% yc2 = y center of 2d projection

%outputs
%pc_ret = Pearsons value for that point on boundary

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%dimensions of psf
wid_p=size(psf_p,1);
    
%cropping
cc_crop=imcrop(c_im_keep,[xc2-(0.5*wid_p),yc2-(0.5*wid_p),wid_p-1,wid_p-1]);

%seeing if the cropped image and psf image are the same size
dim1p=size(psf_p,1);
dim2p=size(psf_p,2);
dim1c=size(cc_crop,1);
dim2c=size(cc_crop,2);
            
if dim1p==dim1c && dim2p==dim2c
    %removing background
    back_sig1=find_backg(psf_p,2,2);
    back_sig2=find_backg(cc_crop,2,2);
    
    %calculating Pearsons coefficient
    [pc_ret]=calc_coloc(psf_p,cc_crop,back_sig1,back_sig2); 
else
    pc_ret=0;
end

    
            


