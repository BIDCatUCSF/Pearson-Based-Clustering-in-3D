function[PSF]=create_psf(width_psf,height_psf)

%render a 2D gaussian
PSF=fspecial('gaussian',width_psf,10);

%rescaling
dim1=size(PSF,1);
dim2=size(PSF,2);
min_P=min(PSF(1:(dim1*dim2)));
max_P=max(PSF(1:(dim1*dim2)));
PSF=PSF-min_P;
PSF=PSF.*(height_psf/(max_P-min_P));


%For debugging only
%figure, imagesc(PSF); colormap(gray); colorbar;