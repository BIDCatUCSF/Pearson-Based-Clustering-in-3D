function[pc_ret]=calc_coloc(im1,im2,g_avg,r_avg)

%casting as double
im1=double(im1);
im2=double(im2);

%size of image
dim1=size(im1,1);
dim2=size(im1,2);

%average intensities
% g_avg=mean(im1(1:(dim1*dim2)));
% r_avg=mean(im2(1:(dim1*dim2)));
g_avg=double(g_avg);
r_avg=double(r_avg);

%pre-allocating for speed
num_sum=zeros((dim1*dim2),1);
den_sum1=zeros((dim1*dim2),1);
den_sum2=zeros((dim1*dim2),1);
num_sum=double(num_sum);
den_sum1=double(den_sum1);
den_sum2=double(den_sum2);


for i=1:(dim1*dim2)
    
    %numerator
    num_sum(i,1)=((im1(i)-g_avg)*(im2(i)-r_avg));
    
    %denominator
    den_sum1(i,1)=((im1(i)-g_avg)*(im1(i)-g_avg));
    den_sum2(i,1)=((im2(i)-r_avg)*(im2(i)-r_avg));
    
end

pc_ret=(sum(num_sum(:,1)))/(((sum(den_sum1(:,1)))*(sum(den_sum2(:,1))))^0.5);


