clear all; close all;

%render a 2D gaussian
PSF=fspecial('gaussian',10,10);

%rescaling
dim1=size(PSF,1);
dim2=size(PSF,2);
min_P=min(PSF(1:(dim1*dim2)));
max_P=max(PSF(1:(dim1*dim2)));
PSF=PSF-min_P;
PSF=PSF.*(100/(max_P-min_P));
figure, imagesc(PSF); colormap(gray); colorbar;

%larger PSF for test
large_PSF=fspecial('gaussian',10,10);
dim1a=size(large_PSF,1);
dim2a=size(large_PSF,2);
min_l=min(large_PSF(1:(dim1a*dim2a)));
max_l=max(large_PSF(1:(dim1a*dim2a)));
large_PSF=large_PSF-min_l;
max_l=max_l-min_l;
large_PSF=large_PSF.*(100/max_l);

figure, imagesc(large_PSF); colormap(gray); colorbar;



%making a large image of PSFs
large_ims1=zeros(100,100);
large_ims2=zeros(100,100);
pos_list=[20,20
   50,50
    60,60];

for i=2:3
    for j=1:dim1
        for k=1:dim2
            if i==2
                large_ims1(pos_list(i,1)+k,pos_list(i,2)+j)=PSF(j,k).*1;
            else
                large_ims1(pos_list(i,1)+k,pos_list(i,2)+j)=PSF(j,k)*1;
            end
        end
    end
end

for r=3:3
   
    for s=1:dim1a
        for t=1:dim2a
            
            large_ims2(pos_list(r,1)+t,pos_list(r,2)+s)=large_PSF(t,s).*1;
            
        end
    end
    
end

%adding some background to image 1
idx_bk1=find(large_ims1==0);
% large_ims1(idx_bk1)=35;

figure, imagesc(large_ims1); colormap(gray); colorbar;
figure, imagesc(large_ims2); colormap(gray); colorbar;

%Pearsons calculation

%removing background
back_sig1=find_backg(large_ims1,2,2)
back_sig2=find_backg(large_ims2,2,2)

%calculating Pearsons coefficient
[pc_ret]=calc_coloc(large_ims1,large_ims2,back_sig1,back_sig2)








































