function[row_return,c_check_save]=calc_kernel_v2(cell_arr,ang_curr,box_size,z_curr,x_cent,y_cent,zmin)

%cell_arr = cell array containing the boundaries that will be in kernel
%ang_curr = angle (degrees) of current point around which kernel will be
%           made
%box_size = size of box (i.e. box dimensions are (box_size x box_size)
%z_curr = current z plane

%output will be a list of coordinates to plot

%levels
side_dist=uint16((box_size-1)*0.5);
side_dist=double(side_dist)

%counter
count=1;

%counter for debugging
count_debug=1;

%counting through the z planes
for i=1:box_size
    
   %grab boundary (top to bottom) 
   bound_n_tmp=cell_arr(i,1);
   bound_n=bound_n_tmp{1};
   bound_n=double(bound_n);
   
   %finding the center point
   min_idx=find_start_pt(bound_n,ang_curr);

   %getting a row -> min_idx=middle 
   x_curr=bound_n(min_idx(1),2);
   y_curr=bound_n(min_idx(1),1);
   
   if count_debug==1
       c_check_save(count_debug,1)=x_curr;
       c_check_save(count_debug,2)=y_curr;
       count_debug=count_debug+1;
   end
   

   %get the boundary
   [row_tmp]=fin_extrema_pts(x_curr,y_curr,bound_n,side_dist,min_idx,(z_curr+i-side_dist-1));
   
   %storing all coordinates
   if count==1
       row_return=row_tmp;
   else
       row_return_tmp=row_return;
       clear row_return;
       row_return=[row_return_tmp;row_tmp];
       clear row_return_tmp;
   end
   
   %iterate counter
   count=count+1;
    
   %clear statements
   clear bound_n_tmp; clear bound_n;
   clear min_idx; clear x_curr; clear y_curr;
   clear row_tmp; 
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%screening to limit xy range of the coordinates returned%%%%%%%%%%%%%

% %the limits
% xlow=c_check_save(1,1)-side_dist
% xhigh=c_check_save(1,1)+side_dist
% ylow=y_cent-side_dist
% yhigh=y_cent+side_dist
% % 
% % 
%  idx_x_low=find(row_return(:,2)<xlow);
% if numel(idx_x_low)>0
%     row_return(idx_x_low,:)=[];
% end
% 
% idx_x_high=find(row_return(:,2)>xhigh);
% if numel(idx_x_high)>0
%     row_return(idx_x_high,:)=[];
% end
% 
% idx_y_low=find(row_return(:,1)<ylow);
% if numel(idx_y_low)>0
%     row_return(idx_y_low,:)=[];
% end
% 
% idx_y_high=find(row_return(:,1)>yhigh);
% if numel(idx_y_high)>0
%     row_return(idx_y_high,:)=[];
% end
% 
% 
% if numel(row_return)==1
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
%     did_it_get_here=10000
% end




