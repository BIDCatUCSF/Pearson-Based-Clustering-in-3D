clear all; close all;

%file and path information for boundaries
path_b='D:\JohnE\TCR_CD28_20200730\ROI17\488nm\The_Boundaries\Bound';

%path to eroded boundary images
path_erode='D:\JohnE\TCR_CD28_20200730\ROI17\488nm\ErodedBoundaryImages\MaskBoundErode';

%file indices
ns_tmp=40;
ne_tmp=91;

%colormap
the_map=colormap(jet);
close all;

%pick box size and please use odd number
size_box=9;

%modifying to accommodate box size
ns=ns_tmp+5;
ne=ne_tmp-5;

%cell array to hold kermels for all the boundaries
cell_all_kernels=cell(ne-ns+1,2);
%cell_all_kernels=cell(3,2);

%levels up and down to go
vert_dist=uint16((size_box-1)*0.5);
vert_dist=double(vert_dist);

%counter
count_all=1;

for i=ns:ne

    i
    
    %grab the boundary and put them into a cell array
    cell_bound=cell(size_box,1);
    
    %read in the boundary of interest
    bound_now_tmp=load(strcat(path_b,num2str(i),'.mat'));
    bound_now=bound_now_tmp.boundary_out;
    bound_now(:,3)=bound_now(:,3).*(180/pi);
    
    %some sorting by angle
    bound_now_tmp=bound_now;
    clear bound_now;
    bound_now=sortrows(bound_now_tmp,3);
 
    %declaring cell array to hold kernels
    cell_kernel=cell(numel(bound_now(:,1)),3);
    cell_check=cell(numel(bound_now(:,1)),1);

    %load the other boundaries
    for k=1:size_box
        
        %grab the boundary
        bound_tmp=load(strcat(path_b,num2str(i-vert_dist+k-1),'.mat'));
        bound=bound_tmp.boundary_out;
        
        %keeping track of z
        z_track_keep(k,1)=i-vert_dist+k-1;
        
        %putting everything in degreesk
        bound(:,3)=bound(:,3)*(180/pi);
        
        %load into cell arrayjjj
        cell_bound(k,1)={bound};
        
        %clear statements
        clear bound_tmp; clear bound;
        
    end
    
    
    for j=1:numel(bound_now(:,1))
        
        %get x,y,theta coordinate
        x_center=bound_now(j,2);
        y_center=bound_now(j,1);
        ang_center=bound_now(j,3);
       

        %calculate kernel
        [row_return,check_ash]=calc_kernel_v2(cell_bound,ang_center,size_box,i,x_center,y_center,ns);
        
        %some debugging
%         if j==31
%             figure, hold on; title('Does this work');
%             plot3(row_return(:,1),row_return(:,2),row_return(:,3),'ko','MarkerSize',12,'LineWidth',1.5);
%         end
        
        %storing the kernel thing and the coordinates of central position
        cell_kernel(j,1)={row_return};
        cell_kernel(j,2)={x_center};
        cell_kernel(j,3)={y_center};
    
        
        %storing the initial search coordinates
        cell_check(j,1)={check_ash};
        
        %clear statements
        clear x_center; clear y_center; clear ang_center; 

    end
    
    %storing the the kernels for this boundary in the master cell array
    cell_all_kernels(count_all,1)={cell_kernel};
    cell_all_kernels(count_all,2)={i}; %image index
    
    %iterate counter
    count_all=count_all+1;
    
    %I did this during the debugging stage
    cell_bound_keep=cell_bound;
    
    %clear statements
    clear cell_bound;  clear cell_check;
    clear bound_now_tmp; clear bound_now;
    clear cell_kernel;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%user-defined object you are looking for%%%%%%%%%%%%%%%%%%%%%%%

%get psf - gaussian shape - assuming this is what you want
wid_psf=5;
amp_psf=1000;
psf_now_tmp=make_PSf(wid_psf,amp_psf);

%adding a frame around the psf
[psf_now]=add_frame_around_psf(psf_now_tmp);

figure,imagesc(psf_now); colormap(gray); colorbar;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Pearson Correlation Calcaultion%%%%%%%%%%%%%%%%%%%%

%Pearson Calculation
[cell_w_pears_data]=return_cc_of_tcell_parallel(cell_all_kernels,path_erode,path_b,ns_tmp,ne_tmp,psf_now);

%directory for saving
dir_save='D:\JohnE\TCR_CD28_20200730\ROI17\488nm\medium size - with sort - green channel\Pearson Slices\im';

%saving the slices with Pearson data
num_slices_save=size(cell_w_pears_data,1);

for b=1:num_slices_save
    
    %getting images from cell array
    slice_save_tmp=cell_w_pears_data(b,1);
    slice_save=slice_save_tmp{1};
    
    %scaling
    slice_save=double(slice_save);
    slice_save=slice_save.*100;
    
    %saving
    imwrite(uint16(slice_save),strcat(dir_save,num2str(b),'.tif'));
    
    %clear statements
    clear slice_save_tmp; clear slice_save; 
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%making plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% %counter
% count_morgan=0;
% count_display=1;
% 
% for r=1:j
%     
%    %get a set of coordinates of kernel
%    set_c_tmp=cell_kernel(r,1);
%    set_c=set_c_tmp{1};
%    
%    %set of initial search postions
% %    init_coords_tmp=cell_check(r,1);
% %    init_coords=init_coords_tmp{1};
%    
%    if numel(set_c)==0
%        count_morgan=count_morgan+1;
%    end
%    
%    
%    %figure
%    if r==1
%        figure, hold on;
%    end
%    
%    %plotting
%    c_idx=uint16(r*(64/j));
%    
%    if c_idx<1
%        c_idx=1;
%    elseif c_idx>64
%        c_idx=64;
%    end
%    
%    if count_display==80
%        %plot3(set_c(:,1),set_c(:,2),set_c(:,3),'ro','MarkerSize',12,'MarkerEdgeColor',the_map(c_idx,:),'LineWidth',1.5);
%        plot3(set_c(:,1),set_c(:,2),set_c(:,3),'ro','MarkerSize',12,'LineWidth',1.5);
%    elseif count_display==88
%        plot3(set_c(:,1),set_c(:,2),set_c(:,3),'yo','MarkerSize',12,'LineWidth',1.5);
%    elseif count_display==98
%        plot3(set_c(:,1),set_c(:,2),set_c(:,3),'go','MarkerSize',12,'LineWidth',1.5);
%    elseif count_display==108
%        plot3(set_c(:,1),set_c(:,2),set_c(:,3),'co','MarkerSize',12,'LineWidth',1.5);
%    elseif count_display==188
%        plot3(set_c(:,1),set_c(:,2),set_c(:,3),'mo','MarkerSize',12,'LineWidth',1.5);
%    end
%    %plot3(init_coords(1,2),init_coords(1,1),50,'rx','MarkerSize',14,'MarkerEdgeColor',the_map(c_idx,:),'LineWidth',1.5);
%    
%    %iterate display counter
%    count_display=count_display+1;
%    
%    %clear statements
%    clear set_c_tmp; clear set_c; clear c_idx;
%    clear init_coords_tmp; clear init_coords;
%     
%     
% end
% 
% count_morgan
% 
% %plotting the actual boundarys
% for k=1:size_box
%    
%     bd_tmp=cell_bound_keep(k,1);
%     bd=bd_tmp{1};
%     
%     %z array for plotting
%     z_plot=linspace(z_track_keep(k,1),z_track_keep(k,1),numel(bd(:,1)));
%     
%     %plots
%     plot3(bd(:,1),bd(:,2),z_plot,'k-','LineWidth',0.5);
%     
%     %clear statements
%     clear bd_tmp; clear bd;clear z_plot;
%     
% end





















