function[in1_ret_final]=corners_test_func(in1)

%intializing output
in1_ret_final=in1;

%get the corners
N=360;
theta=linspace(0,360,N);
I=in1(:,1);
J=in1(:,2);
IJ=[I,J];
c=nan(size(theta));
for i=1:N
   
    [~,c(i)]=max(IJ*[cosd(theta(i));sind(theta(i))]);
    
    
end
H=histcounts(c,1:numel(I)+1);
[~,k] = maxk(H,4);
corners=IJ(k,:)

%plot the corners
% for i=1:numel(corners(:,1))
%     plot(corners(i,1),corners(i,2),'r+');
% end

%find the corners with the lowest y
sort_corners=sortrows(corners,2);
% plot(sort_corners(1,1),sort_corners(1,2),'go');
% plot(sort_corners(2,1),sort_corners(2,2),'go');

%figuring out the angle
ang_tmp=atan(abs(sort_corners(1,2)-sort_corners(2,2))/abs(sort_corners(1,1)-sort_corners(2,1)));
R = [cos(ang_tmp) -sin(ang_tmp); sin(ang_tmp) cos(ang_tmp)];

%rotating
for i=1:numel(in1(:,1))
    thing_rot=R*[in1(i,2);in1(i,1)];
    in1_ret(i,1)=thing_rot(1);
    in1_ret(i,2)=thing_rot(2);
    clear thing_rot;
    
end

%making output
in1_ret_final(:,1)=in1_ret(:,1);
in1_ret_final(:,2)=in1_ret(:,2);



% figure, hold on; plot(in1_ret(:,1),in1_ret(:,2),'k+');















