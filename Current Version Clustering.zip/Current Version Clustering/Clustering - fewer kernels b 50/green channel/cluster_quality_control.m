function[in_arr_ret]=cluster_quality_control(in_arr,im_test)

%This is a function that deals with the case of clusters that overlap but
%overlap with percentages smaller that what set in previous threshold

% in_arr(:,1) = x coordinates of clusters
% in_arr(:,2) = y coordinates of clusters
% in_arr(:,3) = z coordinates of clusters
% in_arr(:,4) = cluster number
%im_test = pearson image used for final quality control step

%making double
in_arr=double(in_arr);

%generally removing duplicate entries in inputted array to start
in_arr = unique(in_arr,'rows');

%making a copy
in_arr_ret=in_arr;

%adding a column to mark for deletion
in_arr(:,5)=linspace(0,0,numel(in_arr(:,4)))';

for i=1:numel(in_arr(:,1))
    
   %grab a pixel and info
   xn=in_arr(i,1);
   yn=in_arr(i,2);
   zn=in_arr(i,3);
   cn=in_arr(i,4);
   dn=in_arr(i,5);
   
   if dn<1
       
       %distance calculation
       dist_arr=(((xn-in_arr(:,1)).^2)+((yn-in_arr(:,2)).^2)+((zn-in_arr(:,3)).^2)).^0.5;
       
       %too close
       idx_too_close=find(dist_arr==0);
       
       if numel(idx_too_close)>0
           
           for j=1:numel(idx_too_close)
              
               if (in_arr(idx_too_close(j),4)~=cn) && (idx_too_close(j)~=i)
                  
                   in_arr(idx_too_close(j),5)=1;
                   
               end
               
           end
           
       end
       
       %clear statements
       clear idx_too_close; clear dist_arr;
       
   end
    
   %clear statements
   clear xn; clear yn; clear zn;
   clear cn; clear dn;
    
end

%some deletions
idx_go=find(in_arr(:,5)==1);
if numel(idx_go)>0
    in_arr_ret(idx_go,:)=[];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%removing small(spurious clusters)%%%%%%%%%%%%%%%%%%%

%cluster extrema
min_c3=min(in_arr_ret(:,4));
max_c3=max(in_arr_ret(:,4));

%make a copy
in_arr_ret_final=in_arr_ret;

%adding a 5th column
in_arr_ret_final(:,5)=linspace(0,0,numel(in_arr_ret(:,4)))';

for w=min_c3:max_c3
   
    %grab a cluster
    idx_c=find(in_arr_ret(:,4)==w);
    
    if numel(idx_c)>0
        
        %grab coordinates
        xc=in_arr_ret(idx_c,1);
        yc=in_arr_ret(idx_c,2);
        zc=in_arr_ret(idx_c,3);
        cp=in_arr_ret(idx_c,4);
        list_send=[xc,yc,zc];
        
        %spatial clustering
        [class_now,type_now]=dbscan_conservative(list_send,5,4);
        clust_class=class_now';
        
        %high cluster
        high_clust=max(clust_class(:,1));
        
        %there are more than one cluster found 
        if high_clust>1
            
            %area counter
            counter_area=1;
            
            %get area
            for q=1:high_clust
                idx_jor=find(clust_class==q);
                area_arr(counter_area,1)=numel(idx_jor);
                area_arr(counter_area,2)=q;
                counter_area=counter_area+1;
                clear idx_jor;
            end
            
            %sort by area
            idx_small=find(area_arr(:,1)<10);
            
            %mark small clusters for removal
            if numel(idx_small)>0
                
                %cluster index for small cluster
                for b=1:numel(idx_small)
                    
                    %dbscan cluster indices for small cluster
                    clust_idx_small=area_arr(idx_small(b),2);
                    
                    %yet another index
                    idx_another=find(clust_class==clust_idx_small);
                    
                    %marking these clusters for deletion
                    in_arr_ret_final(idx_c(idx_another),5)=1;
                    
                    %clear statements
                    clear clust_idx_small; clear idx_another;
                    
                end
               
                
            end
            
            %clear statements
            clear area_arr; clear idx_small;
            
        end
        
        %clear statements
        clear xc; clear yc; clear zc; clear cp; clear list_send;
        clear class_now; clear type_now; clear clust_class;
        clear high_clust;
        
    end
    
    %clear statements
    clear idx_c;
    
end

%making the return argument
idx_get_rid_of=find(in_arr_ret_final(:,5)==1);

%removing the spuious clusters
if numel(idx_get_rid_of)>0
   in_arr_ret(idx_get_rid_of,:)=[]; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%going through once more and removing small clusters%%%%%%%%%%%%%%%%%

%cluster extrema
min_c_final=min(in_arr_ret(:,4));
max_c_final=max(in_arr_ret(:,4));

for v=min_c_final:max_c_final
   
    %get cluster
    idx_last=find(in_arr_ret(:,4)==v);
    
    if numel(idx_last)>0
        if numel(idx_last)<8
           in_arr_ret(idx_last,:)=[];
        end
    end
    
    %clear statement
    clear idx_last;
    
end

%some debugging
hi=9999

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%removing spurious points%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%These are points in clusters which are off on their own%%%%%%%%%%%%%%%%%

for v=min_c_final:max_c_final
    
    %get cluster
    idx_s=find(in_arr_ret(:,4)==v);
    
    %is there a cluster
    if numel(idx_s)>0
       
        %get the xyz coordinates
        xs=in_arr_ret(idx_s,1);
        ys=in_arr_ret(idx_s,2);
        zs=in_arr_ret(idx_s,3);
        is_it_alone=zeros(numel(idx_s),1);
        
        %go through each coordinate
        %see how many nearest neighbors it has
        for r=1:numel(xs)
            
            %find distances
            dist_now=((xs(r)-xs).^2)+((ys(r)-ys).^2)+((zs(r)-zs).^2);
            
            %make an integer matrix
            dist_now=uint16(dist_now);
            
            %look for nearest neighbors
            idx_nn=find(dist_now==1);
            
            %remove if voxel is off by itself - no nearest neoighbors
            if numel(idx_nn)==0
                is_it_alone(idx_nn,1)=1;
            end
            
            %clear statements
            clear dist_now; clear idx_nn;
            
        end
        
        %remove pixels from matrix to return
        %are there pixels to remove
        idx_lose=find(is_it_alone==1);
        if numel(idx_lose)>0
            in_arr_ret(idx_s(idx_lose),:)=[];
        end
        
        %clear statements
        clear xs; clear ys; clear zs; clear is_it_alone;
        clear idx_lose;
        
    end
    
    %clear statement
    clear idx_s;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%Making sure that I am removing the small clustering elements using%%%%
%%%%dbscan%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%getting dimensions of image
dimE=size(im_test,1);
dimC=size(im_test,2);
if dimE<=dimC
    dimU=dimE;
else
    dimU=dimC;
end

%dor debugging
close all;

%go through each cluster
for b=min_c_final:max_c_final
    
    %look for a cluster
    idx_b=find(in_arr_ret(:,4)==b);
    
    if numel(idx_b)>0
        
        %making coordinate list
        list_to_cluster=[in_arr_ret(idx_b,1),in_arr_ret(idx_b,2),in_arr_ret(idx_b,3)];
        
        %doing the spatial clustering
        [class_now,type_now]=dbscan_conservative(list_to_cluster,2,3);
        
        %are there multiple density clusters
        min_d=min(class_now);
        max_d=max(class_now);
        if abs(min_d-max_d)>0
            mul_c=1;
        else
            mul_c=0;
        end
        
        %deciding what to do with multiple clusters
        if mul_c==1
            %get the size of each cluster
            for h=min_d:max_d
                idx_t=find(class_now==h);
                if numel(idx_t)<4
                    in_arr_ret(idx_b(idx_t),:)=[];
                end
                clear idx_t;
            end
        end
        
        %clear statements
        clear list_to_cluster; clear class_now; clear type_now;
        clear idx_too_small;
        
    end

    %clear statemetns
    clear idx_b;
    
end




























%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%Some plots for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%


% figure, hold on; title('Should be Green');
% plot3(in_arr(:,1),in_arr(:,2),in_arr(:,3),'r+','MarkerSize',12,'LineWidth',1.5);
% 
% %figure, hold on; title('No Overlap Data');
% plot3(in_arr_ret(:,1),in_arr_ret(:,2),in_arr_ret(:,3),'g+','MarkerSize',12,'LineWidth',1.5);
% 
% %some additional sanity checks
% figure, hold on; title('Should be red');
% 
% for a=1:numel(in_arr_ret(:,1))
%    
%     %grab a coordinate 
%     xs=in_arr_ret(a,1);
%     ys=in_arr_ret(a,2);
%     zs=in_arr_ret(a,3);
%     
%     %plotting
%     plot3(xs,ys,zs,'r+','MarkerSize',12,'LineWidth',1.5);
%     
%     %distance calculation
%     dist_test=(((in_arr_ret(:,1)-xs).^2)+((in_arr_ret(:,2)-ys).^2)+((in_arr_ret(:,3)-zs).^2)).^0.5;
%     
%     idx_test=find(dist_test==0);
%     
%     if numel( idx_test)>1
%         plot3(xs,ys,zs,'g+','MarkerSize',12,'LineWidth',1.5);
%     end
%     
%     %clear statements
%     clear xs; clear ys; clear zs; clear dist_test; clear idx_test;
% end
% 
% close all;


%another debugging plot - plotting original clusters

% min_c2=min(in_arr_ret(:,4));
% max_c2=max(in_arr_ret(:,4));
% 
% figure, hold on; 
% the_map=colormap(jet);
% 
% for p=min_c2:max_c2
%     
%    idx_cas=find(in_arr_ret(:,4)==p);
%    
%    if numel(idx_cas)>0
%        
%        %get color vector
%        color_num=uint16(p.*(256/max_c2))
%        if color_num>256
%            color_num=256;
%        end
%        if color_num<1
%            color_num=1;
%        end
%        color_num=double(color_num);
%        plot3(in_arr_ret(idx_cas,1),in_arr_ret(idx_cas,2),in_arr_ret(idx_cas,3),'k+','MarkerSize',12,'LineWidth',1.5,'Color',the_map(color_num,:));
%        
%        clear color_num;
%        
%    end
%    
%    %clear statements
%    clear idx_cas;
%     
% end
% 
% %plotting the output after the spurious (small) clusters have been
% %removed
% 
% %removing the small clusters
% idx_really_small=find(in_arr_ret_final(:,5)==1);
% in_arr_ret(idx_really_small,:)=[];
% 
% for p=min_c2:max_c2
%     
%    idx_cas=find(in_arr_ret(:,4)==p);
%    
%    if numel(idx_cas)>0
%        plot3(in_arr_ret(idx_cas,1),in_arr_ret(idx_cas,2),in_arr_ret(idx_cas,3),'ro','MarkerSize',12,'LineWidth',1.5);
%    end
%    
%    %clear statements
%    clear idx_cas;
%     
% end
% 
% figure, hold on;
% plot3(in_arr_ret_final(idx_really_small,1),in_arr_ret_final(idx_really_small,2),in_arr_ret_final(idx_really_small,3),'k+');
% 


















% %counter 
% count=1;
% 
% for i=min_c:max_c
%    
%     %look for the cluster
%     idx_find=find(in_arr(:,4)==i);
% 
%     if numel(idx_find)>0
%        
%         %go through each pixel and see if it exists in another cluster
%         for r=1:numel(idx_find)
%             
%             %counter
%             count_delete=1;
%             
%             for q=min_c:max_c
%                
%                 %look only in other clusters
%                 if abs(q-r)>0
%                     
%                     %get pixels in the cluster
%                     idx_new=find(in_arr_ret(:,4)==q);
%                     
%                     %distance calculation
%                     dist_arr=(((in_arr(idx_find(r),1)-in_arr_ret(idx_new,1)).^2)+((in_arr(idx_find(r),2)-in_arr_ret(idx_new,2)).^2)+((in_arr(idx_find(r),3)-in_arr_ret(idx_new,3)).^2)).^0.5;
%                     
%                     %find overlap pixels in other clusters
%                     idx_near=find(dist_arr==0);
%                     
%                     %store overlap indices to delete
%                     if numel(idx_near)>0
%                         if count_delete==1
%                             idx_delete=idx_near;
%                             count_delete=count_delete+1;
%                         else
%                             idx_delete_tmp=idx_delete;
%                             clear idx_delete;
%                             idx_delete=[idx_delete_tmp;idx_near];
%                             clear idx_delete_tmp;
%                         end 
%                     end
%                     
%                     %clear statements
%                     clear idx_new; clear idx_near; clear dist_arr;
%                     
%                 end
%                 
%             end
%             
%             %at end of for loop removing elements that overlap
%             if count_delete>1
%                 in_arr_ret(idx_delete,:)=[];
%             end
%             
%         end
%         
%     end
% 
%     %clear statements
%     clear idx_find;
%     
%     
% end
% 
% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % %%%%%%%%%%%%%%%%%%making some plots for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
% figure, hold on; title('Original Data');
% plot3(in_arr(:,1),in_arr(:,2),in_arr(:,3),'r+','MarkerSize',12,'LineWidth',1.5);
% 
% figure, hold on; title('No Overlap Data');
% plot3(in_arr_ret(:,1),in_arr_ret(:,2),in_arr_ret(:,3),'r+','MarkerSize',12,'LineWidth',1.5);

% figure, hold on; title('Overlap pixels');
% idx_use=find(overlap_keep(:,1)>0);
% plot3(overlap_keep(idx_use,1),overlap_keep(idx_use,2),overlap_keep(idx_use,3),'r+','MarkerSize',12,'LineWidth',1.5);

% 
% %cluster extrema
% min_c=min(in_arr_ret(:,4));
% max_c=max(in_arr_ret(:,4));
% 
% %counter for the plots
% count_plot=1;
% 
% figure, hold on;
% for j=min_c:max_c
%    
%     idx_find=find(in_arr_ret(:,4)==j);
%     
%     if numel(idx_find)>0
%         
%         if count_plot==1
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'r+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==2
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'g+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==3
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'c+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==4
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'b+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==5
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'k+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==6
%             plot3(in_arr_ret(idx_find,1),in_arr_ret(idx_find,2),in_arr_ret(idx_find,3),'y+','MarkerSize',12,'LineWidth',1.5);
%         end
%            
%         %iterate counter
%         count_plot=count_plot+1;
%         
%         if count_plot==7
%             count_plot=1;
%         end
%             
%     end
%     
%     clear idx_find;
%     
% end
% 
% %cluster extrema
% min_c=min(in_arr(:,4));
% max_c=max(in_arr(:,4));
% 
% %counter for the plots
% count_plot=1;
% 
% figure, hold on;
% for j=min_c:max_c
%    
%     idx_find=find(in_arr_ret(:,4)==j);
%     
%     if numel(idx_find)>0
%         
%         if count_plot==1
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'r+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==2
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'g+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==3
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'c+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==4
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'b+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==5
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'k+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==6
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'y+','MarkerSize',12,'LineWidth',1.5);
%         end
%            
%         %iterate counter
%         count_plot=count_plot+1;
%         
%         if count_plot==7
%             count_plot=1;
%         end
%             
%     end
%     
%     clear idx_find;
%     
% end

% % % 
% idx_remove=find(in_arr(:,5)==0);
% % % 
% plot3(in_arr(idx_remove,1),in_arr(idx_remove,2),in_arr(idx_remove,3),'m+','MarkerSize',15,'LineWidth',2.5);
% % 
% % idx_overlap=find(in_arr(:,5)==1);
% % 
% % plot3(in_arr(idx_overlap,1),in_arr(idx_overlap,2),in_arr(idx_overlap,3),'bo','MarkerSize',10,'LineWidth',4.5);
% % 
% % hi=100000
% % 
% % hi=100000
% % 
% % 
  hi=100000000

  
 
 
%This was the first try which did not work
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%getting indices of overlapping pixels%%%%%%%%%%%%%%%%%%%%%

% %counter
% count=1;
% 
% %counter for overlap
% count_overlap=1;
% 
% %converting to double
% in_arr=double(in_arr);
% 
% for i=1:numel(in_arr(:,1))
%    
%     %some coordinates
%     xn=in_arr(i,1);
%     yn=in_arr(i,2);
%     zn=in_arr(i,3);
%     
%     %figuring out if this voxel is repeated
%   
%     %calculating distance
%     dist_arr=(((xn-in_arr(:,1)).^2)+((yn-in_arr(:,2)).^2)+((zn-in_arr(:,3)).^2)).^0.5;
%     
%     %look around for overlapping pixels
%     idx_look=find(dist_arr==0);
%     
%     %looking through list and eliminating 
%     if numel(idx_look)>2
% 
%         %removing index that you are looking at 
%         for r=1:numel(idx_look)
%             if idx_look(r)==i
%                 the_r=r;
%             end
%         end
%         idx_look(the_r)=[];
%         clear the_r;
%         
%         %making a list of coordinates to remove later
%         if count==1
%             idx_remove=idx_look;
%             count=count+1;
%             
%             %keeping track of pixels that overlap
%             pix_overlap(count_overlap,1)=i;
%             count_overlap=count_overlap+1;
%             
%         else
%             %seeing if any point is in the stack already
%             
%             %another counter
%             another_count=1;
%             
%             for s=1:numel(idx_look)
%                 idx_a=find(idx_remove==idx_look(s));
%                 if numel(idx_a)==0
%                     
%                     %store pixels to remove
%                    idx_remove_tmp=idx_remove;
%                    clear idx_remove;
%                    idx_remove=[idx_remove_tmp;idx_look(s)];
%                    clear idx_remove_tmp;
%                    
%                   if another_count==1
%                      
%                       %keeping track of pixels that overlap
%                       pix_overlap(count_overlap,1)=i;
%                       count_overlap=count_overlap+1;
%                       
%                       %iterate counter
%                       another_count=another_count+1;
%                       
%                   end
%                    
%                 end
%                 
%                 
%             end
%             
%         end
%         
%         
%     end
%     
%     %clear statements
%     clear xn; clear yn; clear zn; clear dist_arr; clear idx_look;
%     
% end
%  
%     
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%making some plots for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %cluster extrema
% min_c=min(in_arr(:,4));
% max_c=max(in_arr(:,4));
% 
% %counter for the plots
% count_plot=1;
% 
% figure, hold on;
% for j=min_c:max_c
%    
%     idx_find=find(in_arr(:,4)==j);
%     
%     if numel(idx_find)>0
%         
%         if count_plot==1
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'r+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==2
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'g+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==3
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'c+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==4
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'b+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==5
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'m+','MarkerSize',12,'LineWidth',1.5);
%         elseif count_plot==6
%             plot3(in_arr(idx_find,1),in_arr(idx_find,2),in_arr(idx_find,3),'y+','MarkerSize',12,'LineWidth',1.5);
%         end
%            
%         %iterate counter
%         count_plot=count_plot+1;
%         
%         if count_plot==7
%             count_plot=1;
%         end
%             
%     end
%     
%     clear idx_find;
%     
% end
% 
% plot3(in_arr(idx_remove,1),in_arr(idx_remove,2),in_arr(idx_remove,3),'m+','MarkerSize',15,'LineWidth',4.5);
% 
% hi=100000
% 
% hi=100000
% 
% 
% % 
% % 
% % 
% % 
% % 
% % 
% % 
% % 
% % 
% % 
% % 
