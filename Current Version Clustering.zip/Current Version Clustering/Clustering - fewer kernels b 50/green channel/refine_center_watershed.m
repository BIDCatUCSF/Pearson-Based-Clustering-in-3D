function[xt_ret,yt_ret,zt_ret,int_ret]=refine_center_watershed(in_arr,xt,yt,zt)

%This is a function to declare the center of possible as cluster as the
%brightest location near the likely center

% inputs
% in_arr(:,1) = x coordinates
% in_arr(:,2) = y coordinates
% in_arr(:,3) = z coordinates
% in_arr(:,4) = intensities
% xt = likely x coordinate of center
% yt = likely y coordinate of center
% zt = likely z coordinate of center

%distance
in_arr
in_arr(:,5)=(((in_arr(:,1)-xt).^2)+((in_arr(:,2)-yt).^2)+((in_arr(:,3)-zt).^2)).^0.5;

%get the spots closest to center
in_arr_sort=sortrows(in_arr,5);

%pick to new peak out of first 4
in_arr_pick=in_arr_sort(1:4,:);
max_int=max(in_arr_pick(:,4));
idx_max=find(in_arr_pick(:,4)==max_int);

xt_ret=in_arr_pick(idx_max(1),1);
yt_ret=in_arr_pick(idx_max(1),2);
zt_ret=in_arr_pick(idx_max(1),3);
int_ret=in_arr_pick(idx_max(1),4);

john=100000













