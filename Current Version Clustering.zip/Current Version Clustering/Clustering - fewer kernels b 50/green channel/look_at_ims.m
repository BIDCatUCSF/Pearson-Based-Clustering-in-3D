clear all; %close all;

%reading in the images
ic=imread('E:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\analysis and figures\cluster test\images stacks point 65 eps 5\clusterProj2d_pearson_thresh_p65_eps_5.btf');
im=imread('E:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\analysis and figures\cluster test\image stacks point 7\green_er_2d_proj_point7.btf');

%median filter
%ic=medfilt2(ic,[2 2]);

%rgb compsoite figure
ic_rgb=make_rgb_blank(ic,7,0,2);
im_rgb=make_rgb_blank(im,1500,300,1);

im_compos(:,:,1)=ic_rgb(:,:,1).*im_rgb(:,:,1);
im_compos(:,:,2)=ic_rgb(:,:,2).*im_rgb(:,:,2);
im_compos(:,:,3)=ic_rgb(:,:,3).*im_rgb(:,:,3);
figure, imshow([ic_rgb;im_rgb;im_compos]);

%plotting the boundaries
bw_im_3=zeros(size(ic));
bw_im_5=zeros(size(ic));
bw_im_7=zeros(size(ic));
idx_3=find(ic==3);
idx_5=find(ic==5);
idx_7=find(ic==7);
bw_im_3(idx_3)=1;
bw_im_5(idx_5)=1;
bw_im_7(idx_7)=1;

bound3_tmp=bwboundaries(bw_im_3);
bound5_tmp=bwboundaries(bw_im_5);
bound7_tmp=bwboundaries(bw_im_7);

figure, imagesc(im,[100,2500]); colormap(gray); colorbar; hold on;

for i=1:size(bound3_tmp,1)
   bound3=bound3_tmp{i};
   plot(bound3(:,2),bound3(:,1),'c','LineWidth',1.5);
   clear bound3;
end

for i=1:size(bound5_tmp,1)
   bound5=bound5_tmp{i};
   plot(bound5(:,2),bound5(:,1),'g','LineWidth',1.5);
   clear bound5;
end

for i=1:size(bound7_tmp,1)
   bound7=bound7_tmp{i};
   plot(bound7(:,2),bound7(:,1),'r','LineWidth',1.5);
   clear bound7;
end






