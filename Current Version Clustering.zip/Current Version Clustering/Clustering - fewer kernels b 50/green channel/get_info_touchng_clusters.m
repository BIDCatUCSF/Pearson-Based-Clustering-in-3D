function[matrix_of_overlap_ret]=get_info_touchng_clusters(main_arr,idx_close,important_cluster_num)

%inputs - matrix with all possible touching clusters
%main_arr(:,1) = x coordinates
%main_arr(:,2) = y coordinates
%main_arr(:,3) = z coordinates
%main_arr(:,4) = cluster #

%inputs 
%idx_close = rows of main_arr that touch the cluster of interest

%inputs
%important_cluster_num = original cluster number that main_arr touches
%important_cluster_area = area of the original cluster that main_arr
%touches
if numel(idx_close)>0
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%get the section of main_arr that are contained%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%within the cluster of interest%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %elements that colocalize
    sec_main_arr(:,1)=main_arr(idx_close,1);
    sec_main_arr(:,2)=main_arr(idx_close,2);
    sec_main_arr(:,3)=main_arr(idx_close,3);
    sec_main_arr(:,4)=main_arr(idx_close,4);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%getting area of overlapping clusters%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %extrema cluster numbers tha colocalize
    min_c=min(sec_main_arr(:,4));
    max_c=max(sec_main_arr(:,4));
    
    %counter
    count_look=1;
    
    for q=min_c:max_c
        
        %look for something
        idx_look=find(sec_main_arr(:,4)==q);
        
        if numel(idx_look)>0
            overlap_arr(count_look,1)=q;%cluster number
            overlap_arr(count_look,2)=numel(idx_look); %area of cluster that overlaps
            count_look=count_look+1;
        end
        
        %clear statements
        clear idx_look;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%getting the total area of the clusters that overlap%%%%%%%%%%
    
    
    if count_look>1
        
        %pre-allocating for speed
        matrix_of_overlap_ret=zeros(numel(overlap_arr(:,1)),3);
        matrix_of_overlap_ret=double(matrix_of_overlap_ret);
        
        for s=1:numel(overlap_arr(:,1))
            
            %get the cluster number and area of overlap
            c_num_now=overlap_arr(s,1);
            c_area_overlap=overlap_arr(s,2);
            c_area_overlap=double(c_area_overlap);
            
            %get the total area of this cluster
            idx1=find(main_arr(:,4)==c_num_now);
            tot_area_touching_cluster=numel(idx1);
            tot_area_touching_cluster=double(tot_area_touching_cluster);
            
            %putting the final matrix togehter
            matrix_of_overlap_ret(s,1)=double(important_cluster_num);
            matrix_of_overlap_ret(s,2)=double(c_num_now);
            matrix_of_overlap_ret(s,3)=(c_area_overlap/tot_area_touching_cluster)*100;
            
            %clear statements
            clear c_num_ow; clear c_area_overlap;
            clear idx1; clear tot_area_touching_cluster;
            
            
        end
        
    else
        
        %a really exceptional case
        matrix_of_overlap_ret=0;
        
    end
    
else
    %a really exceptional case
    matrix_of_overlap_ret=0;
end























