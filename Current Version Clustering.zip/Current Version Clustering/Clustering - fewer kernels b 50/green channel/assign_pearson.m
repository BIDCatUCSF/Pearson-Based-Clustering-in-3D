function[in_arr_ret]=assign_pearson(in_arr,all_p)

%This is a function that adds a Pearson value to the center position of the
%likely cluster center described in in_arr

%inputs
% in_arr(:,1) = x coordinate of possible cluster center
% in_arr(:,2) = y coordinate of possible cluster center
% in_arr(:,3) = z coordinate of possible cluster center

%inputs
% all_p(:,1) = x coordinate of pearson slice with non-zero entries
% all_p(:,2) = y coordinate of pearson slice with non-zero entries
% all_p(:,3) = z coordinate of pearson slice with non-zero entries
% all_p(:,4) = corresponding Pearson value

%making double
in_arr=double(in_arr);
all_p=double(all_p);

%declaring and pre-allocating matrix to return
in_arr_ret=in_arr;
in_arr_ret(:,4)=zeros(numel(in_arr_ret(:,1)),1);

for s=1:numel(in_arr(:,1))
    
    %copying
    all_p_tmp=all_p;
    
    %distance calculation
    all_p_tmp(:,5)=(((in_arr(s,1)-all_p_tmp(:,1)).^2)+((in_arr(s,2)-all_p_tmp(:,2)).^2)+((in_arr(s,3)-all_p_tmp(:,3)).^2)).^0.5;
    
    %sorting
    sort_all_p_tmp=sortrows(all_p_tmp,5);
    
    %grab the top value
    in_arr_ret(s,4)=max([sort_all_p_tmp(1,4),sort_all_p_tmp(2,4),sort_all_p_tmp(3,4)]);
    
    %clear statements
    clear all_p_tmp; clear sort_all_p_tmp;
    
end







