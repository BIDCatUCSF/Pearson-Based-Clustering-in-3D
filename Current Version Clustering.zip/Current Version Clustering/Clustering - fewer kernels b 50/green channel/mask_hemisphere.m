function[mask_return]=mask_hemisphere(im_in,x1,x2,y1,y2)

%weighting the start position
x1=x1+35;
y1=y1+20;

%making a mask
the_mask=zeros(size(im_in));
the_mask=double(the_mask);
im_in=double(im_in);

%dimensions
dim1=size(im_in,1);
dim2=size(im_in,2);

for k=1:(dim1*dim2)
    
    %converting to coordinate
    [yk,xk]=ind2sub(size(im_in),k);
    
    if xk>=x1 && xk<=x2 && yk>=y1 && yk<=y2
        the_mask(k)=1;
    end
    
    %clear statements
    clear yk; clear xk;
    
end

mask_return=im_in.*the_mask;















