function[im_c_stack_ret]=fill_in_clusters_v2(im_c_stack,im_e_stack,ns,ne)

%This is a function to fill in clusters. Filling just means holes in
%clusters are filled in. watershed in this sort of data is a little prone
%to holes.

%inputs
% im_c_stack = stack of images with clusters numbers
% im_e_stack = stack of images with intensity
% ns = initial index of image stack
% ne = final index of image stack

%outputs
%im_c_stack_ret = stack of cluster images after filling

%counters
countA=1;

%creating a return a matrix
im_c_stack_ret=im_c_stack;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%make a list of clusters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=ns:ne
   
    %read in images - cluster images
    imc=im_c_stack(:,:,countA);
    
    %read in images - intensity images
    ime=im_e_stack(:,:,countA);

    %non-zero elements
    idxe=find(ime>0);
    [ye,xe]=ind2sub(size(ime),idxe);
    
    if countA==1
        all_data(:,1)=xe;
        all_data(:,2)=ye;
        all_data(:,3)=linspace(i,i,numel(xe))';
        all_data(:,4)=imc(idxe);
    else
        all_data_tmp=all_data;
        clear all_data;
        all_data=[all_data_tmp;[xe,ye,linspace(i,i,numel(xe))',imc(idxe)]];
        clear all_data_tmp;
    end
    
    %iterate counter
    countA=countA+1;
    
   %clear statements
   clear imc; clear idxe; clear ime; clear xe; clear ye;

end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%filling in%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%adding a column of zeros
all_data(:,5)=0;

%look for areas without cluster
idx_no_c=find(all_data(:,4)==0);

if numel(idx_no_c)>0
    for j=1:numel(idx_no_c)
        
        %get coordinates
        all_data=double(all_data);
        xn=all_data(idx_no_c(j),1);
        yn=all_data(idx_no_c(j),2);
        zn=all_data(idx_no_c(j),3);
        
        %new matrix for calculation
        all_data_calc=all_data;
        
        %remove current entry
        all_data_calc(idx_no_c(j),:)=[];
        all_data_calc=double(all_data_calc);
        
        %get distance
        all_data_calc(:,6)=(((xn-(all_data_calc(:,1))).^2)+((yn-(all_data_calc(:,2))).^2)+((zn-(all_data_calc(:,3))).^2)).^0.5;
        
        %sorting by distance
        sort_all_data_calc=sortrows(all_data_calc,6);
        
        %grab the top 8 nearest neighbors
        top_eight=sort_all_data_calc(1:8,:);
        
        %counter
        count8=0;
        
        %checking if I should fill it
        for k=1:8
            if top_eight(k,6)<=2 && top_eight(k,4)>0
                
                %iterate counter
                count8=count8+1;
                
                %cluster number
                clust_change(count8,1)=top_eight(k,4);
                
            end
        end
        
        %filling cluster
        if count8>=6
            %filling spaces
            all_data(idx_no_c(j),4)=mode(clust_change);
            
            %marking for change
            all_data(idx_no_c(j),5)=1;
            
            %clearing cluster matrix
            clear clust_change;
            
        end
        
        %clear statements 
        clear xn; clear yn; clear zn; clear all_data_calc; clear sort_all_data_calc;
        clear top_eight; 
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Making changes to stack%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%look if you need to change anything
idx_egh=find(all_data(:,5)>0);

if numel(idx_egh)>0
    
    for r=1:numel(idx_egh)
       
        %get the correct z index
        zf_tmp=all_data(idx_egh(r),3);
        zf=zf_tmp-ns+1;
        xf=all_data(idx_egh(r),1);
        yf=all_data(idx_egh(r),2);
        cf=all_data(idx_egh(r),4);
        
        %grab z slice
        z_slice=im_c_stack_ret(:,:,zf);
        idx_f=sub2ind(size(z_slice),yf,xf);
        z_slice(idx_f)=cf;
        
        %storing
        im_c_stack_ret(:,:,zf)=z_slice;
        
        %clear statements
        clear zf_tmp; clear zf; 
        clear xf; clear yf; clear cf;
        clear z_slice; clear idx_f;
    end
    
end













    