function[list_ret]=combine_cluster_after_screen(the_list,the_cell)

%counter 
countR=1;

for i=1:size(the_cell,1)
    
   %get an element
   ele_now_tmp=the_cell(i,1);
   ele_now=ele_now_tmp{1};
   
   %local counter
   loc_count=1;
   
   for r=1:numel(ele_now)
       
       %get the cluster
       idx_it=find(the_list(:,4) == ele_now(r));
       
       if loc_count==1 && numel(idx_it)>0
            new_thing=[the_list(idx_it,1),the_list(idx_it,2),the_list(idx_it,3),linspace(countR,countR,numel(idx_it))'];
            loc_count=loc_count+1;
       elseif loc_count>1 && numel(idx_it)>0
            new_thing_tmp=new_thing;
            clear new_thing;
            new_thing=[new_thing_tmp;[the_list(idx_it,1),the_list(idx_it,2),the_list(idx_it,3),linspace(countR,countR,numel(idx_it))']];
            clear new_thing_tmp;
       end
       
       %clear statements
       clear idx_it;
       
   end
    
   if countR==1 && loc_count>1
       list_ret=new_thing;
       countR=countR+1;
   elseif countR>1 && loc_count>1
       list_ret_tmp=list_ret;
       clear list_ret;
       list_ret=[list_ret_tmp;new_thing];
       clear list_ret_tmp;
       countR=countR+1;
   end
   
   %clear statements
   clear ele_now; clear ele_now_tmp;


end

if countR==1
    list_ret=0;
end























