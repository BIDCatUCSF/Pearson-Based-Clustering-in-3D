function[arr_return]=create_txt_cluster_matrix(clust_in,int_in)

%cluster extrema
min_cl=min(clust_in);
max_cl=max(clust_in);

%making double
int_in=double(int_in);

%counter
count2=1;

for p=min_cl:max_cl
    
   %look
   idx_p=find(clust_in==p);
   
   if numel(idx_p)>0
       
       arr_return(count2,1)=double(p); %cluster number
       arr_return(count2,2)=double(numel(idx_p)); %size
       arr_return(count2,3)=double(sum(int_in(idx_p))); %integrated intensity
       
       count2=count2+1;
       
   end
    
    
  %clear statements
  clear idx_p;
   
end

if count2==1
    arr_return=0;
end




































