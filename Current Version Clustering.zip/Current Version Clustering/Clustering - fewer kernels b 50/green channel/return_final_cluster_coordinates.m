function[the_cluster_ret]=return_final_cluster_coordinates(xb,yb,zb,size_b,all_pc_now)

%inputs
% xb = x center of cluster
% yb = y center of cluster
% zb = z center of cluster
% size_b = width of kernel associated with cluster

%inputs
% all_pc_now(:,1) = x coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,2) = y coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,3) = z coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,4) = pearsons coefficient


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Grabbing the relevant z planes%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%some type conversion
xb=double(xb); yb=double(yb); zb=double(zb);

%some type conversion
all_pc_now=uint16(all_pc_now);
all_pc_now=double(all_pc_now);

%how far up and down to go
delta_z=(uint16(size_b*0.5))+1;
delta_z=double(delta_z);

%lowest and highest z to sample
low_z=uint16(zb)-delta_z; low_z=double(low_z);
high_z=uint16(zb)+delta_z; high_z=double(high_z);

%counter
count_z=1;

for d=low_z:high_z
    
   %indices from a z level
   idx_cb=find(all_pc_now(:,3)==d);
   
   if count_z==1
      sec_now=[all_pc_now(idx_cb,1),all_pc_now(idx_cb,2),all_pc_now(idx_cb,3),all_pc_now(idx_cb,4)];
      count_z=count_z+1;
   else
       sec_now_tmp=sec_now;
       clear sec_now;
       sec_now=[sec_now_tmp;[all_pc_now(idx_cb,1),all_pc_now(idx_cb,2),all_pc_now(idx_cb,3),all_pc_now(idx_cb,4)]];
       clear sec_now_tmp;
   end
    
   %clear statements
   clear idx_cb;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Getting the size of the cluster%%%%%%%%%%%%%%%%%%%%%%%%%%%

%some type conversion
sec_now=double(sec_now);

%figuring out some distances
dist_cb=(((xb-sec_now(:,1)).^2)+((yb-sec_now(:,2)).^2)+((zb-sec_now(:,3)).^2)).^0.5;

%elements within allowed distance based on the size of the kernel
idx_cl_tmp=find(dist_cb<((size_b*0.5)+1)); %was +0.5

%further sectioning out the voxels right around my cluster
sec_near(:,1)=sec_now(idx_cl_tmp,1);
sec_near(:,2)=sec_now(idx_cl_tmp,2);
sec_near(:,3)=sec_now(idx_cl_tmp,3);
sec_near(:,4)=sec_now(idx_cl_tmp,4);
sec_near=double(sec_near);

%thresholding based on PC level
idx_pc_thresh=find(sec_near(:,4)>10); %was 0.35

if numel(idx_pc_thresh)>=12
    
    %matrix to return
    the_cluster_ret(:,1)=sec_near(idx_pc_thresh,1);
    the_cluster_ret(:,2)=sec_near(idx_pc_thresh,2);
    the_cluster_ret(:,3)=sec_near(idx_pc_thresh,3);
    
else 
    
    the_cluster_ret=0;

end 
   







