function[XYZ_2_ret]=function_find_microvilli(XYZ_2a)

%This is a function written to take a set of coordinates from a 3d mesh
%around a suspected peak and find the edges of the microvilli

%input matrix "XYZ_2_tmp"
% I am referencing below here the node matrix outputted by the mesh
% generation step

%NB element XYZ_2_tmp(1,:) = should be the suspected peak (center)

% XYZ_2a(:,1)=node(:,2);
% XYZ_2a(:,2)=node(:,1);
% XYZ_2a(:,3)=node(:,3);
% XYZ_2a(:,4)=ring # (0-peak, 1, 2, 3)
% XYZ_2a(:,5)=node(:,4) curvature

%output matrix
% XYZ_2_ret(:,1)=node(:,2);
% XYZ_2_ret(:,2)=node(:,1);
% XYZ_2_ret(:,3)=node(:,3);
% XYZ_2_ret(:,4)= '1' or '0' indicating if this node point is in the
% mountain or not.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%real data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%removing duplicate rows
%XYZ_2a=unique(XYZ_2_tmp,'rows');
%XYZ_2a=XYZ_2_tmp;
XYZ_2(:,1)=XYZ_2a(:,1);
XYZ_2(:,2)=XYZ_2a(:,2);
XYZ_2(:,3)=XYZ_2a(:,3);
ring_num=XYZ_2a(:,4);
curve_data=XYZ_2a(:,5);


%definition of the simulated plane
%figure, plot3(XYZ_2(:,1),XYZ_2(:,2),XYZ_2(:,3),'b.'); hold on;

%extrema
del_x=uint16(abs(max(XYZ_2(:,1))-min(XYZ_2(:,1))));
del_y=uint16(abs(max(XYZ_2(:,2))-min(XYZ_2(:,2))));
del_z=uint16(abs(max(XYZ_2(:,3))-min(XYZ_2(:,3))));
the_width_arr=[del_x;del_y;del_z];
the_width=max(the_width_arr);

%compute the normal to the plane and a point that belongs to the plane
[n_2,V_2,p_2] = affine_fit(XYZ_2);

%what is the point on plane
%plot3(p_2(1),p_2(2),p_2(3),'r+','MarkerSize',12,'LineWidth',1.5);

%define the grid
%[S1,S2] = meshgrid([-1 0 1]);
for i=1:the_width
    
    %figure out width from center - odd case and then even case
    if i==1
        %if mod(the_width,2)==1
            del_s1=-1*double((uint16(the_width*0.5))-1);
            del_s2=(uint16(the_width*0.5))-1;
%         else
%             del_s1=-(uint16(the_width*0.5))
%             del_s2=(uint16(the_width*0.5))-1
%         end
    end

    %making double
    del_s1=double(del_s1);
    del_s2=double(del_s2);
    the_width=double(the_width);
    i=double(i);

    %making the lists (S1 and S2)
    if i==1
        S2=linspace(del_s1+i-1,del_s1+i-1,the_width)';
        S1=linspace(del_s1,del_s2,the_width)';
    else
        S2_tmp=S2;
        clear S2;
        S2=[S2_tmp;linspace(del_s1+i-1,del_s1+i-1,the_width)'];
        clear S2_tmp;

        S1_tmp=S1;
        clear S1;
        S1=[S1_tmp;linspace(del_s1,del_s2,the_width)'];
        clear S1_tmp;
    end

end

%generate the pont coordinates
X = p_2(1)+[S1(:) S2(:)]*V_2(1,:)';
Y = p_2(2)+[S1(:) S2(:)]*V_2(2,:)';
Z = p_2(3)+[S1(:) S2(:)]*V_2(3,:)';

%plot the plane
% surf(reshape(X,the_width,the_width),reshape(Y,the_width,the_width),reshape(Z,the_width,the_width),'facecolor','blue','facealpha',0.5);
% xlabel('x');
% ylabel('y');
% zlabel('z');
% axis equal

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Checking how curvature projects to plane%%%%%%%%%%%%%%%

%plotting the original curvature information
% figure, hold on; title('Original Data w Curvature');
% for p=1:numel(XYZ_2(:,1))
%     
%     %curvature
%     c_now=curve_data(p,1);
%     idx_low=find(c_now<-0.5);
%     idx_high=find(c_now>0.5);
%     if numel(idx_low)>0
%         c_now(idx_low)=-0.5;
%     end
%     if numel(idx_high)>0
%         c_now(idx_high)=0.5;
%     end
%     
%     %scaling - keeping it positive
%     c_now=c_now+0.5;
%     c_now=double(c_now);
%     idx_bar=uint16(c_now.*64);
%     if idx_bar<1
%         idx_bar=1;
%     end
%     if idx_bar>64
%         idx_bar=64;
%     end
%     
%     %plot3(XYZ_2(p,1),XYZ_2(p,2),XYZ_2(p,3),'k+','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     
%     %clear statements
%     clear c_now; clear idx_low; clear idx_high; clear idx_bar;
%     
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%Making planes to better keep track of ring number%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%and curvature throughout code%%%%%%%%%%%%%%%%%%%%%%%%%

%list of curvature in plane
curve_plane=zeros(size(X));
curve_plane=curve_plane+100; 

%list of ring number in plane
ring_plane=curve_plane;

%plane to keep track of locations in original stack
track_plane=curve_plane;

%making double
X=double(X);
Y=double(Y);
Z=double(Z);
XYZ_2=double(XYZ_2);

for s=1:numel(XYZ_2(:,1))
   
    %distance
    d_arr=((X-XYZ_2(s,1)).^2)+((Y-XYZ_2(s,2)).^2)+((Z-XYZ_2(s,3)).^2);
    min_d=min(d_arr);
    idx_d=find(d_arr==min_d);
    
    %checking if this spot on plane is already populated
    if curve_plane(idx_d(1)) == 100
        
        %adding curvature
        curve_plane(idx_d(1))=curve_data(s,1);
        
        %adding ring number
        ring_plane(idx_d(1))=ring_num(s,1);
        
        %adding location
        track_plane(idx_d(1))=s;
     
     %if spot is already populated put spot in next closest spot
    else
        
        while curve_plane(idx_d(1)) ~= 100
           d_arr(idx_d(1))=1000;
           clear idx_d;
           min_d=min(d_arr);
           idx_d=find(d_arr==min_d);
        end
        
        %adding curvature
        curve_plane(idx_d(1))=curve_data(s,1);
        
        %adding ring number
        ring_plane(idx_d(1))=ring_num(s,1);
        
        %adding location
        track_plane(idx_d(1))=s;
        
    end
    
    %clear statements
    clear d_arr; clear min_d; clear idx_d;
    
    
end

%projecting information about curvature onto plot
%figure, hold on; title('Curvature projected onto 2D Plane');
% for r=1:numel(X)
%    
%      %curvature
%      c_now=curve_plane(r,1);
%     
%     if c_now<100
%         
%         %screening
%         idx_low=find(c_now<-0.5);
%         idx_high=find(c_now>0.5);
%         if numel(idx_low)>0
%             c_now(idx_low)=-0.5;
%         end
%         if numel(idx_high)>0
%             c_now(idx_high)=0.5;
%         end
%         
%         %scaling - keeping it positive
%         c_now=c_now+0.5;
%         c_now=double(c_now);
%         
%         %figuring out the colorbar
%         idx_bar=uint16(c_now.*64);
%         if idx_bar<1
%             idx_bar=1;
%         end
%         if idx_bar>64
%             idx_bar=64;
%         end
%         
%         %plotting
%         plot3(X(r),Y(r),Z(r),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%         
%         %clear statements
%         clear c_now; clear idx_low; clear idx_high; clear idx_bar;
%         
%     end
%     
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%debugging
%seeing what these vectors are
% figure, hold on;
% for i=1:numel(X)
%     plot3(X(i),Y(i),Z(i),'ro','MarkerSize',12,'LineWidth',1.5);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%Figuring out the rotation necessary to put the plane on%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2d axis%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%defining rotation matrix
%figure, hold on; 

for t=1:6%
    
    %pre-allocating for speed
    del_keep=zeros(360,2);
    del_keep=double(del_keep);
    
    for k=1:360
        
        %define theta
        theta=double(-180+k-1);
        theta=theta.*(pi/180);
        
        %define rotation matrix
        if t==1 %x axis
            rot_mat=rotationmat3D(theta,[1 0 0]);
        elseif t==2 % y axis
            rot_mat=rotationmat3D(theta,[0 1 0]);
        elseif t==3 % z axis
            rot_mat=rotationmat3D(theta,[0 0 1]);
        elseif t==4 %x z axes
            rot_mat=rotationmat3D(theta,[1 0 1]);
        elseif t==5 %x y axes
            rot_mat=rotationmat3D(theta,[1 1 0]);
        elseif t==6 %y z axes
            rot_mat=rotationmat3D(theta,[0 1 1]);
        end
   
        
        %applying rotation matrix
        for j=1:numel(X)
            
            vec=[X(j);Y(j);Z(j)];
            thing_plot=[rot_mat*vec]';
            coord_2d(j,:)=[thing_plot];
            
            %clear statements
            clear vec; clear thing_plot;
            
        end
        
        %seeing how close to being purely in xy plabe coordinates are
        del_keep(k,1)=theta;
        del_keep(k,2)=abs(min(coord_2d(:,3))-max(coord_2d(:,3)));
        
        
        %seeing how close to flat things are
%         del_keep(k,1)=theta*(180/pi);
%         del_keep(k,2)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),1)-coord_2d(1:(numel(coord_2d(:,2))-1),1)));
%         del_keep(k,3)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),2)-coord_2d(1:(numel(coord_2d(:,2))-1),2)));
%         del_keep(k,4)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),3)-coord_2d(1:(numel(coord_2d(:,2))-1),3)));
        
        %clear statements
        clear theta; clear rot_mat; 
        clear coord_2d;
        
    end
    
    %storing extrema information
    extrema_info(t,1)=min(del_keep(:,2));
    
    %locating angles where extrema occurred 
    idx_ang_x=find(del_keep(:,2)==min(del_keep(:,2)));
    
    %storing angles
    extrema_info(t,2)=del_keep(idx_ang_x(1),1);

    
    %clear statement
    clear del_keep; clear idx_ang_x; clear idx_ang_y; clear idx_ang_z;
    
    
end

%figuring out the rotation angle to use
min_diff=min(extrema_info(:,1));
idx_diff=find(extrema_info(:,1)==min_diff);
theta_use=extrema_info(idx_diff(1),2);

%figuring out which rotation matrix to use
if idx_diff(1)==1 %x axis
    rot_mat_use=rotationmat3D(theta_use,[1 0 0]);
elseif idx_diff(1)==2 % y axis
    rot_mat_use=rotationmat3D(theta_use,[0 1 0]);
elseif idx_diff(1)==3 % z axis
    rot_mat_use=rotationmat3D(theta_use,[0 0 1]);
elseif idx_diff(1)==4 %x z axes
    rot_mat_use=rotationmat3D(theta_use,[1 0 1]);
elseif idx_diff(1)==5 %x y axes
    rot_mat_use=rotationmat3D(theta_use,[1 1 0]);
elseif idx_diff(1)==6 %y z axes
    rot_mat_use=rotationmat3D(theta_use,[0 1 1]);
end

%applying rotation matrix
for m=1:numel(X)
    
    vec1=[X(m);Y(m);Z(m)];
    thing_plot1=[rot_mat_use*vec1]';
    final_data_in_xy(m,:)=[thing_plot1];
    
    %clear statements
    clear vec1; clear thing_plot1;
    
end

%making a figure
% figure, hold on; title(strcat('r is',num2str(r),' and s is', num2str(s)));
% plot(final_data_in_xy(:,1),final_data_in_xy(:,2),'k+');

%counter
count_en=1;

%adding the curvature information
for q=1:numel(final_data_in_xy(:,1))
    
    %curvature
     c_now=curve_plane(q,1);
    
    if c_now<100
        
        %storing only the data points with known curvature
        final_coords_w_curv(count_en,1)=final_data_in_xy(q,1); %x
        final_coords_w_curv(count_en,2)=final_data_in_xy(q,2); %y
        final_coords_w_curv(count_en,3)=ring_plane(q,1); %ring 
        final_coords_w_curv(count_en,4)=c_now; %curvature
        final_coords_w_curv(count_en,5)=track_plane(q,1); %position in the original list
        count_en=count_en+1;
        
        %screening
        idx_low=find(c_now<-0.5);
        idx_high=find(c_now>0.5);
        if numel(idx_low)>0
            c_now(idx_low)=-0.5;
        end
        if numel(idx_high)>0
            c_now(idx_high)=0.5;
        end
        
        %scaling - keeping it positive
        c_now=c_now+0.5;
        c_now=double(c_now);
        
        %figuring out the colorbar
        idx_bar=uint16(c_now.*64);
        if idx_bar<1
            idx_bar=1;
        end
        if idx_bar>64
            idx_bar=64;
        end

        %plotting
        %plot3(final_data_in_xy(q,1),final_data_in_xy(q,2),final_data_in_xy(q,3),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
        
        %clear statements
        clear c_now; clear idx_low; clear idx_high; clear idx_bar;
        
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%This is the actual watershed portion of code%%%%%%%%%%%%%%

%pre-allocating an array to tell me what is in and not in mountain
mountain_or_not=zeros(numel(final_coords_w_curv(:,5)),1);

%scaling up the x and y axis to simplify later calculations - x axis
if min(final_coords_w_curv(:,1))<0
    final_coords_w_curv(:,1)=final_coords_w_curv(:,1)+abs(min(final_coords_w_curv(:,1)))+1;
end

%scaling up the x and y axis to simplify later calculations - y axis
if min(final_coords_w_curv(:,2))<0
    final_coords_w_curv(:,2)=final_coords_w_curv(:,2)+abs(min(final_coords_w_curv(:,2)))+1;
end

%getting center
idx_center=find(final_coords_w_curv(:,3)==0);
x_center1=final_coords_w_curv(idx_center(1),1);
y_center1=final_coords_w_curv(idx_center(1),2);
curve_center1=final_coords_w_curv(idx_center(1),4);

%marking the center as a mountain
mountain_or_not(idx_center(1))=1;

%calculating angle
[angle_list_all]=calc_angle_microvilli([final_coords_w_curv(:,2),final_coords_w_curv(:,1)],x_center1,y_center1);
angle_list_all(:,3)=angle_list_all(:,3)*(180/pi);

%getting the locations of the rings
idx_ring1=find(final_coords_w_curv(:,3)==1);
idx_ring2=find(final_coords_w_curv(:,3)==2);
idx_ring3=find(final_coords_w_curv(:,3)==3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%calculate gradient of ring 1
gradient_list(:,1)=zeros(numel(final_coords_w_curv(:,5)),1);
gradient_list(idx_ring1,1)=curve_center1-final_coords_w_curv(idx_ring1,4); %curvature

%adding to mountain classification
idx_r1_mtn=find(gradient_list(:,1)<0);
if numel(idx_r1_mtn)>0
    mountain_or_not(idx_r1_mtn)=1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[mountain_or_not_r12]=find_grad_ring(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not,idx_ring1,idx_ring2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[mountain_or_not_final]=find_grad_ring(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not_r12,idx_ring2,idx_ring3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Creating matrix to return%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%return
XYZ_2_ret=XYZ_2;

for f=1:numel(final_coords_w_curv(:,5))
    
    %index from original list
    idx_orig=final_coords_w_curv(f,5);
    
    %for debugging only
    %XYZ_2_ret(idx_orig,4)=final_coords_w_curv(f,4);
    
    %adding assignment of mtn or not
    XYZ_2_ret(idx_orig,4)=mountain_or_not_final(f,1);
    
    %clear statements
    clear idx_orig;
    
end



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%Checking angles%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% figure, hold on; title('Checking Angles');
% jet_map=colormap(jet);
% 
% for i=1:numel(angle_list(:,1))
%    
%     %get color
%     idx_bar=uint16(angle_list(i,3)*(256/360));
%     if idx_bar<1
%         idx_bar=1;
%     elseif idx_bar>256
%         idx_bar=256;
%     end
%     
%     %plot
%     plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',jet_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     
%     %clear statement
%     clear idx_bar;
% end
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%% Checking Rings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% figure, hold on; title('Checking Rings');
% 
% %checking the ring number
% for i=1:(count_en-1)
%     
%     if final_coords_w_curv(i,3)==1
%         idx_bar=1;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==2
%         idx_bar=32;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==3
%         idx_bar=64;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==0
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','LineWidth',1.5,'MarkerSize',12);
%     end
%     
% end



















