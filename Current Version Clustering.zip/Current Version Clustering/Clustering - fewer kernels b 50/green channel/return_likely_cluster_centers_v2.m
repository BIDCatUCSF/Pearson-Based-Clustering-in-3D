function[final_list]=return_likely_cluster_centers_v2(in2,in3,in4,p2,p3,p4,ns,ne)

%version 2 has limited number of kernels 

%inputs 
%each of these matrices corresponds to a pre-determined kernel size
%(3,4,5,6,7)
%in#(:,1) = x coordinate of possible center
%in#(:,2) = y coordinate of possible center
%in#(:,3) = z coordinate of possible center

%p# = paths to Pearson Images
%ns,ne = extrema of stack

%outputs
%final_list(:,1) = x coordinate of unique cluster center
%final_list(:,2) = y coordinate of unique cluster center
%final_list(:,3) = z coordinate of unique cluster center
%final_list(:,4) = Pearson Max of unique cluster center
%final_list(:,5) = size of corresponding kernel

%outputs 
%all_p#(:,1) = x coordinate of non-zero spot in Pearson image
%all_p#(:,2) = y coordinate of non-zero spot in Pearson image
%all_p#(:,3) = z coordinate of non-zero spot in Pearson image
%all_p#(:,4) = Pearson number

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%Making Coordinate Lists%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%intializing return argument
final_list=0;

%counters
count1=1;
count2=1;
count3=1;
count4=1;
count5=1;

for r=ns:ne
    
   %read in the images
 %  i1=imread(strcat(p1,num2str(r),'.tif'));
   i2=imread(strcat(p2,num2str(r-ns+1),'.tif'));
   i3=imread(strcat(p3,num2str(r-ns+1),'.tif'));
   i4=imread(strcat(p4,num2str(r-ns+1),'.tif'));
   %i5=imread(strcat(p5,num2str(r-ns+1),'.tif'));
    
   %find non - zero entries
   %idx1=find(i1>0);
   idx2=find(i2>0);
   idx3=find(i3>0);
   idx4=find(i4>0);
   %idx5=find(i5>0);
   
%    if numel(idx1)>0
%        [y1,x1]=ind2sub(size(i1),idx1);
%        if count1==1
%            all_p1=[x1,y1,linspace(r,r,numel(x1))',i1(idx1)];
%            count1=count1+1;
%        else
%            all_p1_tmp=all_p1;
%            clear all_p1;
%            all_p1=[all_p1_tmp;[x1,y1,linspace(r,r,numel(x1))',i1(idx1)]];
%            clear all_p1_tmp;    
%        end
%        %clear statements
%        clear x1; clear y1;
%    end
%        
   if numel(idx2)>0
       [y2,x2]=ind2sub(size(i2),idx2);
       if count2==1
           all_p2=[x2,y2,linspace(r,r,numel(x2))',i2(idx2)];
           count2=count2+1;
       else
           all_p2_tmp=all_p2;
           clear all_p2;
           all_p2=[all_p2_tmp;[x2,y2,linspace(r,r,numel(x2))',i2(idx2)]];
           clear all_p2_tmp;    
       end
       %clear statements
       clear x2; clear y2;
   end
   
   if numel(idx3)>0
       [y3,x3]=ind2sub(size(i3),idx3);
       if count3==1
           all_p3=[x3,y3,linspace(r,r,numel(x3))',i3(idx3)];
           count3=count3+1;
       else
           all_p3_tmp=all_p3;
           clear all_p3;
           all_p3=[all_p3_tmp;[x3,y3,linspace(r,r,numel(x3))',i3(idx3)]];
           clear all_p3_tmp;    
       end
       %clear statemetns
       clear x3; clear y3;
   end
   
   if numel(idx4)>0
       [y4,x4]=ind2sub(size(i4),idx4);
       if count4==1
           all_p4=[x4,y4,linspace(r,r,numel(x4))',i4(idx4)];
           count4=count4+1;
       else
           all_p4_tmp=all_p4;
           clear all_p4;
           all_p4=[all_p4_tmp;[x4,y4,linspace(r,r,numel(x4))',i4(idx4)]];
           clear all_p4_tmp;    
       end
       %clear statemetns
       clear x4; clear y4;
   end
%    
%    if numel(idx5)>0
%        [y5,x5]=ind2sub(size(i5),idx5);
%        if count5==1
%            all_p5=[x5,y5,linspace(r,r,numel(x5))',i5(idx5)];
%            count5=count5+1;
%        else
%            all_p5_tmp=all_p5;
%            clear all_p5;
%            all_p5=[all_p5_tmp;[x5,y5,linspace(r,r,numel(x5))',i5(idx5)]];
%            clear all_p5_tmp;    
%        end
%        %clear statements
%        clear x5; clear y5;
%    end
%    
   %clear statements
   clear i1; clear i2; clear i3; clear i4; clear i5;
   clear idx1; clear idx2; clear idx3; clear idx4; clear idx5;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Assigning Pearson Values to %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%inputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%[in1_pc]=assign_pearson(in1,all_p1);
[in2_pc]=assign_pearson(in2,all_p2);
[in3_pc]=assign_pearson(in3,all_p3);
[in4_pc]=assign_pearson(in4,all_p4);
%[in5_pc]=assign_pearson(in5,all_p5);

%assigning sizes of kernel
%in1_pc(:,5)=linspace(3,3,numel(in1_pc(:,1)))';
in2_pc(:,5)=linspace(4,4,numel(in2_pc(:,1)))';
in3_pc(:,5)=linspace(5,5,numel(in3_pc(:,1)))';
in4_pc(:,5)=linspace(6,6,numel(in4_pc(:,1)))';
%in5_pc(:,5)=linspace(7,7,numel(in5_pc(:,1)))';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%Remvoing Redundancies%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%this section of the code deals with the case where certain spots are
%similar in size to multiple kernels

%putting all matrices together
in_pc_ok=[in3_pc;in2_pc;in4_pc];
in_pc=sortrows(in_pc_ok,4);

%total number of initial clusters
init_num=numel(in_pc(:,1));

%counter
count_c=1;

%make a copy
in_pc_copy=in_pc;

%counter for master center list
while init_num > 0
   
    %coordinate to search - always grab element 1 as I trim matrix
    xn=in_pc_copy(1,1);
    yn=in_pc_copy(1,2);
    zn=in_pc_copy(1,3);
    pn=in_pc_copy(1,4);
    sn=in_pc_copy(1,5);
    
    %removing element
    in_pc_copy(1,:)=[];
    
    %distance
    dn=(((xn-in_pc_copy(:,1)).^2)+((yn-in_pc_copy(:,2)).^2)+((zn-in_pc_copy(:,3)).^2)).^0.5;
    
    %too close
    too_close=find(dn<=3);
    
    if numel(too_close)>0
        
        %grab all close elements
        nn_tmp=[in_pc_copy(too_close,1),in_pc_copy(too_close,2),in_pc_copy(too_close,3),in_pc_copy(too_close,4),in_pc_copy(too_close,5)];

        %adding the first element - this might have the high pearson value
        nn=[[xn,yn,zn,pn,sn];nn_tmp];
        
        %put the element with highest pc in return
        max_pc=max(nn(:,4));
        idx_max=find(nn(:,4)==max_pc);
        final_list(count_c,1)=nn(idx_max(1),1);
        final_list(count_c,2)=nn(idx_max(1),2);
        final_list(count_c,3)=nn(idx_max(1),3);
        final_list(count_c,4)=nn(idx_max(1),4);
        final_list(count_c,5)=nn(idx_max(1),5);
        
        %remvoing element
        in_pc_copy(too_close,:)=[];
        
        %iterate counter
        count_c=count_c+1;
        
        %clear statement
        clear nn; clear max_pc; clear idx_max; clear nn_tmp;
        
    else
        
        %putting current element in list
        final_list(count_c,1)=xn;
        final_list(count_c,2)=yn;
        final_list(count_c,3)=zn;
        final_list(count_c,4)=pn;
        final_list(count_c,5)=sn;
        
        %iterate counter
        count_c=count_c+1;
        
    end
    
    %anything left?
    init_num=numel(in_pc_copy(:,1));
    
    %clear statements
    clear too_close; clear dn; clear xn; clear yn; clear zn; clear pn; clear sn;
    
    
end






















