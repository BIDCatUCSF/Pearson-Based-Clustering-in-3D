function[cell_send_back]=final_screen_to_combine_clusters(a_map)

%This function provides a final screen on the cell array that contains the
%information necessary to combine overlapping clusters


% %making a cell array to return
% cell_arr_back=cell(size(a_map,1),1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%making the inputted cell array into a matrix%%%%%%%%%%%%%%%


for i=1:size(a_map,1)
    
    %get an element
    ele_tmp=a_map(i,1);
    ele=ele_tmp{1};
    
    %the element number
    ele_num=linspace(i,i,numel(ele));
    
    %making a matrix
    if i==1
        big_m=[ele',ele_num'];
    else
        big_m_tmp=big_m;
        clear big_m;
        big_m=[big_m_tmp;[ele',ele_num']];
        clear big_m_tmp;
    end
    
    %clear statements
    clear ele_tmp; clear ele;
    clear ele_num;
    
end

big_m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%Going through the list%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Remvoing Redundant Entries%%%%%%%%%%%%%%%%%%%

%extrema to loop through
min_l=min(big_m(:,2));
max_l=max(big_m(:,2));

for j=min_l:max_l
    
    %getting a set
    idx_find=find(big_m(:,2)==j);
    
    if numel(idx_find)>1

        %removing unique values
        test_arr1=big_m(idx_find,1);
        test_arr2=big_m(idx_find,2);
        [c,idx_unique]=unique(test_arr1,'rows');
        
        %removing entry
        big_m(idx_find,:)=[];

        %addin unique set
        big_m_tmp=big_m; 
        clear big_m;
        big_m=[big_m_tmp;[c,test_arr2(idx_unique)]];
        clear big_m_tmp;

        %clear statements
        clear test_arr1; clear test_arr2; clear idx_unique; clear c;
        
    end

  %clear statemetns
  clear idx_find;
    
end

%some sorting to facilitate debugging
big_m_tmp=big_m;
clear big_m;
big_m=sortrows(big_m_tmp,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Removing single entries that occur multiple times%%%%%%%%%%%%%%%%%

%extrema to loop through
min_l=min(big_m(:,2));
max_l=max(big_m(:,2));
    

for q=min_l:max_l
    
    %get it
    idx1=find(big_m(:,2)==q);
    
    if numel(idx1)==1

        %the elements vlaue
        curr_ele=big_m(idx1(1),1);
        
        %look through rest of list
        idx2=find(big_m(:,1)==curr_ele);
        
        if numel(idx2)>0
            
            %counter
            countB=1;
            countC=1;

            for y=1:numel(idx2)
                
                curr_num=big_m(idx2(y),2);
                idx_check=find(big_m(:,2)==curr_num);
                
                if numel(idx_check) == 1 && countB>1
                    idx_remove(countC,1)=idx2(y);
                    countC=countC+1;
                    %big_m(idx2(y),:)=[];
                elseif numel(idx_check)==1 && countB==1
                    countB=countB+1;
                end
                
                %clear statements
                clear curr_num; clear idx_check;
                
            end
            
            if countC>1
                big_m(idx_remove,:)=[];
                clear idx_remove;
            end
            
        end
        
        %clear statements
        clear curr_ele; clear idx2;
        
    end
    
    %clear statements
    clear idx1;
    
end

%sorting for debuggin
big_m_tmp=big_m;
clear big_m;
big_m=sortrows(big_m_tmp,2);
clear big_m_tmp;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Combining sets with common elements%%%%%%%%%%%%%%%%%%%%%%

%extrema to loop through
min_a=min(big_m(:,1));
max_a=max(big_m(:,1));
    

for d=min_a:max_a
   
    %looking
    idx3=find(big_m(:,1)==d);
    
    if numel(idx3)>1
       
        %section
        the_set(:,1)=big_m(idx3,1);
        the_set(:,2)=big_m(idx3,2);
        
        %extrema 
        min_cl=min(the_set(:,2));
        max_cl=max(the_set(:,2));
        
        %counter 
        countE=1;
        
        for a=min_cl:max_cl
            
            %is it in the set
            idxe=find(the_set(:,2)==a);
            
            if numel(idxe)>0
            
                %get element
                ele_idx=find(big_m(:,2)==a);
                
                if countE==1
                    idx_use=a;
                    arr_t=[big_m(ele_idx,1),linspace(idx_use,idx_use,numel(ele_idx))'];
                    countE=countE+1;
                else
                    arr_t_tmp=arr_t;
                    clear arr_t;
                    arr_t=[arr_t_tmp;[big_m(ele_idx,1),linspace(idx_use,idx_use,numel(ele_idx))']];
                    clear arr_t_tmp;
                end
                
   
                
                %remove from big m
                big_m(ele_idx,:)=[];
               
                %clear statements
                clear ele_idx;
                
            end
            
            %clear statement
            clear idxe;
            
        end
        
        %adding back
        if countE>1
            big_m_tmp=big_m;
            clear big_m;
            big_m=[big_m_tmp;arr_t];
            clear big_m_tmp;
            clear arr_t;
     
        end
        
        %clear statements
        clear the_set; clear min_cl; clear max_cl;
        
    end
    
    %clear statements
    clear idx3;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%Going through the list%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Remvoing Redundant Entries%%%%%%%%%%%%%%%%%%%

%extrema to loop through
min_l=min(big_m(:,2));
max_l=max(big_m(:,2));

for j=min_l:max_l
    
    %getting a set
    idx_find=find(big_m(:,2)==j);
    
    if numel(idx_find)>1

        %removing unique values
        test_arr1=big_m(idx_find,1);
        test_arr2=big_m(idx_find,2);
        [c,idx_unique]=unique(test_arr1,'rows');
        
        %removing entry
        big_m(idx_find,:)=[];

        %addin unique set
        big_m_tmp=big_m; 
        clear big_m;
        big_m=[big_m_tmp;[c,test_arr2(idx_unique)]];
        clear big_m_tmp;

        %clear statements
        clear test_arr1; clear test_arr2; clear idx_unique; clear c;
        
    end

  %clear statemetns
  clear idx_find;
    
end

%some sorting to facilitate debugging
big_m_tmp=big_m;
clear big_m;
big_m=sortrows(big_m_tmp,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Putting things back together as cell array%%%%%%%%%%%%%%


%extrema to loop through
min_l=min(big_m(:,2));
max_l=max(big_m(:,2));
    
%counter for cell array    
count_cell=1;

for s=min_l:max_l
    
   %get elements
   idx_now=find(big_m(:,2)==s);
   
   if numel(idx_now)>0
       
       for p=1:numel(idx_now)
          
           if p==1
               arr_tmp=big_m(idx_now(p),1);
           else
               arr_tmp_tmp=arr_tmp;
               clear arr_tmp;
               arr_tmp=[arr_tmp_tmp,big_m(idx_now(p),1)];
               clear arr_tmp_tmp;
           end
           
       end
       
       %load into cell array
       cell_send_back(count_cell,1)={arr_tmp};
       
       %iterate counter
       count_cell=count_cell+1;
       
       %clear statement
       clear arr_tmp;
       
   end
   
   %clear statement
   clear idx_now;

end

    
if count_cell==1
    cell_send_back=0;
end
    
    
    
    



































