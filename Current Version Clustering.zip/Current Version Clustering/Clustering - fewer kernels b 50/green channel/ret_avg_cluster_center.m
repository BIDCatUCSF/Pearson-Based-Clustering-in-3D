function[ret_thing]=ret_avg_cluster_center(in_arr,c_arr)

%intializing
ret_thing=0;

%making doubles
c_arr=double(c_arr);
in_arr=double(in_arr);

%cluster extrema
min_cl=1;
max_cl=max(c_arr);

%counter
count_ret=1;

for k=min_cl:max_cl
    
   %find coordinates of cluster
   idx_c=find(c_arr==k);
   
   if numel(idx_c)>0
       
       if count_ret==1
           clear ret_thing;
       end
       
       %get coordinates of cluster
       ret_thing(count_ret,1)=mean(in_arr(idx_c,1));
       ret_thing(count_ret,2)=mean(in_arr(idx_c,2));
       ret_thing(count_ret,3)=mean(in_arr(idx_c,3));
       
       %iterate counter
       count_ret=count_ret+1;
       
   end
    
    
    %clear statements
    clear idx_c;

end










