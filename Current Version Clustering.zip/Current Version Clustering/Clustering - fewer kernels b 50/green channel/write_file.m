function[]=write_file(the_name,num_tiles,the_data)
%making info string
thing_info=strcat('ImageJ=1.52o images=',num2str(num_tiles),' slices=',num2str(num_tiles),' loop=false min=0.0 max=100000.0 ');

for k=1:num_tiles
    imwrite(the_data(:,:,k),the_name,'WriteMode','append','Compression','none','Description',thing_info);
end








