function[the_cluster_ret]=return_final_cluster_coordinates_v5(xb,yb,zb,size_b,all_pc_now)

%version notes 
% There will be no segmentation done here. 

%inputs
% xb = x center of cluster
% yb = y center of cluster
% zb = z center of cluster
% size_b = width of kernel associated with cluster

%inputs
% all_pc_now(:,1) = x coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,2) = y coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,3) = z coordinates of non-zero elements in pc matrix with this kernel size
% all_pc_now(:,4) = intensity from associated coordinate


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Grabbing the relevant z planes%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%some type conversion
xb=double(xb); yb=double(yb); zb=double(zb);

%some type conversion
all_pc_now=uint16(all_pc_now);
all_pc_now=double(all_pc_now);

%how far up and down to go
delta_z=(uint16(size_b*0.5))+1;
delta_z=double(delta_z);

%lowest and highest z to sample
low_z=uint16(zb)-delta_z; low_z=double(low_z);
high_z=uint16(zb)+delta_z; high_z=double(high_z);

%counter
count_z=1;

for d=low_z:high_z
    
   %indices from a z level
   idx_cb=find(all_pc_now(:,3)==d);
   
   if count_z==1
      sec_now=[all_pc_now(idx_cb,1),all_pc_now(idx_cb,2),all_pc_now(idx_cb,3),all_pc_now(idx_cb,4)];
      count_z=count_z+1;
   else
       sec_now_tmp=sec_now;
       clear sec_now;
       sec_now=[sec_now_tmp;[all_pc_now(idx_cb,1),all_pc_now(idx_cb,2),all_pc_now(idx_cb,3),all_pc_now(idx_cb,4)]];
       clear sec_now_tmp;
   end
    
   %clear statements
   clear idx_cb;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Getting the size of the cluster%%%%%%%%%%%%%%%%%%%%%%%%%%%

%some type conversion
sec_now=double(sec_now);

%figuring out some distances
dist_cb=(((xb-sec_now(:,1)).^2)+((yb-sec_now(:,2)).^2)+((zb-sec_now(:,3)).^2)).^0.5;

%elements within allowed distance based on the size of the kernel
idx_cl_tmp=find(dist_cb<((uint16(size_b*2))));

%further sectioning out the voxels right around my cluster
sec_near(:,1)=sec_now(idx_cl_tmp,1);
sec_near(:,2)=sec_now(idx_cl_tmp,2);
sec_near(:,3)=sec_now(idx_cl_tmp,3);
sec_near(:,4)=sec_now(idx_cl_tmp,4);
sec_near=double(sec_near);


if numel(sec_near(:,4))>6 % 4 is the minimum size of cluster
    
    %clustering the intensities
    IDX=kmeans(sec_near(:,4),4,'emptyaction','singleton','replicates',5,'start','uniform','distance','cityblock');
    IDX1=find(IDX==1);
    IDX2=find(IDX==2);
    IDX3=find(IDX==3);
    IDX4=find(IDX==4);
    
    %figuring out highest and lowrest
    avg_clus(1,1)=1;
    avg_clus(1,2)=mean(sec_near(IDX1,4));
    
    avg_clus(2,1)=2;
    avg_clus(2,2)=mean(sec_near(IDX2,4));
    
    avg_clus(3,1)=3;
    avg_clus(3,2)=mean(sec_near(IDX3,4));
    
    avg_clus(4,1)=4;
    avg_clus(4,2)=mean(sec_near(IDX4,4));
    
    avg_clus_sort=sortrows(avg_clus,2);
    
    if avg_clus_sort(1,1) == 1
        idx_calc=[IDX2;IDX3;IDX4];
    elseif avg_clus_sort(1,1) == 2
        idx_calc=[IDX1;IDX3;IDX4];
    elseif avg_clus_sort(1,1) == 3
        idx_calc=[IDX1;IDX2;IDX4];
    elseif avg_clus_sort(1,1)==4
        idx_calc=[IDX1;IDX2;IDX3];
    end
    
    %pre-allocating for speed
    the_cluster_ret=zeros(numel(idx_calc),4);

    %matrix to return
    for p=1:numel(idx_calc)
        the_cluster_ret(p,1)=sec_near(idx_calc(p),1);
        the_cluster_ret(p,2)=sec_near(idx_calc(p),2);
        the_cluster_ret(p,3)=sec_near(idx_calc(p),3);
        the_cluster_ret(p,4)=sec_near(idx_calc(p),4);
    end
    
else
    the_cluster_ret=0;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%adding the watershedding%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(the_cluster_ret)>1
    center_send_jp=[xb,yb,zb];
    the_cluster_ret_tmp=the_cluster_ret;
    clear the_cluster_ret;
    [the_cluster_ret]=function_watershed_for_cluster(the_cluster_ret_tmp,center_send_jp);
end

%some debugging code
john=10000;

% if size_b == 4 && ct > 3 && ct < 20
%    save(strcat('the_test_spot_',num2str(ct),'.mat'),'the_cluster_ret'); 
%    center_keep=[xb,yb,zb];
%    save(strcat('the_center_',num2str(ct),'.mat'),'center_keep'); 
%    clear center_keep;
% end



%This is the new part where I 

% %thresholding based on PC level
% idx_pc_thresh=find(sec_near(:,4)>pc_search1);
% 
% if numel(idx_pc_thresh)>=10
%     
%     %matrix to return
%     the_cluster_ret(:,1)=sec_near(idx_pc_thresh,1);
%     the_cluster_ret(:,2)=sec_near(idx_pc_thresh,2);
%     the_cluster_ret(:,3)=sec_near(idx_pc_thresh,3);
%     
% else 
%     
%     the_cluster_ret=0;
% 
% end 
%    







