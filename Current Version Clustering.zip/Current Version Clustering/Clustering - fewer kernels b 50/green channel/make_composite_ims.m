function[m_ret,m_ret_mask]=make_composite_ims(m1,m2)

%getting number of images
num_ims=size(m1,3);

%getting dimension
dim1=size(m1,1);
dim2=size(m1,2);

%pre-allocating matrix to return
m_ret=zeros(dim1,dim2,num_ims);
m_ret_mask=m_ret;

%counter
count_c=1;

for a=1:num_ims
    
   %images
   im1=m1(:,:,a);
   im2=m2(:,:,a);
    
   %blank image
   b1=zeros(dim1,dim2);

   %all elements in this slice
   idx_all=find(im1>0);
   b1(idx_all)=1;
   
   %cluster - specific elements
   idx1=find(im1>1);
   idx2=find(im2>1);
   
   %adding cluster specific elements
   if numel(idx1)>0
       b1(idx1)=im1(idx1);
   end
   
   if numel(idx2)>0
       b1(idx2)=im2(idx2);
   end
   
   %adding
   m_ret(:,:,count_c)=b1;
   
   %final mask
   idx_final=find(b1>0);
   b1(idx_final)=1;
   m_ret_mask(:,:,count_c)=b1;
   
   %iterate counter
   count_c=count_c+1;
   
   %clear statements
   clear im1; clear im2; clear im3; clear b1;
   clear idx_all; clear idx1; clear idx2; clear idx3;
   
end












