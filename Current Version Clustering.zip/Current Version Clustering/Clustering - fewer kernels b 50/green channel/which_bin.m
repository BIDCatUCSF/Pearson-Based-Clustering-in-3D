function[ret_bin]=which_bin(theta1,the_arr1)


for p=1:numel(the_arr1(:,1))
    
   if theta1<the_arr1(1,1)
       ret_bin=1;
   elseif theta1>the_arr1(numel(the_arr1(:,1)),2)
        ret_bin=numel(the_arr1(:,1));
   elseif theta1>=the_arr1(p,1) && theta1<=the_arr1(p,2)
        ret_bin=p;
   end
    
end


