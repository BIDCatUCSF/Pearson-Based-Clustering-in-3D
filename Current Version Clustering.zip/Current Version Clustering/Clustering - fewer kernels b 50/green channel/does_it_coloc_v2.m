function[thing_ret,stack_ret,stack_ret_perc,stack_imaris_copy]=does_it_coloc_v2(big_g,big_r,ns,ne,the_dim,criteria_decide)

%total number of images
tot_ims=ne-ns+1;

%stack of images to return 
%stack ret = image stack with all the clusters that colocalize masked by
%'1' 
stack_ret=zeros(the_dim(1),the_dim(2),tot_ims); stack_ret=double(stack_ret);

%stack_ret_perc = image stack with all the clusters that colocalize masked
%by the percentage by which they colocalize.
stack_ret_perc=stack_ret;

%image stack (binary) containing colocalized pixels - meant to mimic Imaris
%output
stack_imaris_copy=stack_ret;

%counter
count_ret=1;

%allocating for return
big_g_ret=big_g;

%extrema of cluster
min_g_cl=min(big_g(:,4));
max_g_cl=max(big_g(:,4));


for j=min_g_cl:max_g_cl
    
   %get a current green cluster
   green_cl_idx=find(big_g(:,4)==j);
   
   if numel(green_cl_idx)>0
       
       %xyz coordinates of green cluster
       the_gr(:,1)=big_g(green_cl_idx,1);%x
       the_gr(:,2)=big_g(green_cl_idx,2);%y
       the_gr(:,3)=big_g(green_cl_idx,3);%z
       
       %counters
       count_dist=0;
       count_teng=1;
       
       %distance calculation
       for k=1:numel(green_cl_idx)
          
           %distance
           dist_arr(:,1)=(((the_gr(k,1)-big_r(:,1)).^2)+((the_gr(k,2)-big_r(:,2)).^2)+((the_gr(k,3)-big_r(:,3)).^2)).^0.5;
           
           %too close
           if criteria_decide==1
             idx_too_close=find(dist_arr(:,1)==0);
           elseif criteria_decide==2
            idx_too_close=find(dist_arr(:,1)<=1);
           end
           
           %there are colocalized pixels
           if numel(idx_too_close)>0
               
               %making the binary mask - like Imaris
               imaris_copy_tmp=stack_imaris_copy(:,:,the_gr(k,3)-ns+1);
               
               %making some indices
               [idx_imaris]=sub2ind(size(imaris_copy_tmp),the_gr(k,2),the_gr(k,1));
               
               %masking
               imaris_copy_tmp(idx_imaris)=1;
               stack_imaris_copy(:,:,the_gr(k,3)-ns+1)=imaris_copy_tmp;
               
               %iterate counter
               count_dist=count_dist+1;
               
               %clear statements
               clear imaris_copy_tmp; clear idx_imaris;
               
               %finding information about the red cluster that colocalizes
               red_clust_num_coloc=big_r(idx_too_close,4);
               
               
               %figuring out the list of red clusters that colocalize
               for b=min(red_clust_num_coloc):max(red_clust_num_coloc)
                  
                   %looking around
                   idx_kev=find(red_clust_num_coloc==b);
                   
                   if numel(idx_kev)>0
                       
                       %individual red clusters that colocalize
                       red_coloc_tmp(count_teng,1)=j; %green cluster that colocalizes
                       red_coloc_tmp(count_teng,2)=b; %red cluster that colocalizes
                       
                       %iterate counter
                       count_teng=count_teng+1;
                       
                   end
                   
                   %clear statement
                   clear idx_kev;
                   
               end
               
           end
           
           %clear statment
           clear dist_arr; clear idx_too_close;
           
       end
      
       %removing duplicate entries
       if count_teng>1
           
           %removal
            red_coloc_tmp
            red_coloc = unique(red_coloc_tmp,'rows')
            
            %clear statement
            clear red_coloc_tmp;
       end
       
       %storing some things - 
       if count_dist>0 && numel(red_coloc(:,1))==1
           
           %returning the percentage of colocalization for the histogram
           thing_ret(count_ret,1)=(count_dist/numel(green_cl_idx)).*100; %colocalization percentage based on area
           thing_ret(count_ret,2)=numel(green_cl_idx); %area of green cluster that colocalizes
           thing_ret(count_ret,3)=j; %number of green cluster that colocalizes
           thing_ret(count_ret,4)=red_coloc(:,2); %number of red cluster that colocalizes
           count_ret=count_ret+1;
           
           %adding a column to the input matrix for percentage of
           %colocalization
           big_g_ret(green_cl_idx,5)=linspace(((count_dist/numel(green_cl_idx)).*100),((count_dist/numel(green_cl_idx)).*100),numel(green_cl_idx))';
           
       elseif count_dist>0 && numel(red_coloc(:,1))>1
           
           
           for v=1:numel(red_coloc(:,1))

               %returning the percentage of colocalization for the histogram
               thing_ret(count_ret,1)=(count_dist/numel(green_cl_idx)).*100; %colocalization percentage based on area
               thing_ret(count_ret,2)=numel(green_cl_idx); %area of green cluster that colocalizes
               thing_ret(count_ret,3)=j; %number of green cluster that colocalizes
               thing_ret(count_ret,4)=red_coloc(v,2); %number of red cluster that colocalizes
               count_ret=count_ret+1;
               
           end
           
           %adding a column to the input matrix for percentage of
           %colocalization
           big_g_ret(green_cl_idx,5)=linspace(((count_dist/numel(green_cl_idx)).*100),((count_dist/numel(green_cl_idx)).*100),numel(green_cl_idx))';
           
       end
       
       %clear statments
       clear the_gr; 
       
   end

       
   %clear statments
   clear green_cl_idx; clear red_coloc;
    
end


count_ret

min_g_cl=min(big_g(:,4))
max_g_cl=max(big_g(:,4))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Creating a binary image stack%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_zero=1

for r=ns:ne
   
    %looking for z
    is_z=find(big_g_ret(:,3)==r);
    
    if numel(is_z)>0
        
        %blank image
        the_blank=zeros(the_dim(1),the_dim(2));
        the_blank=double(the_blank);
        
        %blank image for percemt
        blank_im_perc=the_blank;
        
        %some thresholding to be implemented later
        xk=big_g_ret(is_z,1);
        yk=big_g_ret(is_z,2);
        perc_k=big_g_ret(is_z,5);
        idx_pt=find(perc_k>1);
        
        if numel(idx_pt)>0
            
            %loading up the binary image
            [idx_bin]=sub2ind(size(the_blank),yk(idx_pt),xk(idx_pt));
            the_blank(idx_bin)=1;
            
            %loading the percent image
            blank_im_perc(idx_bin)=perc_k(idx_pt);
            
            %something curious about
            idx_is_zero=find(perc_k<1);
            
            if count_zero==1
                all_zero=idx_is_zero;
                count_zero=count_zero+1;
            else
                all_zero_tmp=all_zero;
                clear all_zero;
                all_zero=[all_zero_tmp;idx_is_zero];
                clear all_zero_tmp;
            end
                
            %clear statements
            clear idx_bin; clear idx_is_zero;
        end
        
        %adding to the stack
        stack_ret(:,:,r-ns+1)=the_blank;
        stack_ret_perc(:,:,r-ns+1)=blank_im_perc;
        
        %some clear statement
        clear the_blank; clear xk; clear yk; clear perc_k; clear idx_pt;
        clear blank_im_perc;
        
    end
    
    %clear statments
    clear is_z;
    
    
end


this_is_zero=all_zero











