function[mat_to_ret]=make_solid_masks(all_coord,cl_centers,the_size_kernel,ns,ne,im1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%initializing matrix with new cluster info%%%%%%%%%%%%%%%%%%%%%%%%

%putting 1's in the 4th column 
all_coord_ret=all_coord;
all_coord_ret(:,4)=zeros(numel(all_coord(:,1)),1);
all_coord_ret(:,4)=all_coord_ret(:,4)+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Assigning spots on each slice to a cluster type%%%%%%%%%%%%%

for q=1:numel(cl_centers(:,1))
   
    %distance calculation
    dist_arr=(((all_coord(:,1)-cl_centers(q,1)).^2)+((all_coord(:,2)-cl_centers(q,2)).^2)+((all_coord(:,3)-cl_centers(q,3)).^2)).^0.5;
    
    %seeing if any coordinates are in cluser
    idx_in_cl=find(dist_arr<=(1.5));
    
    if numel(idx_in_cl)>0
       all_coord_ret(idx_in_cl,4)=the_size_kernel;
    end
    
    %clear statements
    clear dist_arr; clear idx_in_cl;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%Making Cluster Slices%%%%%%%%%%%%%%%%%%%%%%%%%%%

%pre-allocate stack to return
dimA=size(im1,1);
dimB=size(im1,2);
mat_to_ret=zeros(dimA,dimB,ne-ns+1);
mat_to_ret=double(mat_to_ret);

%counter
count_r=1;

for w=ns:ne
   
   %blank image
   blank_im=zeros(dimA,dimB);
   blank_im=double(blank_im);
   
   %locating all coordinates in this slice
   idx_slice=find(all_coord_ret(:,3) == w);
   
   if numel(idx_slice)>0
       
       %xy coordinates
       xall=all_coord_ret(idx_slice,1);
       yall=all_coord_ret(idx_slice,2);
       
       %pearson values
       pall=all_coord_ret(idx_slice,4);
       
       %get indices
       idx_all=sub2ind(size(im1),yall,xall);
       
       %masking
       blank_im(idx_all)=pall;
       
       %clear statements
       clear xall; clear yall; clear pall; clear idx_all;
       
   end
   
   %store in stack to return
   mat_to_ret(:,:,count_r)=blank_im;
   
   %iterate counter
   count_r=count_r+1;
   
   %clear statements
   clear blank_im; clear idx_slice
    
    
end














