function[a_cell,thing_ret]=does_cell_array_colocalize_v2(the_num,a_cell)

%the flag
the_flag=0;

%counter
count_en=1;

for i=1:size(a_cell,1)
    
    %grab a cell array - look at first elements
    thing_tmp=a_cell(i,1);
    thing=thing_tmp{1};
    start_ele=thing(1);
    
    if (the_num == start_ele)
        the_flag=1;
        the_ele=i;
    end
    
    %clear statements
    clear thing_tmp; clear thing; clear start_ele;
    
end



if the_flag == 1
   
    %grabbing the elements
    thing_ret_tmp=a_cell(the_ele,1);
    thing_ret1=thing_ret_tmp{1};
    
    %removing redundancy in final list
    if numel(thing_ret1)==1
        clear thing_ret;
        thing_ret=0;
    else
        thing_ret=thing_ret1(2:(numel(thing_ret1)));
    end
    
    %removing element
    a_cell(the_ele,:)=[];
    
else
    
    thing_ret=0;
    
end