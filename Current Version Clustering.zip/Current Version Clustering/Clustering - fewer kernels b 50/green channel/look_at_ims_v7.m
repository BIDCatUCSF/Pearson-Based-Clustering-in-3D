clear all; close all;

%This is a script written to make renderings in Imaris to hopefully get the
%clearest look at the results of the clustering by correlation

%version 7 projects the cluster # (not just outline) onto the stack of
%images

%Images
file_combined='Final_Cluster_Stack.tif';
%file_orig='Final_Cluster_Stack_NotCombined.tif';
file_gray='Final_ER1_Avg_Stack.tif';

%info 
info_gray=imfinfo(file_combined);
info_gray2=imfinfo(file_gray);
num_images=44;

%paths
dir_start='D:\John\clustering with watershed technique\ROI42\Clustering with watershed technique added -looser watershed and segmentation - More tests\ImarisProjections\';
mkdir(dir_start)
d1=strcat(dir_start,'OrigIms\');
d2=strcat(dir_start,'InClusterIms\');
d3=strcat(dir_start,'NotInClusterIms\');
d4=strcat(dir_start,'Proj1\OrigIms\');
d5=strcat(dir_start,'Proj1\InClusterIms\');
mkdir(d1);
mkdir(d2);
%mkdir(d3);
mkdir(d4);
mkdir(d5);


for i=1:num_images
    i
   %the images
   cluster_tmp=imread(file_combined,i,'Info',info_gray);
   gray_tmp=imread(file_gray,i,'Info',info_gray2);

   %making double
   cluster_tmp=double(cluster_tmp);
   gray_tmp=double(gray_tmp);
   
   %making a mask
   cl_mask=zeros(size(gray_tmp));
   idx_mask=find(cluster_tmp>1);
   idx_not_mask=find(cluster_tmp<=1);
   if numel(idx_mask)>0
      cl_mask(idx_mask)=cluster_tmp(idx_mask);
       
   end
   cl_mask=double(cl_mask);
   
   %saving
   imwrite(uint16(gray_tmp),strcat(d1,'Im',num2str(i),'.tif'));
   imwrite(uint16(cl_mask),strcat(d2,'Im',num2str(i),'.tif'));
   %imwrite(uint16(not_in_cluster),strcat(d3,'Im',num2str(i),'.tif'));
   
   %clear statements
   clear cluster_tmp; clear gray_tmp;
   clear idx_mask; clear cl_mask; 
   clear in_cluster; clear not_in_cluster;
   clear cl_inv_mask; clear idx_not_mask;
   
   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%Double Checking Cluster sizes%%%%%%%%%%%%%%%%%%%%%%%%

% %counter
% count_size=1;
% 
% %extrema
% min_cl=min(cluster_nums(:,1));
% max_cl=max(cluster_nums(:,1));
% 
% for j=min_cl:max_cl
%     
%    idx_john=find(cluster_nums(:,1)==j);
%    
%    if numel(idx_john)>0
%        clust_size(count_size,1)=j;
%        clust_size(count_size,2)=numel(idx_john);
%        count_size=count_size+1;
%    end
%     
%     clear idx_john;
% 
% end
% 
% if count_size>1
%     figure, hist(clust_size(:,2));
% end










