function[im_c_stack_ret]=fill_in_clusters(im_c_stack,im_e_stack,ns,ne)

%This is a function to fill in clusters. Filling just means holes in
%clusters are filled in. watershed in this sort of data is a little prone
%to holes.

%inputs
% im_c_stack = stack of images with clusters numbers
% im_e_stack = stack of images with intensity
% ns = initial index of image stack
% ne = final index of image stack

%outputs
%im_c_stack_ret = stack of cluster images after filling

%closing all open figures
close all;

%counters
count=1;
countA=1;

%creating a return a matrix
im_c_stack_ret=im_c_stack;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%make a list of clusters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=ns:ne
   
    %read in images
    imc=im_c_stack(:,:,countA);
    
    %iterate counter
    countA=countA+1;
    
    %non-zero elements
    idxc=find(imc>0);
    
    if numel(idxc)>0
       
        %convert to coordinates
        [y,x]=ind2sub(size(imc),idxc);
        
        %store 
        if count==1
            all_c=[x,y,linspace(i,i,numel(x))',imc(idxc)];
        else
            all_c_tmp=all_c;
            clear all_c;
            all_c=[all_c_tmp;[x,y,linspace(i,i,numel(x))',imc(idxc)]];
            clear all_c_tmp;
        end
        
        %iterate counter
        count=count+1;
        
        %clear statements
        clear x; clear y;
        
    end
    
    %clear statements
    clear imc; clear idxc;
    
end

%sorting 
all_c_use=sortrows(all_c,4);
all_c_use=double(all_c_use);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%convex hull calculation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count1=1;

for j=min(all_c_use(:,4)):max(all_c_use(:,4))
    
    %look for cluster
    idx1=find(all_c_use(:,4)==j);
    
    if numel(idx1)>0
       
        %coordinates of cluster
        mat_calc=[all_c_use(idx1,1),all_c_use(idx1,2),all_c_use(idx1,3)];
        
        for r=min(mat_calc(:,3)):max(mat_calc(:,3))
            
            %look for slice
            idx_slice=find(mat_calc(:,3)==r);
            
            if numel(idx_slice)>0
                
                %read in cluster image
                imc=im_c_stack(:,:,(r-ns+1));
                
                %read in eroded boundary image
                imt=im_e_stack(:,:,(r-ns+1));
                
                %get centroid
                bw_im=zeros(size(imt));
                bw_im=double(bw_im);
                idx_bw=find(imt>0);
                bw_im(idx_bw)=1;
                c_tmp=regionprops(bw_im,'Centroid');
                c=c_tmp.Centroid;
                
                %calculate angle of cluster
                bound1=[mat_calc(idx_slice,2),mat_calc(idx_slice,1)];
                the_angles=calc_angle(bound1,c(1),c(2),imc);
                the_angles(:,3)=the_angles(:,3)*(180/pi);
                the_angles=sortrows(the_angles,3);
                
                %calculate all angles
                [all_y,all_x]=ind2sub(size(bw_im),idx_bw);
                the_angles_all=calc_angle([all_y,all_x],c(1),c(2),imc);
                the_angles_all(:,3)=the_angles_all(:,3)*(180/pi);
                the_angles_all=sortrows(the_angles_all,3);
                
                %angle extrema
                ang_low=the_angles(1,3);
                ang_high=the_angles(numel(the_angles(:,1)),3);
                
                %initialization
                new_cluster_idx=[];
                
                if abs(ang_high-ang_low)>200
                    
                    %low set of indices
                    idx_low1=1;
                    idx_test1=find(the_angles(:,3)<200);
                    max1=max(the_angles(idx_test1,3));
                    idx_low2_tmp=find(the_angles_all(:,3)<=max1);
                    idx_low2=idx_low2_tmp(numel(idx_low2_tmp));
                    
                    %high set of indices
                    idx_high2=numel(the_angles_all(:,3));
                    idx_test2=find(the_angles(:,3)>200);
                    min2=min(the_angles(idx_test2,3));
                    idx_high1_tmp=find(the_angles_all(:,3)>=min2);
                    idx_high1=idx_high1_tmp(1);
                    
                    new_cluster_idx=[[idx_low1:idx_low2]';[idx_high1:idx_high2]'];
                    
                    %clear statements
                    clear idx_low1; clear idx_test1; clear max1;
                    clear idx_low2; clear idx_high2; clear idx_high1; 
                    clear min2; clear idx_high1_tmp; clear idx_low2_tmp;
                        
                    
                else
                    
                    %low index
                    idx_low_tmp=find(the_angles_all(:,3)>=ang_low);
                    if numel(idx_low_tmp)>0
                        idx_low=idx_low_tmp(1);
                    else
                        idx_low=1;
                    end
                    
                    %high index
                    idx_high_tmp=find(the_angles_all(:,3)<=ang_high);
                    if numel(idx_high_tmp)>0
                        idx_high=idx_high_tmp(numel(idx_high_tmp));
                    else
                        idx_high=numel(the_angles_all(:,3));
                    end
                    
                    %new indices of cluster
                    new_cluster_idx=idx_low:idx_high;
                    
                end
       
                
                %adjusting and storing new images
                for b=1:numel(new_cluster_idx)
                    imc(the_angles_all((new_cluster_idx(b)),2),the_angles_all((new_cluster_idx(b)),1))=j;
                end
                
                %plots for debugging
                if r==69
%                     figure, imagesc(imt); colormap(gray); colorbar; hold on; title(num2str(r));
%                     plot(the_angles_all((new_cluster_idx),1),the_angles_all((new_cluster_idx),2),'g+');
                 %   plot(the_angles(:,1),the_angles(:,2),'r+');
                 
                 figure, imagesc(imc); colormap(gray); colorbar; title(num2str(r))
                 
                end
                
                %saving
                im_c_stack_ret(:,:,r-ns+1)=imc;
                im_c_stack(:,:,(r-ns+1))=imc;
                %imwrite(uint16(imc),strcat(path_c,num2str(r),'.tif'));
                

                %clear statements
                clear imc; clear imt; clear bw_im; clear idx_bw;
                clear c_tmp; clear c; clear bound1; clear the_angles;
                clear all_y; clear all_x; clear the_angles_all;
                clear ang_low; clear ang_high; clear idx_low; clear idx_high;
                clear new_cluster_idx;
                
            end
            
            %clear statements
            clear idx_slice;
            
        end
        
        %clear statements
        clear mat_calc;
        
    end
    
    %clear statements
    clear idx1;
    
end

