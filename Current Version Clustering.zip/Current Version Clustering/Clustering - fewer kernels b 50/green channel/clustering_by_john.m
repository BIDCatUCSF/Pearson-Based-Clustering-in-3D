function[clust_center]=clustering_by_john(in_arr)

%inputs
% in_arr(:,1)=x coordinates
% in_arr(:,2)=y coordinates
% in_arr(:,3)=z coordinates


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%The code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%adding some columns
in_arr(:,4)=linspace(1,1,numel(in_arr(:,3)))'; %flag
in_arr(:,5)=[1:numel(in_arr(:,3))]'; %number in matrix

for i=1:numel(in_arr(:,3))
   
    %some coordinates
    x1=in_arr(i,1);
    y1=in_arr(i,2);
    z1=in_arr(i,3);
    f1=in_arr(i,4);
    
    if f1==1
    
        %removing element
        in_arr_tmp=in_arr;
        in_arr_tmp(i,:)=[];
        
        %calculate distances
        d_arr=(((x1-in_arr_tmp(:,1)).^2)+((y1-in_arr_tmp(:,2)).^2)+((z1-in_arr_tmp(:,3)).^2)).^0.5;
        
        %look for point nearby
        idx_look=find(d_arr<=3);
        
        if numel(idx_look)>0
            for r=1:numel(idx_look)
                in_arr(in_arr_tmp(idx_look(r),5),4)=0;
            end
        end
        
        %clear statements
        clear in_arr_tmp; clear d_arr; clear idx_look;
        
    end
    
    %clear statements
    clear x1; clear y1; clear z1; clear f1;
    
end

%making the return
idx_back=find(in_arr(:,4)==1);
clust_center(:,1)=in_arr(idx_back,1);
clust_center(:,2)=in_arr(idx_back,2);
clust_center(:,3)=in_arr(idx_back,3);







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %getting the size
% the_size=numel(in_arr(:,1));
% 
% %counter
% count=1;
% 
% while the_size>0
%     
%     %some coordinates
%     x1=in_arr(1,1);
%     y1=in_arr(1,2);
%     z1=in_arr(1,3);
%     
%     %remove from list
%     in_arr(1,:)=[];
%     
%     if numel(in_arr(:,1))>1
%         
%         %calculate distances
%         d_arr=(((x1-in_arr(:,1)).^2)+((y1-in_arr(:,2)).^2)+((z1-in_arr(:,3)).^2)).^0.5;
%         
%         %look for point nearby
%         idx_look=find(d_arr<=3);
%         
%         if numel(idx_look)>0
%             
%             %storing
%             clust_center(count,1)=mean([x1;in_arr(idx_look,1)]);
%             clust_center(count,2)=mean([y1;in_arr(idx_look,2)]);
%             clust_center(count,3)=mean([z1;in_arr(idx_look,3)]);
%             
%             %iterate counter
%             count=count+1;
%             
%             %remove elements from in_arr matrix
%             in_arr(idx_look,:)=[];
%             
%         else
%             
%             %storing
%             clust_center(count,1)=x1;
%             clust_center(count,2)=y1;
%             clust_center(count,3)=z1;
%             
%             %iterate counter
%             count=count+1;
%             
%         end
%         
%     else
%         
%         %storing
%         clust_center(count,1)=x1;
%         clust_center(count,2)=y1;
%         clust_center(count,3)=z1;
%         
%         %iterate counter
%         count=count+1;
%         
%     end
%     
%     %re-declare what the size is
%     the_size=numel(in_arr(:,1));
%     
%     %clear statements
%     clear x1; clear y1; clear z1;
%     clear idx_look; clear d_arr;
% end

















