function[]=create_small_proj(cell_in)

%total number of images
num_ims=size(cell_in,1)


%getting the extrema
for j=1:num_ims
    j
   %coordinate lists
   a_list_tmp=cell_in(j,3);
   a_list=a_list_tmp{1};
   
   %convert to angle
   a_list(:,3)=a_list(:,3).*(180/pi);
   
   %storing some info
   some_info(j,1)=min(a_list(:,3));
   some_info(j,2)=max(a_list(:,3));
   some_info(j,3)=numel(a_list(:,3));
   
   %clear statements
   clear a_list_tmp; clear a_list;
    
    
end

%extrema
the_length=min(some_info(:,3))
low_ang=min(some_info(:,1))
high_ang=max(some_info(:,2))
incre=uint16((high_ang-low_ang)/the_length);

for k=1:the_length
    
    if k==1
        low_lim=low_ang;
        high_lim=low_lim+incre;
    else
        low_lim=high_lim;
        high_lim=low_lim+incre;
    end
    
    lim_arr(k,1)=low_lim;
    lim_arr(k,2)=high_lim;

end

%pre-allocating for projection to return
the_proj_ret_int=zeros(num_ims,the_length);
the_proj_ret_clust=zeros(num_ims,the_length);

for s=1:num_ims

    %coordinate lists
    a_list_tmp=cell_in(s,3);
    a_list=a_list_tmp{1};
    
    int_im_tmp=cell_in(s,1);
    int_im=int_im_tmp{1};
    
    clust_im_tmp=cell_in(s,2);
    clust_im=clust_im_tmp{1};

    
    for t=1:a_list(:,1)
        
        %angle
        theta_now=a_list(t,3).*(180/pi);
        
        %bin
        [the_bin]=which_bin(theta_now,lim_arr)
        
        %index
        [idx_now]=sub2ind(size(int_im),a_list(t,2),a_list(t,1));
        
        %loading
        the_proj_ret_int(s,the_bin)=int_im(idx_now);
        the_proj_ret_clust(s,the_bin)=clust_im(idx_now);
        
        clear theta_now;
        
    end

    clear a_list_tmp; clear a_list; 
    clear int_im_tmp; clear int_im;
    clear clust_im; clear clust_im_tmp;

end

figure, surf(the_proj_ret_int); colormap(gray); colorbar; title('Intensity'); axis tight; shading interp;
figure, surf(the_proj_ret_clust); colormap(jet); colorbar; title('Clusters');axis tight; shading interp;














