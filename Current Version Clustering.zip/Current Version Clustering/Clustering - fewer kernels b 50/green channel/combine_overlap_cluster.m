function[cell_arr_final]=combine_overlap_cluster(c)

%inputs
%c(:,1) = cluster #'s
%c(:,2) = clusters that overlap with cluster in column 1
%c(:,3) = percentage overlap (by area)

%outputs
%cell_arr_final = Each element in this cell array contains a list of
%entries in c. 
%For example, cell_arr_final(1,1) may equal [1,2,3,4]
%This means that cluster #'s {1,2,3,4} should be combined to form a cluster

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%testing it out%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%step 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%make a copy
c_tmp=c;

%master counter
count_master=1;

loop_length=numel(c_tmp(:,1));

for i=1:loop_length

    if numel(c_tmp(:,1))>0
        
        %does this cluster colocalize with another?
        
        if c_tmp(1,3)>=35 % was 80
            
            %counter
            count=1;
            
            %current cluster
            c_now=c_tmp(1,1);
            
            %cluster that colocalizes with
            c_now2=c_tmp(1,2);
            
            %remove this element from the list
            c_tmp(1,:)=[];
            
            %current list of colocalize coordinates
            list_now(count)=c_now;
            list_now(count+1)=c_now2;
            
            %iterate counter
            count=count+2;
            
            %does this cluster colocalize with another cluster
            [c_tmp_ret,coloc_nums_ret,colocalize_flag]=does_it_colocalize(c_now2,c_tmp);
            
            %re-initializing matrix
            clear c_tmp;
            c_tmp=c_tmp_ret;
            clear c_tmp_ret;
            
            %ok, something here colocalizes - add it to the list
            if colocalize_flag == 1
                %add to list
                for s=1:numel(coloc_nums_ret)
                    list_now(count)=coloc_nums_ret(s);
                    count=count+1;
                end
            end
            
            %store list
            cell_list(count_master,1)={list_now};
            
            %iterate counter
            count_master=count_master+1;
            
            %clear statements
            clear c_now; clear c_now2;
            clear list_now;
            
        else
            
            %adding to cell array
            cell_list(count_master,1)={c_tmp(1,1)};
            
            %iterate counter
            count_master=count_master+1;
            
            %removing
            c_tmp(1,:)=[];
        end
        
    end
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%testing it out step2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%make a copy
cell_list_tmp=cell_list;

%counter
final_counter=1;

for q=1:count_master

    while size(cell_list_tmp,1)>0
    
        %grab the last element of cell array
        the_cell_tmp=cell_list_tmp(size(cell_list_tmp,1),1);
        the_cell=the_cell_tmp{1};
        
        %removing from cell array
        cell_list_tmp(size(cell_list_tmp,1),:)=[];
        
        if numel(the_cell)==1
            cell_arr_final(final_counter,1)={the_cell};
            final_counter=final_counter+1;
        else
        
            %what is last number
            last_num=the_cell(numel(the_cell));
        
            %counter
            count_tay=1;
            
            %flag
            coloc_ele_ret=1000;
            
            while coloc_ele_ret > 0
            
                if count_tay==1
                    
                    %iterate counter
                    count_tay=count_tay+1;
                    
                    %look through cell array for colocalization
                    [cell_list_tmp_ret,coloc_ele_ret]=does_cell_array_colocalize_v2(last_num,cell_list_tmp);
                    
                    %yeah
                    clear cell_list_tmp;
                    cell_list_tmp=cell_list_tmp_ret;
                    
                    %adding to list
                    if coloc_ele_ret ~= 0
                        the_cell_tmp=the_cell;
                        clear the_cell;
                        the_cell=[the_cell_tmp,coloc_ele_ret];
                        clear the_cell_tmp;
                    end
                    
                else
                    
                    %getting the last number
                    clear last_num;
                    last_num=coloc_ele_ret(numel(coloc_ele_ret));
                    
                    %look through cell array for colocalization
                    [cell_list_tmp_ret,coloc_ele_ret]=does_cell_array_colocalize_v2(last_num,cell_list_tmp);
                    
                    %yeah
                    clear cell_list_tmp;
                    cell_list_tmp=cell_list_tmp_ret;
                    
                    %adding to list
                    if coloc_ele_ret ~= 0
                        the_cell_tmp=the_cell;
                        clear the_cell;
                        the_cell=[the_cell_tmp,coloc_ele_ret];
                        clear the_cell_tmp;
                    end
                    
                    %iterate counter
                    count_tay=count_tay+1;
                    
                end
            
            end
            
            %loading
            cell_arr_final(final_counter,1)={the_cell};
            final_counter=final_counter+1;
            
        end
        
        
        
        %clear statements
        clear the_cell_tmp; clear the_cell;
    
    end
    

end

%in order to insure that there is something to return
if final_counter == 1
    cell_arr_final=0;
end



















