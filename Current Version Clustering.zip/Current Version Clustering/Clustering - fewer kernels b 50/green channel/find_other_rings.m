function[in1_ret,in1_copy_ret]=find_other_rings(in1,in1_copy,flag1,flag2,idx_center)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%other rings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%the distance calculation (euclidean)
d_r2=(((in1(:,1)-in1_copy(idx_center(1),1)).^2)+((in1(:,2)-in1_copy(idx_center(1),2)).^2)).^0.5;

%replacing the distances
in1(:,7)=d_r2;

%indices - ring 1
idx_ring1=find(in1_copy(:,3)==flag1);

%counter
count_r2=1;

for j=1:numel(idx_ring1)
    
    %angle
    ring1_ang_now=in1_copy(idx_ring1(j),8);
    
    %look for angle
    ang_next_tmp=abs(in1(:,8)-ring1_ang_now);
    idx_ang_next=find(ang_next_tmp<=30);
    
    if numel(idx_ang_next)>0
        
        in1_sect=in1(idx_ang_next,:);
        
        %find spot on ring 2
        in1_sect_sort=sortrows(in1_sect,7);
        in1_copy(in1_sect_sort(1,6),3)=700;
        
        dist_r2(count_r2,1)=(in1_sect_sort(1,7));
        count_r2=count_r2+1;
   
        %remove from in1
        idx_bad2=find(in1(:,6)==in1_sect_sort(1,6));
        in1(idx_bad2,:)=[];
    
    end
    
    clear ring1_ang_now;
    clear ang_next_tmp; clear in1_sect; 
    clear in1_sect_sort;
    clear idx_bad2;
    
end

%getting the rest
if count_r2>1
    min_dist_r2=min(dist_r2);
    max_dist_r2=max(dist_r2);
    
    for r=1:numel(in1(:,1))
        
        if in1(r,7)>(min_dist_r2-0.5) && in1(r,7)<(max_dist_r2+0.5)
            in1_copy(in1(r,6),3)=flag2;
            in1(r,6)=10000;
        end
        
    end
    idx_bad3=find(in1(:,6)==10000);
    if numel(idx_bad3)>0
        in1(idx_bad3,:)=[];
    end
    
    idx_r2=find(in1_copy(:,3)==flag2);
%     if flag2==700
%         plot(in1_copy(idx_r2,1),in1_copy(idx_r2,2),'cx','Linewidth',4,'MarkerSize',16);
%     else
%         plot(in1_copy(idx_r2,1),in1_copy(idx_r2,2),'yx','Linewidth',4,'MarkerSize',16);
%     end
end
%creating matrices to return
in1_ret=in1;
in1_copy_ret=in1_copy;

