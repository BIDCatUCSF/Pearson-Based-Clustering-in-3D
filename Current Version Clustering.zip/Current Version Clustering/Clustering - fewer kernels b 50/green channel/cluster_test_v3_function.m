function[avg_stack,avg_mask_stack,cluster_stack,tot_num_cl,tot_area_cl]=cluster_test_v3_function(path_p_small2,path_p_medium,path_p_medium2,path_p_big,path_er_ims,path_bound,p_thresh,ns,ne,pc_search_in,save_or_not)

pc_search_in

% clear all; close all;
% 
% %pearson threshold
% p_thresh=55;
% 
% %image indices
% ns=34;
% ne=73;
% 
% %2d pearson matrics
% % p2d_small_tmp=imread('f:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\smaller size - with sort - green channel\Domain Size Tests\Proj 2d\proj_2d_SMALL_Pearsons_ims_roi45_green.btf');
% % p2d_medium_tmp=imread('f:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\medium size - with sort - green channel\Domain Size Tests\Proj 2d\proj_2d_MEDIUM_Pearsons_ims_roi45_green.btf');
% % p2d_big_tmp=imread('f:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\bigger size - with sort - green channel\Domain Size Tests\Proj 2d\proj_2d_BIG_Pearsons_ims_roi45_green.btf');
% 
% 
% %paths
% % path_p_small='E:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\proj 2d type 1 tests\smaller size - with sort - green channel\Domain Size Tests\Proj 2d\PearsonsIms\im';
% % path_e_small='E:\en project\Oct2018 Images\Misc Code\Domain Size Tests\Initial Tests\results - real data ROI45\proj 2d type 1 tests\smaller size - with sort - green channel\Domain Size Tests\Proj 2d\ErodeIms\im';
% 
% path_p_small2='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\smaller2 size - with sort - green channel\Proj 2d\PearsonsIms\im';
% path_e_small2='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\smaller2 size - with sort - green channel\Proj 2d\ErodeIms\im';
% 
% path_p_medium='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\medium size - with sort - green channel\Proj 2d\PearsonsIms\im';
% path_e_medium='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\medium size - with sort - green channel\Proj 2d\ErodeIms\im';
% 
% path_p_medium2='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\medium2 size - with sort - green channel\Proj 2d\PearsonsIms\im';
% path_e_medium2='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\medium2 size - with sort - green channel\Proj 2d\ErodeIms\im';
% 
% path_p_big='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\bigger size - with sort - green channel\Proj 2d\PearsonsIms\im';
% path_e_big='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\bigger size - with sort - green channel\Proj 2d\ErodeIms\im';
% 
% path_er_ims='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\smaller2 size - with sort - green channel\CroppedFiles\green0\ErodedBoundaryImages\MaskBoundErode';
% path_bound='E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide v2 proj\ROI40\results - real data ROI40\proj 2d type 1 tests\smaller2 size - with sort - green channel\CroppedFiles\green0\The_Boundaries\Bound';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%average the boundary%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get average boundary
[cell_erode_avg_ret_now,frame_list_ret_now]=avg_erode_bound(path_er_ims,path_bound,ns,ne);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%getting non-zero entries%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counters
count_small=1;
count_small2=1;
count_medium=1;
count_medium2=1;
count_big=1;
count_orient=1;

for i=ns:ne
    
    %reading in the Pearson Images
    p_small_im2=imread(strcat(path_p_small2,num2str(i-ns+1),'.tif'));
%    p_medium_im=imread(strcat(path_p_medium,num2str(i-ns+1),'.tif'));
    p_medium_im2=imread(strcat(path_p_medium2,num2str(i-ns+1),'.tif'));
    p_big_im=imread(strcat(path_p_big,num2str(i-ns+1),'.tif'));
    
    %Intensity Images
    im_check_tmp=cell_erode_avg_ret_now(count_orient,1);
    im_check=im_check_tmp{1};
    count_orient=count_orient+1;
    
    %making a copy and verifying orientation
    if i==ns
        
        %make a copy
        im_keep=p_small_im2;

        %make binary images
        idx1=find(im_keep>0);
        idx2=find(im_check>0);
        bin1=zeros(size(im_keep)); bin1(idx1)=1;
        bin2=zeros(size(im_check)); bin2(idx2)=1;
        bin3=bin1+bin2;
        idx3=find(bin3>0);
        
        
        if numel(idx3)~=numel(idx2) 
           do_transpose = 0; 
        else
            do_transpose = 1; 
        end

    end
    
    %making double
    %p_small_im=double(p_small_im);
    if do_transpose==1
        p_small_im2=double(p_small_im2');
       % p_medium_im=double(p_medium_im');
        p_medium_im2=double(p_medium_im2');
        p_big_im=double(p_big_im');
    else
        p_small_im2=double(p_small_im2);
      % p_medium_im=double(p_medium_im);
        p_medium_im2=double(p_medium_im2);
        p_big_im=double(p_big_im);
        im_check=im_check';
    end
    
    %cropping
    dim1=size(p_small_im2,1);
    im_check_crop=imcrop(im_check,[1,1,dim1-1,dim1-1]);
    
    %making another copy
    if i==ns
        im_keep1=p_small_im2;
    end
    
%     figure, imagesc(im_check_crop); title('Intensity Mask'); colorbar;
%     figure, imagesc(p_big_im); title('Pearson'); colorbar;
    
    %non zero elements
   % idx_small=find(p_small_im >= p_thresh);
    idx_small2=find(p_small_im2 >= p_thresh);
   % idx_medium=find(p_medium_im >= p_thresh);
    idx_medium2=find(p_medium_im2 >= p_thresh);
    idx_big=find(p_big_im >= p_thresh);
    
    %making indices coordinates
    [ysmall2,xsmall2]=ind2sub(size(p_small_im2),idx_small2);
   % [ymedium,xmedium]=ind2sub(size(p_medium_im),idx_medium);
    [ymedium2,xmedium2]=ind2sub(size(p_medium_im2),idx_medium2);
    [ybig,xbig]=ind2sub(size(p_big_im),idx_big);

    %getting the coordinate lists - small - 2
    if numel(idx_small2)>0
        %get list
        ret_list_small2(:,1)=xsmall2;
        ret_list_small2(:,2)=ysmall2;
        ret_list_small2(:,3)=linspace(i,i,numel(idx_small2))';
        ret_list_small2(:,4)=im_check_crop(idx_small2);
        ret_list_small2(:,5)=p_small_im2(idx_small2);
        
        if count_small2==1
            list_small2=ret_list_small2;
            count_small2=count_small2+1;
        else
            list_small2_tmp=list_small2;
            clear list_small2;
            list_small2=[list_small2_tmp;ret_list_small2];
            clear list_small2_tmp;
        end
        
        %clear statement
        clear ret_list_small2;
        
    end
    
    %getting the coordinate lists - medium
%     if numel(idx_medium)>0
%         %get list
%         ret_list_medium(:,1)=xmedium;
%         ret_list_medium(:,2)=ymedium;
%         ret_list_medium(:,3)=linspace(i,i,numel(idx_medium))';
%         ret_list_medium(:,4)=im_check_crop(idx_medium);
%         ret_list_medium(:,5)=p_medium_im(idx_medium);
%         
%         if count_medium==1
%             list_medium=ret_list_medium;
%             count_medium=count_medium+1;
%         else
%             list_medium_tmp=list_medium;
%             clear list_medium;
%             list_medium=[list_medium_tmp;ret_list_medium];
%             clear list_medium_tmp;
%         end
%         
%         %clear statement
%         clear ret_list_medium;
%         
%     end
    
    %getting the coordinate lists - medium2
    if numel(idx_medium2)>0
        %get list
        ret_list_medium2(:,1)=xmedium2;
        ret_list_medium2(:,2)=ymedium2;
        ret_list_medium2(:,3)=linspace(i,i,numel(idx_medium2))';
        ret_list_medium2(:,4)=im_check_crop(idx_medium2);
        ret_list_medium2(:,5)=p_medium_im2(idx_medium2);
        
        if count_medium2==1
            list_medium2=ret_list_medium2;
            count_medium2=count_medium2+1;
        else
            list_medium2_tmp=list_medium2;
            clear list_medium2;
            list_medium2=[list_medium2_tmp;ret_list_medium2];
            clear list_medium2_tmp;
        end
        
        %clear statement
        clear ret_list_medium2;
        
    end
     
    %getting the coordinate lists - big
    if numel(idx_big)>0
        %get list
        ret_list_big(:,1)=xbig;
        ret_list_big(:,2)=ybig;
        ret_list_big(:,3)=linspace(i,i,numel(idx_big))';
        ret_list_big(:,4)=im_check_crop(idx_big);
        ret_list_big(:,5)=p_big_im(idx_big);
    
        if count_big==1
            list_big=ret_list_big;
            count_big=count_big+1;
        else
            list_big_tmp=list_big;
            clear list_big;
            list_big=[list_big_tmp;ret_list_big];
            clear list_big_tmp;
        end
        
        %clear statements
        clear ret_list_big;
        
    end
     
        
    %clear statements
    clear idx_small; clear idx_medium; clear idx_big; clear idx_medium2; clear idx_small2;
    clear p_small_im; clear p_medium_im; clear p_big_im; clear p_medium_im2; 
    clear p_small_im2;clear xsmall2; clear ysmall2;  clear xmedium; clear ymedium; clear xmedium2; 
    clear ymedium2; clear xbig; clear ybig;
    clear im_check_tmp; clear im_check; clear im_check_crop; clear dim1;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%doing the clustering%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%list_small2_tmp=find_prelim_peaks(list_small2);
%list_medium_tmp=find_prelim_peaks(list_medium);
list_medium2_tmp=find_prelim_peaks(list_medium2);
list_big_tmp=find_prelim_peaks(list_big);

%a new clustering idea
%[ret_thing_small2]=clustering_by_john(list_small2_tmp);
%[ret_thing_medium]=clustering_by_john(list_medium_tmp);
[ret_thing_medium2]=clustering_by_john(list_medium2_tmp);
[ret_thing_big]=clustering_by_john(list_big_tmp);

% final_list_test=[ret_thing_small2;ret_thing_medium;ret_thing_medium2;ret_thing_big];
% close all;

%getting average positions of the clusters - rough idea
%[ret_thing_small]=ret_avg_cluster_center(list_small,class_small);
% [ret_thing_small2]=ret_avg_cluster_center(list_small2,class_small2);
% [ret_thing_medium]=ret_avg_cluster_center(list_medium,class_medium);
% [ret_thing_medium2]=ret_avg_cluster_center(list_medium2,class_medium2);
% [ret_thing_big]=ret_avg_cluster_center(list_big,class_big);


%getting the more precise positions of the clusters
%original
%[final_list_test,all_pc_small2,all_pc_medium,all_pc_medium2,all_pc_big,small_centers_w_pc2,medium_centers_w_pc,medium_centers_w_pc2,big_centers_w_pc]=return_likely_cluster_centers(ret_thing_small2,ret_thing_medium,ret_thing_medium2,ret_thing_big,path_p_small2,path_p_medium,path_p_medium2,path_p_big,ns,ne);

%getting the more precise positions of the clusters
%modified
[final_list_test]=return_likely_cluster_centers_v4(ret_thing_big,path_p_big,ns,ne);


close all; 
%debugging - checking this output - final assignment of cluster center
%check_outputs4(final_list_test,small_centers_w_pc,medium_centers_w_pc,big_centers_w_pc);

% ret_thing_small
% ret_thing_medium
% ret_thing_big
% final_list_test
% 
% 
% %making a debugging figure
% figure, hold on
% plot3(ret_thing_small(:,1),ret_thing_small(:,2),ret_thing_small(:,3),'ro','MarkerSize',12,'LineWidth',1.5);
% plot3(ret_thing_medium(:,1),ret_thing_medium(:,2),ret_thing_medium(:,3),'go','MarkerSize',12,'LineWidth',1.5);
% plot3(ret_thing_big(:,1),ret_thing_big(:,2),ret_thing_big(:,3),'co','MarkerSize',12,'LineWidth',1.5);
% plot3(final_list_test(:,1),final_list_test(:,2),final_list_test(:,3),'k+','MarkerSize',12,'LineWidth',1.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%getting the averaged intensity images%%%%%%%%%%%%%%%%%%%

%counter
count_maybe=1;

for m=ns:ne
   
    %get the image
    int_image_tmp=cell_erode_avg_ret_now(count_maybe,1);
    int_image=int_image_tmp{1};
    
    %transpose
    int_image=int_image';
    
    %making coordinate list
    idx_may=find(int_image>0);
    
    if numel(idx_may)>0
        
        %convert to coordinates
        [y_may,x_may]=ind2sub(size(int_image),idx_may);
        z_may=linspace(m,m,numel(idx_may));
        int_may=int_image(idx_may);
        
        if count_maybe == 1
            all_int_info=[x_may,y_may,z_may',int_may];
        else
            all_int_info_tmp=all_int_info;
            clear all_int_info;
            all_int_info=[all_int_info_tmp;[x_may,y_may,z_may',int_may]];
            clear all_int_info_tmp;
        end
        
        %clear statements
        clear x_may; clear y_may; clear z_may; clear int_may;
        
    end
    
    %iterate counter
    count_maybe=count_maybe+1;
    
    %clear statements
    clear idx_may; clear int_image_tmp; clear int_image;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Refining the size and position%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%of cluster%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_cb1=1;

%total number of clusters
tot_num_clusters=numel(final_list_test(:,1));

%going through the list of likely cluster centers
for b=1:numel(final_list_test(:,1))
   b
    %get the center of cluster
    xcb=final_list_test(b,1);
    ycb=final_list_test(b,2);
    zcb=final_list_test(b,3);
    
    %get the kernel size
    size_cb=(final_list_test(b,5));
    
    if size_cb==3
        c1_tmp=return_final_cluster_coordinates_v4(xcb,ycb,zcb,size_cb,all_int_info)
       %c1_tmp=return_final_cluster_coordinates_v2(xcb,ycb,zcb,size_cb,all_pc_small,pc_search_in); 
       %c1_tmp=return_final_cluster_coordinates(xcb,ycb,zcb,size_cb,all_pc_small); 
    elseif size_cb==5
        c1_tmp=return_final_cluster_coordinates_v4(xcb,ycb,zcb,size_cb,all_int_info)
        %c1_tmp=return_final_cluster_coordinates_v2(xcb,ycb,zcb,size_cb,all_pc_medium,pc_search_in); 
        %c1_tmp=return_final_cluster_coordinates(xcb,ycb,zcb,size_cb,all_pc_medium); 
    elseif size_cb==7
        c1_tmp=return_final_cluster_coordinates_v4(xcb,ycb,zcb,size_cb,all_int_info); 
       % c1_tmp=return_final_cluster_coordinates_v2(xcb,ycb,zcb,size_cb,all_pc_big,pc_search_in); 
         %c1_tmp=return_final_cluster_coordinates(xcb,ycb,zcb,size_cb,all_pc_big); 
    elseif size_cb==4
        c1_tmp=return_final_cluster_coordinates_v4(xcb,ycb,zcb,size_cb,all_int_info)
        %c1_tmp=return_final_cluster_coordinates_v2(xcb,ycb,zcb,size_cb,all_pc_small2,pc_search_in);
         %c1_tmp=return_final_cluster_coordinates(xcb,ycb,zcb,size_cb,all_pc_small2);
    elseif size_cb==6
        c1_tmp=return_final_cluster_coordinates_v4(xcb,ycb,zcb,size_cb,all_int_info)
        %c1_tmp=return_final_cluster_coordinates_v2(xcb,ycb,zcb,size_cb,all_pc_medium2,pc_search_in);
         %c1_tmp=return_final_cluster_coordinates(xcb,ycb,zcb,size_cb,all_pc_medium2);
    end
 
    if numel(c1_tmp)>1
        
        %adding a column to indicate the number of the cluster
        c1_tmp(:,4)=linspace(b,b,numel(c1_tmp(:,1)))';
        
        %storing
        if count_cb1==1 && numel(c1_tmp(:,1)>4)
            final_cl_result=c1_tmp;
            count_cb1=count_cb1+1;
        elseif count_cb1>1 && numel(c1_tmp(:,1)>4)
            final_cl_result_tmp=final_cl_result;
            clear final_cl_result;
            final_cl_result=[final_cl_result_tmp;c1_tmp];
            clear final_cl_result_tmp;
        end
    end
    
    %clear statements
    clear xcb; clear ycb; clear zb;
    clear size_cb; clear c1_tmp;
    
end

final_cl_result

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%This is the step where is I combine touching cluster%%%%%%%%%%%

%getting the percentage of overlap
matrix_of_overlap_precentages=does_it_coloc_v3(final_cl_result,final_cl_result);

%figuring out which clusters touch
[map_to_combine_clusters_tmp]=combine_overlap_cluster(matrix_of_overlap_precentages);

%screening step
[map_to_combine_clusters]=final_screen_to_combine_clusters(map_to_combine_clusters_tmp);

%refining list
 final_cl_result_tmp=final_cl_result;
 clear final_cl_result;
 [final_cl_result_before_last_filt]=combine_cluster_after_screen(final_cl_result_tmp,map_to_combine_clusters);
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%This is last quality control step written to eliminate spurious clusters 
%final_cl_result=final_cl_result_before_last_filt;
final_cl_result=cluster_quality_control_v2(final_cl_result_before_last_filt);
close all;
 
 idxA=find(uint16(final_cl_result(:,3)==95));
 %plot(final_cl_result(idxA,1),final_cl_result(idxA,2),'m+','LineWidth',1.5,'MarkerSize',12);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%some debugging
the_bar=colormap(jet);

high_cl_orig=max(final_cl_result(:,4));
figure, hold on; title('Screened Clusters')
for i=1:numel(final_cl_result(:,1))
    
     %get a cluster
    idx_de=find(final_cl_result(:,4)==i);
    
    %get a color
    the_color=uint16(64.*(i/high_cl_orig));
    if the_color<1
        the_color=1;
    end
    if the_color>64
        the_color=64;
    end
    
    plot3(final_cl_result(idx_de,1),final_cl_result(idx_de,2),final_cl_result(idx_de,3),'ko','MarkerSize',12,'LineWidth',1.5,'MarkerEdgeColor',the_bar(the_color,:));
    
    clear the_color; clear idx_de;
    
end
figure, hold on; title('Original Clusters')
high_cl_orig=max(final_cl_result_tmp(:,4));
for i=1:numel(final_cl_result_tmp(:,1))
    
     %get a cluster
    idx_de=find(final_cl_result_tmp(:,4)==i);
    
    %get a color
    the_color=uint16(64.*(i/high_cl_orig));
    if the_color<1
        the_color=1;
    end
    if the_color>64
        the_color=64;
    end
    
    plot3(final_cl_result_tmp(idx_de,1),final_cl_result_tmp(idx_de,2),final_cl_result_tmp(idx_de,3),'Go','MarkerSize',8,'LineWidth',1.5,'MarkerEdgeColor',the_bar(the_color,:));
    
    clear the_color; clear idx_de;
    
end


    



%figuring the size and area essentially of the clusters
tot_num_cl=0;
tot_area_cl=0;


for c=1:tot_num_clusters
   
    %get a cluster
    idx_de=find(final_cl_result(:,4)==c);
    
    if numel(idx_de)>0
        tot_num_cl=tot_num_cl+1;
        tot_area_cl=tot_area_cl+numel(idx_de);
    end
    
  
    %clear statements
    clear idx_de;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Making stacks for 2d projections%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%with cluster information%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_i=1;
count_j=1;

for w=ns:ne
    
    %read in an image
    pc_im=imread(strcat(path_p_small2,num2str(w-ns+1),'.tif'));
    
    %pre-allocate some space
    if count_i==1
        dimS=size(pc_im,1);
        dimT=size(pc_im,2);
        cluster_stack=zeros(dimS,dimT,(ne-ns+1));
        cluster_stack=uint16(cluster_stack);
        cluster_mask_stack=cluster_stack;
        count_i=count_i+1;
    end
    
    %make a blank image
    blank_i=zeros(dimS,dimT);
    blank_i=double(blank_i);
    
    %non zero entries
    idx_tay=find(pc_im>0);
    
    %initial masking
    %blank_i(idx_tay)=1;
    
    %cluster mask to be
    blank_cluster=blank_i;
    
    %the clusters
    idx_cl_mask=find(final_cl_result(:,3)==w);
    
    %masking the clusters
    if numel(idx_cl_mask)>0
        hello=100000
        idx_convert=sub2ind(size(blank_cluster),final_cl_result(idx_cl_mask,1),final_cl_result(idx_cl_mask,2));
        blank_cluster(idx_convert)=(final_cl_result(idx_cl_mask,4))+1;
%         figure, imagesc([blank_i]); colormap(gray); colorbar; title('The Mask');
%         figure, imagesc(blank_cluster); colormap(gray); colorbar; title('Cluster Mask');
        clear idx_convert;
    end
        
    %storing
    cluster_stack(:,:,count_j)=uint16(blank_cluster);
    cluster_mask_stack(:,:,count_j)=uint16(blank_i);
    
    %iterate counter
    count_j=count_j+1;
    
    %clear statements
    clear pc_im; clear blank_i; clear idx_tay; clear blank_cluster;
    clear idx_cl_mask;
    
end

count_f=1;
for w=ns:ne
   %figure, imagesc(cluster_stack(:,:,count_f)); colormap(gray); colorbar; title(num2str(count_f));
   count_f=count_f+1;
end


%making the images 100x 100 in dimension for simplicity
cluster_stack_tmp=cluster_stack;
clear cluster_stack;
cluster_mask_stack_tmp=cluster_mask_stack;
clear cluster_mask_stack;

for r=1:(ne-ns+1)
    r
    %get images
    im_cb_tmp=cluster_stack_tmp(:,:,r);
    im_cb_mask_tmp=cluster_mask_stack_tmp(:,:,r);
    
    %figuring out the correct frame size
    %pre-allocating for speed
    if r==1
        
       %dimensions
       dimG=size(im_cb_tmp,1);
       dimP=size(im_cb_tmp,2);
       
       %getting the smallest frame size
       if dimG>=dimP
           dim_mj=dimP
       else
           dim_mj=dimG
       end
       
       %pre-allocating for speed
       cluster_stack=uint16(zeros(size(im_cb_tmp,1),size(im_cb_tmp,2),(ne-ns+1)));
       cluster_mask_stack=zeros(size(im_cb_tmp,1),size(im_cb_tmp,2),(ne-ns+1));
       
    end
    
    %cropping
    im_cb=uint16(im_cb_tmp);
    im_cb_mask=uint16(im_cb_mask_tmp);
    
    %debugging 
    if r==1
        close all;
        figure, imagesc(im_keep1); colormap(jet); colorbar; title('Original');
        figure, imagesc(im_cb); colormap(jet); colorbar; title('Final');hold on;
        plot(final_cl_result(idxA,1),final_cl_result(idxA,2),'m+','LineWidth',1.5,'MarkerSize',12);
    end
    
    %loading
    cluster_stack(:,:,r)=im_cb;
    cluster_mask_stack(:,:,r)=im_cb_mask;
    
    %clear statements
    clear im_cb_tmp; clear im_cb; clear im_cb_mask_tmp; clear im_cb_mask
    
end



%saving the stacks
if save_or_not==1
    write_file('Final_Cluster_Stack.tif',(ne-ns+1),cluster_stack);
end
    %write_file('MaskClusterStack.tif',(ne-ns+1),cluster_mask_stack);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Creating stack of intensity images%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%averaged like they were for correlation%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%analysis%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get average boundary
[cell_erode_avg_ret,frame_list_ret]=avg_erode_bound(path_er_ims,path_bound,ns,ne);

for v=1:size(cell_erode_avg_ret,1)
    
    %get image
    im1_tmp=cell_erode_avg_ret(v,1);
    im1=im1_tmp{1};
    im1=im1';
    
    %pre-allocating for speed
   if v==1
       dim1=size(im1,1);
       dim2=size(im1,2);
       avg_stack=zeros(dim1,dim2,size(cell_erode_avg_ret,1));
       avg_stack=uint16(avg_stack);
       avg_mask_stack=avg_stack;
   end
    
   %mask
   the_mask=zeros(dim1,dim2);
   idx_k=find(im1>0);
   if numel(idx_k)>0
     the_mask(idx_k)=1;
   end
   
   avg_stack(:,:,v)=uint16(im1);
   avg_mask_stack(:,:,v)=uint16(the_mask);
   
   if v==1
     figure, imagesc(im1); colormap(gray); colorbar; title(num2str(v));
   end
   
   clear im1_tmp; clear im1; 
   clear the_mask; clear idx_k;
    
end

%making the images 100x100 for simplicity
avg_stack_tmp=avg_stack;
clear avg_stack;
avg_mask_stack_tmp=avg_mask_stack;
clear avg_mask_stack;

for q=1:(ne-ns+1)
    
    %get images
    im_mm_tmp=avg_stack_tmp(:,:,q);
    im_mm_mask_tmp=uint16(avg_mask_stack_tmp(:,:,q));
    
    %cropping
    im_mm=im_mm_tmp;
    im_mm_mask=uint16(im_mm_mask_tmp);
    
    %pre-allocating for speed
    if q==1
        avg_stack=uint16(zeros(size(im_mm_tmp,1),size(im_mm_tmp,2),(ne-ns+1)));
        avg_mask_stack=zeros(size(im_mm_tmp,1),size(im_mm_tmp,2),(ne-ns+1));
    end
    
    avg_stack(:,:,q)=im_mm;
    avg_mask_stack(:,:,q)=im_mm_mask;
    
    figure, imagesc(im_mm_mask_tmp); colormap(gray); colorbar; title('Cluster');
    size(im_mm_mask)
    
    %clear statement
    clear im_mm_tmp; clear im_mm; clear im_mm_mask; clear im_mm_mask_tmp;
    
end
% 
% %saving the stacks
if save_or_not==1
    write_file('Final_ER1_Avg_Stack.tif',(ne-ns+1),avg_stack);
    write_file('IntensityMaskStack.tif',(ne-ns+1),avg_mask_stack);
end

did_it_finish=999888

close all;