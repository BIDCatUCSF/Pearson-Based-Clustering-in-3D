function[ret_peak]=find_prelim_peaks(the_list)

%inputs
%the_list(:,1) = x coordinates
%the_list(:,2) = y coordinates
%the_list(:,3) = z coordinates
%the_list(:,4) = Intensity
%the_list(:,5) = Pearson Coordinates

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%associating Pearson Peaks with high intensity%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%features%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%adding column to indicate number in set
the_list(:,6)=[1:numel(the_list(:,5))]';

for i=1:numel(the_list(:,1))
   
    %coordinates, intensity, pearson data
    x1=the_list(i,1);
    y1=the_list(i,2);
    z1=the_list(i,3);
    i1=the_list(i,4);
    p1=the_list(i,5);

    if p1>0
        %distance calculations
        dist_arr=(((x1-the_list(:,1)).^2)+((y1-the_list(:,2)).^2)+((z1-the_list(:,3)).^2)).^0.5;
        dist_arr(:,2)=the_list(:,4);
        dist_arr(:,3)=the_list(:,6);
        sort_dist_arr=sortrows(dist_arr,1);
        
        %pre-allocating array to hold intensities
        int_arr(:,1)=sort_dist_arr(1:7,2);
        int_arr(:,2)=sort_dist_arr(1:7,3);
        max_int=max(int_arr(:,1));
        
        for r=1:numel(int_arr(:,1))
            if int_arr(r,1)<max_int
                the_list(int_arr(r,2),5)=0;
            end
        end
    end
    
    %clear statements
    clear x1; clear y1; clear z1; clear p1; clear i1;
    clear dist_arr;  clear sort_dist_arr; clear int_arr;
    clear max_int; clear p1;
    
end

%keeping only likely peaks
idx_good=find(the_list(:,5)>0);
ret_peak(:,1)=the_list(idx_good,1);
ret_peak(:,2)=the_list(idx_good,2);
ret_peak(:,3)=the_list(idx_good,3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%fine tuning the selection of the peaks%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %counter for peak list
% count_peak=1;
% 
% %initializing output
% ret_peak=0;
% 
% %add a column to the list matrix
% the_list(:,6)=linspace(0,0,numel(the_list(:,5)))';
% the_list(:,7)=[1:numel(the_list(:,5))]';
% 
% for i=1:numel(the_list(:,1))
%    
%     %coordinate
%     x1=the_list(i,1);
%     y1=the_list(i,2);
%     z1=the_list(i,3);
%     i1=the_list(i,4);
%     p1=the_list(i,5);
%     f1=the_list(i,6);
%     
%     if f1==0 && p1 > 0
%         
%         %distance calculations
%         dist_arr=(((x1-the_list(:,1)).^2)+((y1-the_list(:,2)).^2)+((z1-the_list(:,3)).^2)).^0.5; %distance
%         dist_arr(:,2)=the_list(:,4); %intensity
%         dist_arr(:,3)=the_list(:,6); %flag
%         dist_arr(:,4)=the_list(:,7); %position
%         sort_dist_arr=sortrows(dist_arr,1);
%         
%         %counter
%         count=0;
%         
%         %is it a peak - going through nearest neighbors
%         for j=1:10
%             if sort_dist_arr(j,2)<=i1 && sort_dist_arr(j,3)==0
%                 
%                 %iterate counter
%                 count=count+1;
%                 
%                 %elements to remove
%                 ele_rem(count,1)=sort_dist_arr(j,4); %position
%                 
%             end
%         end
%         
%         %storing peak if necessary
%         if count>=9
%             %store peaks
%             ret_peak(count_peak,1)=x1;
%             ret_peak(count_peak,2)=y1;
%             ret_peak(count_peak,3)=z1;
%             count_peak=count_peak+1;
%             
%             %marking elements so that they are not included again
%             for p=1:numel(ele_rem(:,1))
%                 the_list(ele_rem(p,1),6)=1;
%             end
%             
%         end
%         
%         %marking the original element
%         the_list(i,6)=1;
%         
%         %clear statements
%         clear ele_rem; clear sort_dist_arr; clear dist_arr;
%         
%     end
%     
%     %clear statements
%     clear x1; clear y1; clear z1; clear i1; clear f1; clear p1;
%     
%     
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%
%
%
%
%
%


% while numel(the_list(:,1))>0
%     
%     the_list
%     
%     %coordinate
%     x1=the_list(1,1);
%     y1=the_list(1,2);
%     z1=the_list(1,3);
%     i1=the_list(1,4);
%     p1=the_list(1,5);
%     
%     if numel(the_list(:,1))==1
%         
%         if p1>0
%             %store peaks
%             ret_peak(count_peak,1)=x1;
%             ret_peak(count_peak,2)=y1;
%             ret_peak(count_peak,3)=z1;
%             count_peak=count_peak+1;
%             
%             %clearing the list
%             clear the_list;
%             
%         end
%         
%     else
%         
%         if p1>0
%             
%             %removing element
%             the_list(1,:)=[];
%             
%             %distance calculations
%             dist_arr=(((x1-the_list(:,1)).^2)+((y1-the_list(:,2)).^2)+((z1-the_list(:,3)).^2)).^0.5;
%             dist_arr(:,2)=the_list(:,4);
%             dist_arr(:,3)=the_list(:,1);
%             dist_arr(:,4)=the_list(:,2);
%             dist_arr(:,5)=the_list(:,3);
%             sort_dist_arr=sortrows(dist_arr,1);
%             
%             %counter
%             count=0;
%             
%             %is it a peak - going through nearest neighbors
%             for j=1:10
%                 
%                 if sort_dist_arr(j,2)<=i1
%                     
%                     %iterate counter
%                     count=count+1;
%                     
%                     %elements to remove
%                     ele_rem(count,1)=sort_dist_arr(j,3); %x
%                     ele_rem(count,2)=sort_dist_arr(j,4); %y
%                     ele_rem(count,3)=sort_dist_arr(j,5); %z
%                     
%                 end
%             end
%             
%             %ok, it is a peak
%             if count>=9
%                 
%                 %store peaks
%                 ret_peak(count_peak,1)=x1;
%                 ret_peak(count_peak,2)=y1;
%                 ret_peak(count_peak,3)=z1;
%                 count_peak=count_peak+1;
%                 
%                 %remove non-peak pixels
%                 for g=1:numel(ele_rem(:,1))
%                     d=(the_list(:,1)-ele_rem(g,1))+(the_list(:,2)-ele_rem(g,2))+(the_list(:,3)-ele_rem(g,3));
%                     idx_d=find(d==0);
%                     if numel(idx_d)>0
%                         the_list(idx_d,:)=[];
%                     end
%                     clear d; clear idx_d;
%                 end
%                 
%             end
%             
%             %clear statemetns
%             clear dist_arr; clear sort_dist_arr; clear ele_rem;
%             
%         end
%         
%         %clear statements
%         clear x1; clear y1; clear z1; clear p1; clear i1;
%     end
%     
% end
% 
% 
% 
% 
% 
% 
% 




























































