function[the_rgb_im]=make_rgb_blank(im_start,max_num,min_num,re_or_gre)

%colormaps
gray_map=colormap(gray);
% gray_map=[  0.0417         0         0
%     0.0399    0.0435         0
%     0.0380    0.0870         0
%     0.0362    0.1304         0
%     0.0344    0.1739         0
%     0.0326    0.2174         0
%     0.0308    0.2609         0
%     0.0290    0.3043         0
%     0.0272    0.3478         0
%     0.0254    0.3913         0
%     0.0236    0.4348         0
%     0.0217    0.4783         0
%     0.0199    0.5217         0
%     0.0181    0.5652         0
%     0.0163    0.6087         0
%     0.0145    0.6522         0
%     0.0127    0.6957         0
%     0.0109    0.7391         0
%     0.0091    0.7826         0
%     0.0072    0.8261         0
%     0.0054    0.8696         0
%     0.0036    0.9130         0
%     0.0018    0.9565         0
%          0    1.0000         0
%     0.0417    1.0000         0
%     0.0833    1.0000         0
%     0.1250    1.0000         0
%     0.1667    1.0000         0
%     0.2083    1.0000         0
%     0.2500    1.0000         0
%     0.2917    1.0000         0
%     0.3333    1.0000         0
%     0.3750    1.0000         0
%     0.4167    1.0000         0
%     0.4583    1.0000         0
%     0.5000    1.0000         0
%     0.5417    1.0000         0
%     0.5833    1.0000         0
%     0.6250    1.0000         0
%     0.6667    1.0000         0
%     0.7083    1.0000         0
%     0.7500    1.0000         0
%     0.7917    1.0000         0
%     0.8333    1.0000         0
%     0.8750    1.0000         0
%     0.9167    1.0000         0
%     0.9583    1.0000         0
%     1.0000    1.0000         0
%     1.0000    1.0000    0.0625
%     1.0000    1.0000    0.1250
%     1.0000    1.0000    0.1875
%     1.0000    1.0000    0.2500
%     1.0000    1.0000    0.3125
%     1.0000    1.0000    0.3750
%     1.0000    1.0000    0.4375
%     1.0000    1.0000    0.5000
%     1.0000    1.0000    0.5625
%     1.0000    1.0000    0.6250
%     1.0000    1.0000    0.6875
%     1.0000    1.0000    0.7500
%     1.0000    1.0000    0.8125
%     1.0000    1.0000    0.8750
%     1.0000    1.0000    0.9375
%     1.0000    1.0000    1.0000];

jet_map=colormap(jet);

%binary colorbar
bin_bar=[0,0,0;1,1,1];
bin_im=zeros(size(im_start));
idx_change=find(im_start>1);
bin_im(idx_change)=1;

%image properties
im_start=double(im_start);
max_num=double(max_num);
min_num=double(min_num);

im_start=im_start-min_num;
max_num=max_num-min_num;
max_num=max_num*1;

size(im_start)
size(max_num)
im_start=im_start.*(64/max_num);

if re_or_gre==1
    the_rgb_im=ind2rgb(uint16(im_start),gray_map);
else
    the_rgb_im_tmp=ind2rgb(uint16(im_start),jet_map);
    the_bin_rgb=ind2rgb(uint16(bin_im),bin_bar);
    
    the_rgb_im(:,:,1)=the_rgb_im_tmp(:,:,1).*the_bin_rgb(:,:,1);
    the_rgb_im(:,:,2)=the_rgb_im_tmp(:,:,2).*the_bin_rgb(:,:,2);
    the_rgb_im(:,:,3)=the_rgb_im_tmp(:,:,3).*the_bin_rgb(:,:,3);
 
end




