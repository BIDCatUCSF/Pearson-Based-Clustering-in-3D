function[ret_list]=add_to_list(orig_list,new_thing)

ret_list=orig_list;

ret_list_tmp=ret_list;
clear ret_list;
ret_list=[ret_list_tmp;new_thing];
clear ret_list_tmp;






