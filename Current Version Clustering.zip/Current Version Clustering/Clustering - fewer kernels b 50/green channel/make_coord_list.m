function[ret_list]=make_coord_list(idx1,im1,zi)

%counter
count=1;

for r=1:numel(idx1)
    
    [y1,x1]=ind2sub(size(im1),idx1(r));
    
    %finding the intensity
    int1=im1(idx1(r));
    int1=double(int1);
    
    %making the coordinate list
    xlist=[linspace(x1,x1,int1)]';
    ylist=[linspace(y1,y1,int1)]';
    zlist=[linspace(zi,zi,int1)]';
    
    if count==1
        ret_list(:,1)=xlist;
        ret_list(:,2)=ylist;
        ret_list(:,3)=zlist;
    else
        ret_list_tmp=ret_list;
        clear ret_list;
        ret_list=[ret_list_tmp;[xlist,ylist,zlist]];
        clear ret_list_tmp;  
    end
    
    %iterate counter
    count=count+1;
       
    clear xlist; clear ylist; clear zlist; clear int;
    
    
end











