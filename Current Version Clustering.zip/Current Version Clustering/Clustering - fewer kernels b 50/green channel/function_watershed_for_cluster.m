function[XYZ_ret_the_end]=function_watershed_for_cluster(XYZ_2_tmp,load_center)

%This is a function that does an additional watershed on top of the kmeans
%segmentation. It is intended to improve the segmentation

%inputs
% XYZ_2_tmp(:,1) = x coordinates of possible cluster
% XYZ_2_tmp(:,2) = y coordinates of possible cluster
% XYZ_2_tmp(:,3) = z coordinates of possible cluster
% XYZ_2_tmp(:,4) = intensity

%load_center(1) = x coordinate of center
%load_center(2) = y coordinate of center
%load_center(3) = z coordinate of center

%outputs
% XYZ_ret_the_end(:,1) = x coordinates of possible cluster
% XYZ_ret_the_end(:,2) = y coordinates of possible cluster
% XYZ_ret_the_end(:,3) = z coordinates of possible cluster
% XYZ_ret_the_end(:,4) = intensity

%colormap
the_map=colormap(jet);

close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%real data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% XYZ_2_tmp_tmp=load('H:\en project\Oct2018 Images\Misc Code\fitting plane in 3d\tests for clustering\large kernels size 7\the_test_spot_13.mat');
% XYZ_2_tmp=XYZ_2_tmp_tmp.the_cluster_ret;
% 
% load_center_tmp=load('H:\en project\Oct2018 Images\Misc Code\fitting plane in 3d\tests for clustering\large kernels size 7\the_center_13.mat');
% load_center=load_center_tmp.center_keep;

%figuring out the rings
% size_from_kernel=4;
xc_tmp=load_center(1);
yc_tmp=load_center(2);
zc_tmp=load_center(3);

%pick center as brightest spot near the likely center
[xc,yc,zc,ic_r]=refine_center_watershed(XYZ_2_tmp,xc_tmp,yc_tmp,zc_tmp);


%removing duplicate rows
%XYZ_2a=unique(XYZ_2_tmp,'rows');
%XYZ_2a=XYZ_2_tmp;
XYZ_2(:,1)=XYZ_2_tmp(:,1);
XYZ_2(:,2)=XYZ_2_tmp(:,2);
XYZ_2(:,3)=XYZ_2_tmp(:,3);
ring_num=zeros(numel(XYZ_2_tmp(:,4)),1)+1;
curve_data=XYZ_2_tmp(:,4);

%add the center
thing_mad=(XYZ_2(:,1)-xc)+(XYZ_2(:,2)-yc)+(XYZ_2(:,3)-zc);
idx_mad=find(thing_mad==0);
for r=1:numel(idx_mad)
    if curve_data(idx_mad(r),1)==ic_r
        ring_num(idx_mad(r))=999;
    end
end
    


%definition of the simulated plane
figure, plot3(XYZ_2(:,1),XYZ_2(:,2),XYZ_2(:,3),'b.'); hold on;

%extrema
del_x=uint16(abs(max(XYZ_2(:,1))-min(XYZ_2(:,1))));
del_y=uint16(abs(max(XYZ_2(:,2))-min(XYZ_2(:,2))));
del_z=uint16(abs(max(XYZ_2(:,3))-min(XYZ_2(:,3))));
the_width_arr=[del_x;del_y;del_z];
the_width=max(the_width_arr)+5;

%compute the normal to the plane and a point that belongs to the plane
[n_2,V_2,p_2] = affine_fit(XYZ_2);

%what is the point on plane
plot3(p_2(1),p_2(2),p_2(3),'r+','MarkerSize',12,'LineWidth',1.5);
plot3(xc,yc,zc,'gx','MarkerSize',12,'LineWidth',2.5);

%define the grid
%[S1,S2] = meshgrid([-1 0 1]);
for i=1:the_width
    
    %figure out width from center - odd case and then even case
    if i==1
       % if mod(the_width,2)==1
            del_s1=-1*double((uint16(the_width*0.5)))+1;
            del_s2=(uint16(the_width*0.5));
%         else
%             del_s1=-(uint16(the_width*0.5))+1
%             del_s2=(uint16(the_width*0.5))
%         end
    end

    %making double
    del_s1=double(del_s1);
    del_s2=double(del_s2);
    the_width=double(the_width);
    i=double(i);

    %making the lists (S1 and S2)
    if i==1
        S2=linspace(del_s1+i-1,del_s1+i-1,the_width)';
        S1=linspace(del_s1,del_s2,the_width)';
    else
        S2_tmp=S2;
        clear S2;
        S2=[S2_tmp;linspace(del_s1+i-1,del_s1+i-1,the_width)'];
        clear S2_tmp;

        S1_tmp=S1;
        clear S1;
        S1=[S1_tmp;linspace(del_s1,del_s2,the_width)'];
        clear S1_tmp;
    end

end

%generate the pont coordinates
X = p_2(1)+[S1(:) S2(:)]*V_2(1,:)';
Y = p_2(2)+[S1(:) S2(:)]*V_2(2,:)';
Z = p_2(3)+[S1(:) S2(:)]*V_2(3,:)';

%plot the plane
surf(reshape(X,the_width,the_width),reshape(Y,the_width,the_width),reshape(Z,the_width,the_width),'facecolor','blue','facealpha',0.5);
xlabel('x');
ylabel('y');
zlabel('z');
axis equal

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Checking how curvature projects to plane%%%%%%%%%%%%%%%

%plotting the original curvature information


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%Making planes to better keep track of ring number%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%and curvature throughout code%%%%%%%%%%%%%%%%%%%%%%%%%

%list of curvature in plane
curve_plane=zeros(size(X));
curve_plane=curve_plane+100000; 

%list of ring number in plane
ring_plane=curve_plane;

%plane to keep track of locations in original stack
track_plane=curve_plane;

%making double
X=double(X);
Y=double(Y);
Z=double(Z);
XYZ_2=double(XYZ_2);

for s=1:numel(XYZ_2(:,1))
   s
    %distance
    d_arr=((X-XYZ_2(s,1)).^2)+((Y-XYZ_2(s,2)).^2)+((Z-XYZ_2(s,3)).^2);
    min_d=min(d_arr);
    idx_d=find(d_arr==min_d);
    
    %checking if this spot on plane is already populated
    if curve_plane(idx_d(1)) == 100000
        
        %adding curvature
        curve_plane(idx_d(1))=curve_data(s,1);
        
        %adding ring number
        ring_plane(idx_d(1))=ring_num(s,1);
        
        %adding location
        track_plane(idx_d(1))=s;
     
     %if spot is already populated put spot in next closest spot
    else
        while curve_plane(idx_d(1)) ~= 100000 %&& s~=numel(XYZ_2(:,1))
           d_arr(idx_d(1))=10000;
           clear idx_d;
           min_d=min(d_arr);
           idx_d=find(d_arr==min_d);
        end
        
        %adding curvature
        curve_plane(idx_d(1))=curve_data(s,1);
        
        %adding ring number
        ring_plane(idx_d(1))=ring_num(s,1);
        
        %adding location
        track_plane(idx_d(1))=s;
        
    end
    
    %clear statements
    clear d_arr; clear min_d; clear idx_d;
    
    
end

%projecting information about curvature onto plot
%figure, hold on; title('Curvature projected onto 2D Plane');
for r=1:numel(X)
   
     %curvature
     c_now=curve_plane(r,1);
     
     %extrema for color rendering
     min_c1=min(curve_data(:,1));
     max_c1=max(curve_data(:,1))-min_c1;
    
    if c_now<100000
        
        %screening
        curve_data=double(curve_data);
        c_now=double(c_now);
        c_now=double((c_now-min_c1).*(64./max_c1));
        
        %figuring out the colorbar
        idx_bar=uint16(c_now);
        if idx_bar<1
            idx_bar=1;
        end
        if idx_bar>64
            idx_bar=64;
        end
        
        %plotting
        plot3(X(r),Y(r),Z(r),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
        
        %clear statements
        clear c_now; clear idx_low; clear idx_high; clear idx_bar;
        
    end
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%debugging
%seeing what these vectors are
figure, hold on;
for i=1:numel(X)
    plot3(X(i),Y(i),Z(i),'ro','MarkerSize',12,'LineWidth',1.5);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%Figuring out the rotation necessary to put the plane on%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2d axis%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%defining rotation matrix
figure, hold on; 

for t=1:6%
    
    %pre-allocating for speed
    del_keep=zeros(360,2);
    del_keep=double(del_keep);
    
    for k=1:360
        
        %define theta
        theta=double(-180+k-1);
        theta=theta.*(pi/180);
        
        %define rotation matrix
        if t==1 %x axis
            rot_mat=rotationmat3D(theta,[1 0 0]);
        elseif t==2 % y axis
            rot_mat=rotationmat3D(theta,[0 1 0]);
        elseif t==3 % z axis
            rot_mat=rotationmat3D(theta,[0 0 1]);
        elseif t==4 %x z axes
            rot_mat=rotationmat3D(theta,[1 0 1]);
        elseif t==5 %x y axes
            rot_mat=rotationmat3D(theta,[1 1 0]);
        elseif t==6 %y z axes
            rot_mat=rotationmat3D(theta,[0 1 1]);
        end
   
        
        %applying rotation matrix
        for j=1:numel(X)
            
            vec=[X(j);Y(j);Z(j)];
            thing_plot=[rot_mat*vec]';
            coord_2d(j,:)=[thing_plot];
            
            %clear statements
            clear vec; clear thing_plot;
            
        end
        
        %seeing how close to being purely in xy plabe coordinates are
        del_keep(k,1)=theta;
        del_keep(k,2)=abs(min(coord_2d(:,3))-max(coord_2d(:,3)));
        
        
        %seeing how close to flat things are
%         del_keep(k,1)=theta*(180/pi);
%         del_keep(k,2)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),1)-coord_2d(1:(numel(coord_2d(:,2))-1),1)));
%         del_keep(k,3)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),2)-coord_2d(1:(numel(coord_2d(:,2))-1),2)));
%         del_keep(k,4)=abs(sum(coord_2d(2:numel(coord_2d(:,2)),3)-coord_2d(1:(numel(coord_2d(:,2))-1),3)));
        
        %clear statements
        clear theta; clear rot_mat; 
        clear coord_2d;
        
    end
    
    %storing extrema information
    extrema_info(t,1)=min(del_keep(:,2));
    
    %locating angles where extrema occurred 
    idx_ang_x=find(del_keep(:,2)==min(del_keep(:,2)));
    
    %storing angles
    extrema_info(t,2)=del_keep(idx_ang_x(1),1);

    
    %clear statement
    clear del_keep; clear idx_ang_x; clear idx_ang_y; clear idx_ang_z;
    
    
end

%figuring out the rotation angle to use
min_diff=min(extrema_info(:,1));
idx_diff=find(extrema_info(:,1)==min_diff);
theta_use=extrema_info(idx_diff(1),2);

%figuring out which rotation matrix to use
if idx_diff(1)==1 %x axis
    rot_mat_use=rotationmat3D(theta_use,[1 0 0]);
elseif idx_diff(1)==2 % y axis
    rot_mat_use=rotationmat3D(theta_use,[0 1 0]);
elseif idx_diff(1)==3 % z axis
    rot_mat_use=rotationmat3D(theta_use,[0 0 1]);
elseif idx_diff(1)==4 %x z axes
    rot_mat_use=rotationmat3D(theta_use,[1 0 1]);
elseif idx_diff(1)==5 %x y axes
    rot_mat_use=rotationmat3D(theta_use,[1 1 0]);
elseif idx_diff(1)==6 %y z axes
    rot_mat_use=rotationmat3D(theta_use,[0 1 1]);
end

%applying rotation matrix
for m=1:numel(X)
    
    vec1=[X(m);Y(m);Z(m)];
    thing_plot1=[rot_mat_use*vec1]';
    final_data_in_xy_tmp(m,:)=[thing_plot1];
    
    %clear statements
    clear vec1; clear thing_plot1;
    
end

%making matrix parallel to xy axes
[final_data_in_xy]=corners_test_func(final_data_in_xy_tmp);

%making a figure
figure, hold on; title(strcat('r is',num2str(r),' and s is', num2str(s)));
plot(final_data_in_xy(:,1),final_data_in_xy(:,2),'k+');

%counter
count_en=1;

%adding the curvature information
for q=1:numel(final_data_in_xy(:,1))
    
    %curvature
     c_now=curve_plane(q,1);
    
    if c_now < 100000
        
        %storing only the data points with known curvature
        final_coords_w_curv(count_en,1)=final_data_in_xy(q,1); %x
        final_coords_w_curv(count_en,2)=final_data_in_xy(q,2); %y
        final_coords_w_curv(count_en,3)=ring_plane(q,1); %ring 
        final_coords_w_curv(count_en,4)=c_now; %curvature
        final_coords_w_curv(count_en,5)=track_plane(q,1); %position in the original list
        count_en=count_en+1;
        
        %screening
        
        
        %figuring out the colorbar
        idx_bar=uint16(c_now.*(64./max(curve_data(:,1))));
        if idx_bar<1
            idx_bar=1;
        end
        if idx_bar>64
            idx_bar=64;
        end

        %plotting
        plot(final_data_in_xy(q,1),final_data_in_xy(q,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
        
        if ring_plane(q,1)==999
            plot(final_data_in_xy(q,1),final_data_in_xy(q,2),'kx','LineWidth',5.5,'MarkerSize',12);
        end
        
        %clear statements
        clear c_now; clear idx_low; clear idx_high; clear idx_bar;
        
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%Some code to look at distances from center to establish%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%the rings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% figure, hold on; title('Are these rings?');
% for i=1:numel(final_coords_w_curv(:,1))
%    
%     if (final_coords_w_curv(i,3))==1
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','LineWidth',1.5,'MarkerSize',12);
%     elseif (final_coords_w_curv(i,3))==2
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ro','LineWidth',1.5,'MarkerSize',12);
%     elseif (final_coords_w_curv(i,3))==3
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'bo','LineWidth',1.5,'MarkerSize',12);
%     elseif (final_coords_w_curv(i,3))==4
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'go','LineWidth',1.5,'MarkerSize',12);
%     elseif (final_coords_w_curv(i,3))==5
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'mo','LineWidth',1.5,'MarkerSize',12);
%     elseif (final_coords_w_curv(i,3))==0
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'r+','LineWidth',1.5,'MarkerSize',12);
%     end
%     
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%This is the actual watershed portion of code%%%%%%%%%%%%%%

final_coords_w_curv_test1=final_coords_w_curv;

%pre-allocating an array to tell me what is in and not in mountain
mountain_or_not=zeros(numel(final_coords_w_curv(:,5)),1);

%scaling up the x and y axis to simplify later calculations - x axis
if min(final_coords_w_curv(:,1))<0
    final_coords_w_curv(:,1)=final_coords_w_curv(:,1)+abs(min(final_coords_w_curv(:,1)))+1;
end

%scaling up the x and y axis to simplify later calculations - y axis
if min(final_coords_w_curv(:,2))<0
    final_coords_w_curv(:,2)=final_coords_w_curv(:,2)+abs(min(final_coords_w_curv(:,2)))+1;
end


idx_center=find(final_coords_w_curv_test1(:,3)==999);
x_center1=final_coords_w_curv_test1(idx_center(1),1);
y_center1=final_coords_w_curv_test1(idx_center(1),2);
curve_center1=final_coords_w_curv_test1(idx_center(1),4);
%plot(x_center1,y_center1,'b*','LineWidth',5,'MarkerSize',5);

%marking the center as a mountain
mountain_or_not(idx_center(1))=1;

%calculating angle
[angle_list_all]=calc_angle_microvilli([final_coords_w_curv(:,2),final_coords_w_curv(:,1)],x_center1,y_center1);
angle_list_all(:,3)=angle_list_all(:,3)*(180/pi);

%figure out the rings
[final_coords_w_curv]=assign_rings(final_coords_w_curv,angle_list_all);

%getting the locations of the rings
idx_ring1=find(final_coords_w_curv(:,3)==1);
idx_ring2=find(final_coords_w_curv(:,3)==2);
idx_ring3=find(final_coords_w_curv(:,3)==3);
idx_ring4=find(final_coords_w_curv(:,3)==4);
idx_ring5=find(final_coords_w_curv(:,3)==5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%calculate gradient of ring 1
gradient_list(:,1)=zeros(numel(final_coords_w_curv(:,5)),1);
gradient_list(:,1)=gradient_list(:,1)-1;
gradient_list(idx_ring1,1)=curve_center1-final_coords_w_curv(idx_ring1,4); %curvature

%adding to mountain classification
idx_r1_mtn=find(gradient_list(:,1)>=0);
if numel(idx_r1_mtn)>0
    mountain_or_not(idx_r1_mtn)=1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mountain_or_not_r12]=find_grad_ring_for_intensity(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not,idx_ring1,idx_ring2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ring 3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mountain_or_not_r23]=find_grad_ring_for_intensity(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not_r12,idx_ring2,idx_ring3);

%%%%%%%%%%%%%%%%%%%%%ring 4%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mountain_or_not_final]=find_grad_ring_for_intensity(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not_r23,idx_ring3,idx_ring4);

%%%%%%%%%%%%%%%%%%ring 5%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[mountain_or_not_final]=find_grad_ring_for_intensity(angle_list_all(:,3),final_coords_w_curv(:,4),mountain_or_not_r34,idx_ring4,idx_ring5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%For Debugging Only%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for h=1:numel(final_coords_w_curv(:,1))
    if mountain_or_not_final(h,1)==1
     plot(final_coords_w_curv_test1(h,1),final_coords_w_curv_test1(h,2),'m*','MarkerSize',8,'LineWidth',1.5);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Creating matrix to return%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%return
XYZ_2_ret=XYZ_2;

for f=1:numel(final_coords_w_curv(:,5))
    
    %index from original list
    idx_orig=final_coords_w_curv(f,5);
    
    %for debugging only - adding intensity (curvature)
    XYZ_2_ret(idx_orig,5)=final_coords_w_curv(f,4);
    
    %adding assignment of mtn or not
    XYZ_2_ret(idx_orig,4)=mountain_or_not_final(f,1);
    
    %clear statements
    clear idx_orig;
    
end

%removing the elements from the return that do not belong in cluster
idx_not=find(XYZ_2_ret(:,4)==0);
if numel(idx_not)>0
    
    XYZ_ret_john=XYZ_2_ret;
    XYZ_ret_john(idx_not,:)=[];
    
    %removing the column with watershed guide
    XYZ_ret_the_end(:,1)=XYZ_ret_john(:,1);
    XYZ_ret_the_end(:,2)=XYZ_ret_john(:,2);
    XYZ_ret_the_end(:,3)=XYZ_ret_john(:,3);
    XYZ_ret_the_end(:,4)=XYZ_ret_john(:,5);

%all elements are in the cluster
else
    XYZ_ret_the_end(:,1)=XYZ_2_ret(:,1);
    XYZ_ret_the_end(:,2)=XYZ_2_ret(:,2);
    XYZ_ret_the_end(:,3)=XYZ_2_ret(:,3);
    XYZ_ret_the_end(:,4)=XYZ_2_ret(:,5);   
end




%closing all open figures before returning
close all;


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%Checking angles%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% figure, hold on; title('Checking Angles');
% jet_map=colormap(jet);
% 
% for i=1:numel(angle_list(:,1))
%    
%     %get color
%     idx_bar=uint16(angle_list(i,3)*(64/360));
%     if idx_bar<1
%         idx_bar=1;
%     elseif idx_bar>64
%         idx_bar=64;
%     end
%     
%     %plot
%     plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',jet_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     
%     %clear statement
%     clear idx_bar;
% end
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%% Checking Rings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% figure, hold on; title('Checking Rings');
% 
% %checking the ring number
% for i=1:(count_en-1)
%     
%     if final_coords_w_curv(i,3)==1
%         idx_bar=1;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==2
%         idx_bar=32;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==3
%         idx_bar=64;
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','MarkerEdgeColor',the_map(idx_bar,:),'LineWidth',1.5,'MarkerSize',12);
%     elseif final_coords_w_curv(i,3)==0
%         plot(final_coords_w_curv(i,1),final_coords_w_curv(i,2),'ko','LineWidth',1.5,'MarkerSize',12);
%     end
%     
% end



















