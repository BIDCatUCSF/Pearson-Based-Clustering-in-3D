function[matrix_overlap_forever]=does_it_coloc_v3(big_g,big_r)

%06/28/2019 - Version 3 is a modification (simplification) of original
%colocalization code to combine clusters of one channel that overlap

%In this case, big_g and big_r will be inputted as the same matrix

%In this case, the output simplified for that purpose
% matrix_overlap_forever(:,1) = cluster #a
% matrix_overlap_forever(:,2) = cluster # that overlaps with cluster #a
% matrix_overlap_forever(:,3) = percent colocalization

%counter
count_ret=1;

%extrema of cluster
min_g_cl=min(big_g(:,4));
max_g_cl=max(big_g(:,4));


for j=min_g_cl:max_g_cl
    
   %get a current green cluster
   green_cl_idx=find(big_g(:,4)==j);
   
   if numel(green_cl_idx)>0
       
       %xyz coordinates of green cluster
       the_gr(:,1)=big_g(green_cl_idx,1);%x
       the_gr(:,2)=big_g(green_cl_idx,2);%y
       the_gr(:,3)=big_g(green_cl_idx,3);%z
       
       
       %Aremoving these elements from the other matrix
       big_r_tmp=big_r;
       big_r_tmp(green_cl_idx,:)=[];
       
       %counter for the loop
       count_loop=1;
       
       %distance calculation
       for k=1:numel(green_cl_idx)
          
           %distance
           dist_arr(:,1)=(((the_gr(k,1)-big_r_tmp(:,1)).^2)+((the_gr(k,2)-big_r_tmp(:,2)).^2)+((the_gr(k,3)-big_r_tmp(:,3)).^2)).^0.5;
           
           %are there touching pixels?
           idx_too_close_tmp=find(dist_arr(:,1)==0);
           
           %as it loops through, i am putting together all the indices that
           %colocalize with cluster 'j'
           if numel(idx_too_close_tmp)>0 && count_loop==1
              
               %keeping
               idx_too_close=idx_too_close_tmp;
               
               %iterate counter
               count_loop=count_loop+1;
               
           elseif numel(idx_too_close_tmp)>0 && count_loop>1
               
               %keeping
               idx_too_close_hold=idx_too_close;
               clear idx_too_close;
               idx_too_close=[idx_too_close_hold;idx_too_close_tmp];
               clear idx_too_close_hold;
               
           end
           
           %clear statements
           clear dist_arr; clear idx_too_close_tmp;
           
       end
       
       
%        if count_loop>1
           
           %getting the colocalization information
           if count_loop == 1
               idx_too_close=1
           end

           [matrix_overlap_tmp]=get_info_touchng_clusters(big_r_tmp,idx_too_close,j);
           
           %keeping
           if numel(matrix_overlap_tmp)>1 && count_ret==1
               
               %keeping
               matrix_overlap_forever=matrix_overlap_tmp;
               
               %iterate counter
               count_ret=count_ret+1;
               
           elseif numel(matrix_overlap_tmp)>1 && count_ret>1
               
               %keeping
               matrix_overlap_forever_tmp=matrix_overlap_forever;
               clear matrix_overlap_forever;
               matrix_overlap_forever=[matrix_overlap_forever_tmp;matrix_overlap_tmp];
               clear matrix_overlap_forever_tmp;
               
               %iterate counter
               count_ret=count_ret+1;
               
           end
           
%        end
       
       %clear statments
       clear matrix_overlap_tmp;
       clear the_gr; clear big_r_tmp;
   end
   
   %clear statements
   clear green_cl_idx;
   
end

%This is what happens when nothing colocalizes
%and making sure that there is something to return
if numel(matrix_overlap_forever)==0
    matrix_overlap_forever=0;
end












