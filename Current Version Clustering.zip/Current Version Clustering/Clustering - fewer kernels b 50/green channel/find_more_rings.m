function[in1A,in1_copyA]=find_more_rings(in1A,in1_copyA,flag1,flag2,idx_center)

%in1A=matrix to remove elements as they are flagged
%in1_copyA=matrix to add flags to.

%the distance calculation (euclidean)
d_r2=(((in1A(:,1)-in1_copyA(idx_center(1),1)).^2)+((in1A(:,2)-in1_copyA(idx_center(1),2)).^2)).^0.5;

%replacing the distances
in1A(:,7)=d_r2;

%indices - ring 1
idx_ring1=find(in1_copyA(:,3)==flag1);

%look at just the elements in most - inner ring
for i=1:numel(idx_ring1)
        
    %coordinates
    xk=in1_copyA(idx_ring1(i),1);
    yk=in1_copyA(idx_ring1(i),2);

    %look in x
    diff_x=abs(xk-in1A(:,1));
    idx_diff_x=find(diff_x<1.0);
    
    %look in y
    diff_y=abs(yk-in1A(:,2));
    idx_diff_y=find(diff_y<1.0);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%       X    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%pick the coordinate closest to the center point%%%%%%%%%%
    
    if numel(idx_diff_x)>0
        sect_x=in1A(idx_diff_x,:);
        sect_x_sort=sortrows(sect_x,7);
        count_low_x=1;
        for s=1:numel(sect_x_sort(:,1))
            if abs(sect_x_sort(s,2)-yk)<0.6 && count_low_x==1
                min_x=sect_x_sort(s,7);
                min_x_idx=s;
                count_low_x=count_low_x+1;
            elseif abs(sect_x_sort(s,2)-yk)<0.6 && count_low_x>1
                if sect_x_sort(s,7)<min_x
                       min_x=sect_x_sort(s,7);
                       min_x_idx=s; 
                end
            end
            
        end
        if count_low_x>1
            
            in1_copyA(sect_x_sort(min_x_idx,6),3)=flag2;
            
            %remove
            idx_bad4=find(in1A(:,6)==sect_x_sort(min_x_idx,6));
            if numel(idx_bad4)>0
                in1A(idx_bad4(1),8)=10000;
            end
            
        end
    
        
        
        %clear statemetns
        clear sect_x; clear sect_x_sort; clear idx_bad4;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%      Y    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%pick the coordinate closest to the center point%%%%%%%%%%
    
     if numel(idx_diff_y)>0
        sect_y=in1A(idx_diff_y,:);
        sect_y_sort=sortrows(sect_y,7);
        count_low_y=1;
        for s=1:numel(sect_y_sort(:,1))
            if abs(sect_y_sort(s,1)-xk)<0.6 && count_low_y==1
                min_y=sect_y_sort(s,7);
                min_y_idx=s;
                count_low_y=count_low_y+1;
            elseif abs(sect_y_sort(s,1)-xk)<0.6 && count_low_y>1
                if sect_y_sort(s,7)<min_y
                       min_y=sect_y_sort(s,7);
                       min_y_idx=s; 
                end
            end
            
        end
        if count_low_y>1
            in1_copyA(sect_y_sort(min_y_idx,6),3)=flag2;
            
            %remove
            idx_bad4=find(in1A(:,6)==sect_y_sort(min_y_idx,6));
            if numel(idx_bad4)>0
                in1A(idx_bad4(1),8)=10000;
            end
        end
    
        
        
        %clear statemetns
        clear sect_y; clear sect_y_sort; clear idx_bad4;
    end
     
    
    %clear statements
    clear xk; clear yk; clear diff_x; clear diff_y;
    clear idx_diff_x; clear idx_diff_y;

end

idx_rem_sor=find(in1A(:,8)==10000);
if numel(idx_rem_sor)>0
    in1A(idx_rem_sor,:)=[];
end
% 
% idx_plot=find(in1_copyA(:,3)==flag2);
% if flag2==900
%     plot(in1_copyA(idx_plot,1),in1_copyA(idx_plot,2),'yx','Linewidth',4,'MarkerSize',16);
% elseif flag2==1100
%     plot(in1_copyA(idx_plot,1),in1_copyA(idx_plot,2),'rx','Linewidth',4,'MarkerSize',16);
% else
%     plot(in1_copyA(idx_plot,1),in1_copyA(idx_plot,2),'kx','Linewidth',4,'MarkerSize',16);
% end







