clear all; close all;

%reading in the images
ic=imread('E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI40\Latest Clustering\green channel\proj2d_cluster.btf');
im=imread('E:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI40\Latest Clustering\green channel\proj2d_er.btf');

% im=imcrop(im_tmp,[1,1,139,46]);

%median filter
%ic=medfilt2(ic,[2 2]);

%rgb compsoite figure
ic_rgb=make_rgb_blank(ic,158,0,2);
im_rgb=make_rgb_blank(im,1500,300,1);

im_compos(:,:,1)=ic_rgb(:,:,1).*im_rgb(:,:,1);
im_compos(:,:,2)=ic_rgb(:,:,2).*im_rgb(:,:,2);
im_compos(:,:,3)=ic_rgb(:,:,3).*im_rgb(:,:,3);
figure, imshow([ic_rgb;im_rgb;im_compos]);

%plotting the boundaries
figure, imagesc(im,[0 600]); colormap(gray); colorbar; hold on;

%dimensions
dim1=size(ic,1);
dim2=size(ic,2);

max_cl=max(ic(1:(dim1*dim2)));

for i=2:max_cl
    
    idx_cl=find(ic==i);
    
    if numel(idx_cl)>0
        blank_im=zeros(dim1,dim2);
        blank_im(idx_cl)=1;
        bound_tmp=bwboundaries(blank_im);
        for j=1:size(bound_tmp,1);
            bound=bound_tmp{j};
            plot(bound(:,2),bound(:,1),'m','LineWidth',1.5);
            clear bound;
        end
        clear blank_im; clear bound_tmp;
    end
    
    clear idx_cl;
    
end






