function[tot_arr_ret,clusts_ret,does_it_colocalize_more]=does_it_colocalize(c_num,tot_arr)

%inputs
% c_num = number of cluster that I want to know if it colocalizes
% tot_arr(:,1) = list of all clusters 
% tot_arr(:,2) = list of clusters that column 1 clusters colocalize with
% tot_arr(:,3) = percentage colocalization

%outputs
%This return does not contain any clusters found to colocalize
% tot_arr_ret(:,1) = list of all clusters 
% tot_arr_ret(:,2) = list of clusters that column 1 clusters colocalize with
% tot_arr_ret(:,3) = percentage colocalization

%Outputs
%clusts_ret = cluster numbers that colocalize

%outputs
%does_it_colocalize_more = flag(0 or 1) indicating if colocalization was found

%making a return argument
tot_arr_ret=tot_arr;

%initializing another return argument
does_it_colocalize_more=0;

%looking for this cluster
idx_find=find(tot_arr(:,1)==c_num);

if numel(idx_find)>0
    
    %section out part that you want
    sec_now(:,1)=tot_arr(idx_find,1);
    sec_now(:,2)=tot_arr(idx_find,2);
    sec_now(:,3)=tot_arr(idx_find,3);
    
    %looking to see if the extent of colocalization is > 20%
    idx_big=find(sec_now(:,3)>=20);
    
    %there is colocalization
    if numel(idx_big)>0
       
        %record cluster numbers
        clusts_ret=sec_now(idx_big,2);
        
        %remove these elements from list
        tot_arr_ret(idx_find(idx_big),:)=[];
       
        
        %the flag
        does_it_colocalize_more=1;
        
    %there is no colocalization   
    else
        clusts_ret=0;
    end

else
    
    %there is no colocalization
    clusts_ret=0;
    
end











