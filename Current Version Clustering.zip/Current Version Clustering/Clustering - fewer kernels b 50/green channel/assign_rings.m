function[in1_copy_ret4]=assign_rings(in1,ang_data)

%adding column
in1(:,6)=[1:numel(in1(:,5))]';
in1(:,8)=ang_data(:,3);

%making a copy
in1_copy=in1;

%get center
idx_center=find(in1(:,3)==999);

%remove center
in1(idx_center(1),:)=[];

%figure
% figure, hold on;
% plot(in1_copy(:,1),in1_copy(:,2),'ko','MarkerSize',12);
% plot(in1_copy(idx_center(1),1),in1_copy(idx_center(1),2),'r+','MarkerSize',12,'LineWidth',2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Ring 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

d_r1=(((in1(:,1)-in1_copy(idx_center(1),1)).^2)+((in1(:,2)-in1_copy(idx_center(1),2)).^2)).^0.5;

in1(:,7)=d_r1;
in1_sort=sortrows(in1,7);

for i=1:8
   %mark ring 1
   in1_copy(in1_sort(i,6),3)=500;
   %plot(in1_copy(in1_sort(i,6),1),in1_copy(in1_sort(i,6),2),'gx','Linewidth',2,'MarkerSize',12);
   
   %remove element from  original list
   idx_r1_bad=find(in1(:,6)==in1_sort(i,6));
   if numel(idx_r1_bad)>0
       in1(idx_r1_bad,:)=[];
   end
   clear idx_r1_bad;
   
end
%plot(in1(:,1),in1(:,2),'m+','Linewidth',2,'MarkerSize',12);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%getting the rest of the rings%%%%%%%%%%%%%%%%%%%%%%%%%%%
[in1_ret,in1_copy_ret]=find_other_rings(in1,in1_copy,500,700,idx_center);
[in1_ret2,in1_copy_ret2]=find_more_rings(in1_ret,in1_copy_ret,700,900,idx_center);
[in1_ret3,in1_copy_ret3]=find_more_rings(in1_ret2,in1_copy_ret2,900,1100,idx_center);
[in1_ret4,in1_copy_ret4]=find_more_rings(in1_ret3,in1_copy_ret3,1100,1300,idx_center);

%renaming the rings to sequential numbers
idx0=find(in1_copy_ret4(:,3)==1);
idx1=find(in1_copy_ret4(:,3)==500);
idx2=find(in1_copy_ret4(:,3)==700);
idx3=find(in1_copy_ret4(:,3)==900);
idx4=find(in1_copy_ret4(:,3)==1100);
idx5=find(in1_copy_ret4(:,3)==1300);

if numel(idx0)>0
    in1_copy_ret4(idx0,3)=0;
end

if numel(idx1)>0
    in1_copy_ret4(idx1,3)=1;
end

if numel(idx2)>0
    in1_copy_ret4(idx2,3)=2;
end

if numel(idx3)>0
    in1_copy_ret4(idx3,3)=3;
end

if numel(idx4)>0
    in1_copy_ret4(idx4,3)=4;
end

if numel(idx5)>0
    in1_copy_ret4(idx5,3)=5;
end

%plot(in1_ret(:,1),in1_ret(:,2),'kx','Linewidth',2,'MarkerSize',12);

john=10000;













