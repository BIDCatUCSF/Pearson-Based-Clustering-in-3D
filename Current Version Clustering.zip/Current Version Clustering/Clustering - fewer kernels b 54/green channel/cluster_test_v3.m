clear all; close all;

%flag to indicate if these images are from the green or red channel
which_channel = 1; %green
%which_channel = 0; %red

%image indices
ns=48;
ne=84;

%the directory to save the images to
curr_dir='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\Clustering_b54\ROI18';
mkdir(curr_dir);

%paths to images
path_p_small2='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\smaller2 size - with sort - CD45\Pearson Slices\im';
path_p_medium='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\medium size - with sort - CD45\Pearson Slices\im';
path_p_medium2='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\medium2 size - with sort - CD45\Pearson Slices\im';
path_p_big='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\bigger size - with sort - CD45\Pearson Slices\im';

path_er_ims='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\ErodedBoundaryImages\MaskBoundErode';
path_bound='J:\20171201to20200931drive\20180329\ROI18\GPUdecon\CroppedFiles\ROI18_1005_high_CD45_A594\The_Boundaries\Bound';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%Figuring out the ideal Pearson threshold%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%For Peak Selection%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Pearson threshold
ideal_pear_search=54;

%doing the actual clustering
[avg_stack,avg_mask_stack,cluster_stack,tot_num_cl]=cluster_test_v3_function(path_p_small2,path_p_medium,path_p_medium2,path_p_big,path_er_ims,path_bound,ideal_pear_search,ns,ne,0.4,1);

%counter
count_k=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%screening by cluster
%%%%%%%%%%%%%%size%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%number of images
num_images=ne-ns+1;

%fill in holes
%filling in holes
[cluster_stack_ret]=fill_in_clusters_v2(cluster_stack,avg_stack,ns,ne);

%rename
cluster_stack_tmp=cluster_stack_ret;
clear cluster_stack;

for r=1:num_images
   
    im1=cluster_stack_tmp(:,:,r);
    idx1=find(im1>0);
    
    if numel(idx1)>0 && count_k==1
       all_c=im1(idx1); 
    elseif numel(idx1)>0 && count_k>1
        all_c_tmp=all_c;
        clear all_c;
        all_c=[all_c_tmp;im1(idx1)];
        clear all_c_tmp
    end
    
    if numel(idx1)>0 
        count_k=count_k+1;
    end
    
    clear im1; clear idx1;
end

count_r=1;

for s=min(all_c(:,1)):max(all_c(:,1))
   
    idx_s=find(all_c(:,1)==s);

    
    if numel(idx_s)<8 
        to_remove(count_r,1)=s;
        count_r=count_r+1;
    end
    
    clear idx_s;
    
end

%renaming
cluster_stack=cluster_stack_tmp;

if count_r>1
    
    for q=1:num_images
        im1=cluster_stack_tmp(:,:,q);
        for i=1:numel(to_remove)
           idx_vote=find(im1==to_remove(i));
           if numel(idx_vote)>0
               im1(idx_vote)=0;
           end
           clear idx_vote;
        end
        cluster_stack(:,:,q)=im1; 
        clear im1;
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Making Some Directories%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%some more definitions
% gr_cluster_file='Final_Cluster_Stack.tif';
% gr_er_avg_file='Final_ER1_Avg_Stack.tif';

%directories for green and red channels
if which_channel == 1
    curr_dir_green=strcat(curr_dir,'g0\');
else
    curr_dir_green=strcat(curr_dir,'r0\');
end

%make new directories
mkdir(curr_dir_green);

mkdir(strcat(curr_dir_green,'WholeImageStackClustering\Intensity Stack\'));
mkdir(strcat(curr_dir_green,'ErodedBoundaryImages\'));
mkdir(strcat(curr_dir_green,'ErodedThreshIms\'));
mkdir(strcat(curr_dir_green,'The_Boundaries\'));

%creating text output for optimization

% %open file for writing
% fileID_opt = fopen(strcat(curr_dir_green,'cluster_optimization_record.txt'),'w');
% 
% for p=1:numel(all_data(:,1))
%    
%     %labels
%     if p==1
%         fprintf(fileID_opt,'%12s\t %12s\t %12s\n','Pearson Threshold','# of Clusters','Area of Clusters');
%     end
%     
%     %loading the actual values
%     fprintf(fileID_opt,'%12.8f\t %12.8f\t %12.8f\n',all_data(p,1),all_data(p,3),all_data(p,4));
%     
%     %adding optimum value
%     if p==numel(all_data(:,1))
%         
%         %label
%         fprintf(fileID_opt,'%12s\n','Optimum Pearson Threshold');
%         
%         %the value
%         fprintf(fileID_opt,'%12.8f',ideal_pear_search);
%         
%     end
%         
%   
% end
% 
% %close the text file
% fclose(fileID_opt);

%counter
count=1;

%moving the boundaries over
for r=ns:ne
   
    %get a boundary
    bound1_tmp=load(strcat(path_bound,num2str(r),'.mat'));
    bound1=bound1_tmp.boundary_out;
    
    %create the boundary
    boundary_out=bound1;
    save(strcat(curr_dir_green,'The_Boundaries\Bound',num2str(r)),'boundary_out');
    
    %clear statements
    clear bound1; clear bound1_tmp; clear boundary_out;
    
end

%header information
% info_gr_cluster=imfinfo(gr_cluster_file);
% info_gr_er=imfinfo(gr_er_avg_file);


for i=ns:ne

   %Read - Eroded Boundary Images
   im_gr_erode_tmp=imread(strcat(path_er_ims,num2str(i),'.tif'));
   
%    %Read - cluster images
%    im_gr_cluster=imread(gr_cluster_file,count,'Info',info_gr_cluster);
%    
%    %some scaling
%    im_gr_cluster=im_gr_cluster-1;
%     
%    %Read - Average Ims - "Eroded Thresh Ims"
%    im_gr_er_avg=imread(gr_er_avg_file,count,'Info',info_gr_er);

   %cropping eroded boundary images to same size as images with clusters
   if i==ns
       im_gr_cluster=cluster_stack(:,:,count);
       dim1=size(im_gr_cluster,1);
       dim2=size(im_gr_cluster,2);
   end
   
   %cropping
   im_gr_erode=imcrop(im_gr_erode_tmp,[1,1,dim2-1,dim1-1]);
   
   %saving - Erode Boundary Images
   imwrite(uint16(im_gr_erode),strcat(curr_dir_green,'ErodedBoundaryImages\MaskBoundErode',num2str(i),'.tif'));
    
   %saving - clustering images
   imwrite(uint16(cluster_stack(:,:,count)-1),strcat(curr_dir_green,'WholeImageStackClustering\Intensity Stack\Im',num2str(i),'.tif'));

   %saving - eroded averaged images
   imwrite(uint16(avg_stack(:,:,count))',strcat(curr_dir_green,'ErodedThreshIms\ErodedThresh',num2str(i),'.tif'));
   
   %iterate counter
   count=count+1;
    
   %clear statements
   clear im_gr_erode_tmp; 
   %clear im_gr_cluster;clear im_gr_er_avg;  clear im_gr_erode; 
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Creating the cluster information txt file%%%%%%%%%%%%%%%%

%counter
count1=1;

for j=ns:ne
    j
%    %Read - cluster images
%    im_gr_cluster=imread(gr_cluster_file,count1,'Info',info_gr_cluster);
%    
%    %some scaling
%    im_gr_cluster=im_gr_cluster-1;
    
    %read - cluster images
    im_gr_cluster=uint16(cluster_stack(:,:,count1)-1);

   %Read - Average Ims - "Eroded Thresh Ims"
%    im_gr_er_avg=imread(gr_er_avg_file,count1,'Info',info_gr_er);

    %Read - Average Ims - "Eroded Thresh Ims"
    im_gr_er_avg=uint16(avg_stack(:,:,count1));
    
   %indices
   idx_gr=find(im_gr_cluster>0);
   
   if j==ns
       
       %cluster data
       big_gr_cl_list=im_gr_cluster(idx_gr);
       
       %intensity dataa
       big_gr_int_list=im_gr_er_avg(idx_gr);

   else
       
       %cluster data
        big_gr_cl_list=add_to_list(big_gr_cl_list,im_gr_cluster(idx_gr));
        
        %intensity data
        big_gr_int_list=add_to_list(big_gr_int_list,im_gr_er_avg(idx_gr));
        
   end
   
   %clear statements
   clear im_gr_cluster; 
   clear im_gr_er_avg; 
   clear idx_gr; 
   
   %iterate counter
   count1=count1+1;

end

%getting the matrix to put into txt file
[green_for_txt_file]=create_txt_cluster_matrix(big_gr_cl_list,big_gr_int_list);

%open file for writing
fileID = fopen(strcat(curr_dir_green,'WholeImageStackClustering\','cluster_size.txt'),'w');

for a=1:numel(green_for_txt_file(:,1))
   
    if a==1
        fprintf(fileID,'%12s %12s %12s\n','Cluster #','Size of Cluster (Voxel)','Integrated Intensity');
    end
    
    fprintf(fileID,'%12.8f %12.8f %12.8f\n',green_for_txt_file(a,1),green_for_txt_file(a,2),green_for_txt_file(a,3));
    
end

fclose(fileID);



        
        
        
        
        
        
        
        
        
        
        
        
        
        
